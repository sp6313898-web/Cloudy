from pathlib import Path
from collections import Counter
TOOLS = [{"name": "project_tree", "description": "Дерево файлов рабочей папки (глубина до 3) и количество файлов по расширениям.",
          "parameters": {"type": "object", "properties": {}}}]
SKIP = {".git", "node_modules", "__pycache__", ".venv", "dist", "build"}


def run(name, args, ctx):
    root = Path(ctx["workspace"]).resolve()
    lines, ext = [], Counter()

    def walk(d, depth):
        for p in sorted(d.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
            if p.name in SKIP:
                continue
            if p.is_dir():
                if depth < 3:
                    lines.append("  " * depth + "[папка] " + p.name); walk(p, depth + 1)
            else:
                ext[p.suffix or "(без)"] += 1
                if depth < 3 and len(lines) < 200:
                    lines.append("  " * depth + p.name)
    walk(root, 0)
    return "\n".join(lines) + "\n\nПо типам: " + ", ".join(f"{k}: {v}" for k, v in ext.most_common(10))
