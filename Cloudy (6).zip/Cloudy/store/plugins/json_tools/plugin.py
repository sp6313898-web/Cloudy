import json, re
TOOLS = [{"name": "json_process", "description": "Работа с JSON: validate, format, minify, keys (ключи верхнего уровня), get (значение по пути a.b[0].c), flatten (плоский вид).",
          "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "action": {"type": "string", "enum": ["validate", "format", "minify", "keys", "get", "flatten"]},
                                                          "path": {"type": "string"}}, "required": ["text", "action"]}}]


def flat(o, p=""):
    if isinstance(o, dict):
        for k, v in o.items(): yield from flat(v, f"{p}.{k}" if p else k)
    elif isinstance(o, list):
        for i, v in enumerate(o): yield from flat(v, f"{p}[{i}]")
    else: yield p, o


def run(name, a, ctx):
    try: o = json.loads(a["text"])
    except Exception as e: return f"Невалидный JSON: {e}"
    act = a["action"]
    if act == "validate": return "JSON корректен. Тип: " + type(o).__name__
    if act == "format": return json.dumps(o, ensure_ascii=False, indent=2)
    if act == "minify": return json.dumps(o, ensure_ascii=False, separators=(",", ":"))
    if act == "keys": return ", ".join(o.keys()) if isinstance(o, dict) else f"список из {len(o)} элементов" if isinstance(o, list) else "не объект"
    if act == "flatten": return "\n".join(f"{k} = {json.dumps(v, ensure_ascii=False)}" for k, v in flat(o))
    cur = o
    for part in re.findall(r"[^.\[\]]+|\[\d+\]", a.get("path", "")):
        try: cur = cur[int(part[1:-1])] if part.startswith("[") else cur[part]
        except Exception: return f"Путь не найден на «{part}»"
    return json.dumps(cur, ensure_ascii=False, indent=2)
