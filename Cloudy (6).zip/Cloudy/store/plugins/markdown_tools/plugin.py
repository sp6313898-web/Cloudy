import re
from pathlib import Path
TOOLS = [
    {"name": "md_toc", "description": "Оглавление Markdown: из текста или из файла рабочей папки (path).",
     "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "path": {"type": "string"}}}},
    {"name": "md_table", "description": "Собрать таблицу Markdown из строк-списков (первая строка — заголовок).",
     "parameters": {"type": "object", "properties": {"rows": {"type": "array", "items": {"type": "array", "items": {"type": "string"}}}}, "required": ["rows"]}}]


def run(name, a, ctx):
    if name == "md_table":
        r = a["rows"]
        if not r: return ""
        w = max(len(x) for x in r); r = [x + [""] * (w - len(x)) for x in r]
        return "\n".join(["| " + " | ".join(r[0]) + " |", "|" + "---|" * w] + ["| " + " | ".join(x) + " |" for x in r[1:]])
    if a.get("path"):
        root = Path(ctx["workspace"]).resolve(); p = (root / a["path"]).resolve(); p.relative_to(root); text = p.read_text("utf-8", errors="replace")
    else: text = a.get("text", "")
    out, fence = [], False
    for l in text.splitlines():
        if l.strip().startswith("```"): fence = not fence
        m = re.match(r"(#{1,6})\s+(.*)", l)
        if m and not fence:
            anchor = re.sub(r"[^\w\- ]", "", m[2].lower()).strip().replace(" ", "-")
            out.append("  " * (len(m[1]) - 1) + f"- [{m[2].strip()}](#{anchor})")
    return "\n".join(out) or "Заголовков нет"
