import json, time
from pathlib import Path
TOOLS = [{"name": "notes", "description": "Постоянные заметки пользователя (хранятся на компьютере). action: add (text, tag), list, search (text), delete (id).",
          "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["add", "list", "search", "delete"]}, "text": {"type": "string"}, "tag": {"type": "string"}, "id": {"type": "integer"}}, "required": ["action"]}}]


def run(name, a, ctx):
    f = Path(ctx["data"]) / "notes.json"
    try: d = json.loads(f.read_text("utf-8"))
    except Exception: d = {"next": 1, "items": []}
    act = a["action"]
    if act == "add":
        d["items"].append({"id": d["next"], "text": a.get("text", ""), "tag": a.get("tag", ""), "ts": time.strftime("%Y-%m-%d %H:%M")}); d["next"] += 1
        f.write_text(json.dumps(d, ensure_ascii=False), "utf-8"); return f"Заметка #{d['next'] - 1} сохранена"
    if act == "delete":
        n = len(d["items"]); d["items"] = [x for x in d["items"] if x["id"] != a.get("id")]; f.write_text(json.dumps(d, ensure_ascii=False), "utf-8")
        return "Удалено" if len(d["items"]) < n else "Не найдено"
    q = (a.get("text") or "").lower(); xs = [x for x in d["items"] if act == "list" or q in (x["text"] + " " + x["tag"]).lower()]
    return "\n".join(f"#{x['id']} [{x['ts']}] {('(' + x['tag'] + ') ') if x['tag'] else ''}{x['text']}" for x in xs[-50:]) or "Заметок нет"
