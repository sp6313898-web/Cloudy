import calendar, datetime as dt
TOOLS = [{"name": "date_calc", "description": "Даты: add (date + days/weeks/months/years), diff (между a и b), weekday, age (birth), business_days (a..b), week_number, month_calendar (year, month). Даты в формате ГГГГ-ММ-ДД.",
          "parameters": {"type": "object", "properties": {"action": {"type": "string"}, "date": {"type": "string"}, "a": {"type": "string"}, "b": {"type": "string"}, "days": {"type": "integer"},
                                                          "weeks": {"type": "integer"}, "months": {"type": "integer"}, "years": {"type": "integer"}, "year": {"type": "integer"}, "month": {"type": "integer"}}, "required": ["action"]}}]
DAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]


def D(s): return dt.date.fromisoformat(s)


def addm(d, m):
    y, mo = divmod(d.month - 1 + m, 12); y += d.year; mo += 1
    return d.replace(year=y, month=mo, day=min(d.day, calendar.monthrange(y, mo)[1]))


def run(name, a, ctx):
    act = a["action"]
    if act == "add":
        d = addm(D(a["date"]), int(a.get("months") or 0) + 12 * int(a.get("years") or 0)) + dt.timedelta(days=int(a.get("days") or 0) + 7 * int(a.get("weeks") or 0))
        return f"{d.isoformat()} ({DAYS[d.weekday()]})"
    if act == "diff":
        x, y = D(a["a"]), D(a["b"]); n = (y - x).days; return f"{n} дн. ({n // 7} нед. {n % 7} дн.)"
    if act == "weekday": d = D(a["date"]); return DAYS[d.weekday()]
    if act == "week_number": d = D(a["date"]); return f"ISO-неделя {d.isocalendar()[1]}, день года {d.timetuple().tm_yday}"
    if act == "age":
        b, t = D(a["date"] if "date" in a else a["a"]), dt.date.today(); y = t.year - b.year - ((t.month, t.day) < (b.month, b.day))
        m = (t.month - b.month - (t.day < b.day)) % 12; return f"{y} лет {m} мес."
    if act == "business_days":
        x, y = D(a["a"]), D(a["b"]); n = sum(1 for i in range((y - x).days + 1) if (x + dt.timedelta(i)).weekday() < 5); return f"{n} рабочих дней (без учёта праздников)"
    if act == "month_calendar": return calendar.month(int(a["year"]), int(a["month"]))
    return "Неизвестное действие"
