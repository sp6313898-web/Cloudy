import urllib.parse as up
TOOLS = [
    {"name": "url_parse", "description": "Разобрать URL на части и параметры запроса.", "parameters": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}},
    {"name": "url_build", "description": "Собрать URL из базового адреса и словаря параметров.",
     "parameters": {"type": "object", "properties": {"base": {"type": "string"}, "params": {"type": "object"}}, "required": ["base", "params"]}}]


def run(name, a, ctx):
    if name == "url_parse":
        u = up.urlparse(a["url"]); q = up.parse_qs(u.query)
        return f"схема: {u.scheme}\nхост: {u.hostname}\nпорт: {u.port}\nпуть: {u.path}\nпараметры: {q}\nфрагмент: {u.fragment}"
    return a["base"] + ("&" if "?" in a["base"] else "?") + up.urlencode(a["params"], doseq=True)
