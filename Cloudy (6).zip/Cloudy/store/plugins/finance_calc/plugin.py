TOOLS = [
    {"name": "loan_payment", "description": "Аннуитетный кредит: ежемесячный платёж, переплата и первые месяцы графика. Ставка — годовая в %.",
     "parameters": {"type": "object", "properties": {"principal": {"type": "number"}, "annual_rate": {"type": "number"}, "months": {"type": "integer"}}, "required": ["principal", "annual_rate", "months"]}},
    {"name": "compound_interest", "description": "Сложный процент с ежемесячными взносами. Ставка годовая в %.",
     "parameters": {"type": "object", "properties": {"principal": {"type": "number"}, "annual_rate": {"type": "number"}, "years": {"type": "number"}, "monthly_add": {"type": "number"}}, "required": ["principal", "annual_rate", "years"]}},
    {"name": "percent_calc", "description": "Проценты: kind=change (от a к b), of (p% от x), vat_add (добавить НДС p% к x), vat_remove (выделить НДС p% из x).",
     "parameters": {"type": "object", "properties": {"kind": {"type": "string"}, "a": {"type": "number"}, "b": {"type": "number"}}, "required": ["kind", "a", "b"]}}]


def run(name, a, ctx):
    if name == "loan_payment":
        P, n, r = float(a["principal"]), int(a["months"]), float(a["annual_rate"]) / 1200
        pay = P / n if r == 0 else P * r / (1 - (1 + r) ** -n); bal = P; rows = []
        for i in range(1, min(n, 3) + 1):
            it = bal * r; pr = pay - it; bal -= pr; rows.append(f"месяц {i}: проценты {it:,.2f}, долг {pr:,.2f}, остаток {bal:,.2f}")
        return f"Платёж: {pay:,.2f} в месяц; всего {pay * n:,.2f}; переплата {pay * n - P:,.2f}\n" + "\n".join(rows)
    if name == "compound_interest":
        bal = float(a["principal"]); add = float(a.get("monthly_add") or 0); r = float(a["annual_rate"]) / 1200; n = int(float(a["years"]) * 12); put = bal
        for _ in range(n): bal = bal * (1 + r) + add; put += add
        return f"Итог: {bal:,.2f}; вложено {put:,.2f}; доход {bal - put:,.2f}"
    k, x, y = a["kind"], float(a["a"]), float(a["b"])
    if k == "change": return f"{(y - x) / x * 100:+.4g}%" if x else "деление на ноль"
    if k == "of": return f"{x}% от {y} = {x * y / 100:,.4f}"
    if k == "vat_add": return f"{y:,.2f} + НДС {x}% = {y * (1 + x / 100):,.2f} (налог {y * x / 100:,.2f})"
    if k == "vat_remove": return f"{y:,.2f} включает НДС {x}%: без НДС {y / (1 + x / 100):,.2f}, налог {y - y / (1 + x / 100):,.2f}"
    return "Неизвестный вид"
