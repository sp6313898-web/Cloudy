import secrets, string, math
TOOLS = [
    {"name": "make_password", "description": "Сгенерировать криптостойкие пароли (secrets).",
     "parameters": {"type": "object", "properties": {"length": {"type": "integer"}, "count": {"type": "integer"}, "symbols": {"type": "boolean"}}}},
    {"name": "password_strength", "description": "Оценить энтропию пароля (в битах) по составу символов. Пароль никуда не отправляется.",
     "parameters": {"type": "object", "properties": {"password": {"type": "string"}}, "required": ["password"]}}]


def run(name, a, ctx):
    if name == "make_password":
        n = max(8, min(int(a.get("length") or 16), 128)); alpha = string.ascii_letters + string.digits + ("!@#$%^&*-_=+?" if a.get("symbols", True) else "")
        out = []
        for _ in range(max(1, min(int(a.get("count") or 1), 10))):
            while True:
                p = "".join(secrets.choice(alpha) for _ in range(n))
                if any(c.islower() for c in p) and any(c.isupper() for c in p) and any(c.isdigit() for c in p): break
            out.append(p)
        return "\n".join(out)
    p = a["password"]; pool = (26 if any(c.islower() for c in p) else 0) + (26 if any(c.isupper() for c in p) else 0) + (10 if any(c.isdigit() for c in p) else 0) + (32 if any(not c.isalnum() for c in p) else 0)
    bits = len(p) * math.log2(pool) if pool else 0
    return f"~{bits:.0f} бит: " + ("слабый" if bits < 40 else "средний" if bits < 60 else "хороший" if bits < 80 else "очень сильный") + " (оценка по алфавиту, словарные слова слабее)"
