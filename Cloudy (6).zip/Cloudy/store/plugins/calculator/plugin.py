import ast, operator as op, math
OPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.Pow: op.pow,
       ast.Mod: op.mod, ast.FloorDiv: op.floordiv, ast.USub: op.neg, ast.UAdd: op.pos}
FUN = {k: getattr(math, k) for k in ("sqrt", "sin", "cos", "tan", "log", "log10", "exp", "floor", "ceil")}
FUN.update(abs=abs, round=round, min=min, max=max)
CONST = {"pi": math.pi, "e": math.e}
TOOLS = [{"name": "calc", "description": "Вычислить математическое выражение, например 2**10 + sqrt(144).",
          "parameters": {"type": "object", "properties": {"expression": {"type": "string"}}, "required": ["expression"]}}]


def _ev(n):
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
        return n.value
    if isinstance(n, ast.BinOp) and type(n.op) in OPS:
        a, b = _ev(n.left), _ev(n.right)
        if isinstance(n.op, ast.Pow) and abs(b) > 1000:
            raise ValueError("слишком большая степень")
        return OPS[type(n.op)](a, b)
    if isinstance(n, ast.UnaryOp) and type(n.op) in OPS:
        return OPS[type(n.op)](_ev(n.operand))
    if isinstance(n, ast.Name) and n.id in CONST:
        return CONST[n.id]
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in FUN:
        return FUN[n.func.id](*[_ev(a) for a in n.args])
    raise ValueError("недопустимое выражение")


def run(name, args, ctx):
    return _ev(ast.parse(args["expression"], mode="eval").body)
