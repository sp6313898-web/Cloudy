import hashlib, base64
TOOLS = [
    {"name": "hash_text", "description": "Хэш текста: algo = sha256 | md5 | sha1.",
     "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "algo": {"type": "string"}}, "required": ["text"]}},
    {"name": "base64_convert", "description": "Base64: mode = encode | decode.",
     "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "mode": {"type": "string"}}, "required": ["text", "mode"]}},
]


def run(name, args, ctx):
    if name == "hash_text":
        algo = args.get("algo", "sha256")
        if algo not in ("sha256", "md5", "sha1"):
            return "Алгоритм не поддерживается"
        return hashlib.new(algo, args["text"].encode()).hexdigest()
    if args["mode"] == "encode":
        return base64.b64encode(args["text"].encode()).decode()
    return base64.b64decode(args["text"]).decode("utf-8", "replace")
