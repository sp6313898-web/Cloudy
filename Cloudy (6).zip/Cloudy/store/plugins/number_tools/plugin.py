import math
TOOLS = [
    {"name": "number_info", "description": "Свойства целого числа: простое ли, разложение на множители, делители, двоичная/16-ричная запись, римская цифра.",
     "parameters": {"type": "object", "properties": {"n": {"type": "integer"}}, "required": ["n"]}},
    {"name": "gcd_lcm", "description": "НОД и НОК списка целых чисел.", "parameters": {"type": "object", "properties": {"numbers": {"type": "array", "items": {"type": "integer"}}}, "required": ["numbers"]}},
    {"name": "base_convert", "description": "Перевод числа между системами счисления 2..36.",
     "parameters": {"type": "object", "properties": {"value": {"type": "string"}, "from_base": {"type": "integer"}, "to_base": {"type": "integer"}}, "required": ["value", "from_base", "to_base"]}}]
ROM = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"), (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]


def factor(n):
    f, d = {}, 2
    while d * d <= n and d < 2_000_000:
        while n % d == 0: f[d] = f.get(d, 0) + 1; n //= d
        d += 1 if d == 2 else 2
    if n > 1: f[n] = f.get(n, 0) + 1
    return f


def run(name, a, ctx):
    if name == "gcd_lcm":
        n = a["numbers"]; g = 0; l = 1
        for x in n: g = math.gcd(g, x); l = l * x // math.gcd(l, x) if x else 0
        return f"НОД = {g}; НОК = {l}"
    if name == "base_convert":
        v = int(a["value"], int(a["from_base"])); b = int(a["to_base"]); digs = "0123456789abcdefghijklmnopqrstuvwxyz"; s = ""; x = abs(v)
        while x: s = digs[x % b] + s; x //= b
        return ("-" if v < 0 else "") + (s or "0")
    n = int(a["n"])
    if abs(n) > 10 ** 12: return "Число слишком большое (до 10^12)"
    f = factor(abs(n)) if abs(n) > 1 else {}; prime = len(f) == 1 and list(f.values())[0] == 1
    out = [f"{n}: " + ("простое" if prime else "составное" if abs(n) > 1 else "ни простое, ни составное"), "множители: " + (" · ".join(f"{p}^{e}" if e > 1 else str(p) for p, e in f.items()) or "-"),
           f"bin {bin(n)}; hex {hex(n)}; oct {oct(n)}; сумма цифр {sum(map(int, str(abs(n))))}"]
    if 0 < n < 4000:
        r, x = "", n
        for v, s in ROM:
            while x >= v: r += s; x -= v
        out.append("римское: " + r)
    return "\n".join(out)
