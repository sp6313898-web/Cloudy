import csv, io, json, random, uuid
FIRST = ["Алексей", "Мария", "Иван", "Анна", "Дмитрий", "Елена", "Сергей", "Ольга", "Андрей", "Наталья", "John", "Emma", "Liam", "Olivia", "Noah", "Sophia"]
LAST = ["Иванов", "Петрова", "Смирнов", "Кузнецова", "Попов", "Соколова", "Smith", "Johnson", "Brown", "Taylor", "Miller", "Wilson"]
CITY = ["Москва", "Казань", "Минск", "Алматы", "Berlin", "Paris", "Boston", "Tokyo", "Lisbon", "Warsaw"]
CO = ["Север", "Вектор", "Атлас", "Nimbus", "Orbit", "Pixel", "Quanta", "Helix"]
TR = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя", ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "f", "h", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]))
TOOLS = [{"name": "fake_data", "description": "Сгенерировать тестовые данные (вымышленные): person (имя, email, телефон, город, дата рождения), company, uuid. Формат json или csv, до 100 записей.",
          "parameters": {"type": "object", "properties": {"kind": {"type": "string", "enum": ["person", "company", "uuid"]}, "count": {"type": "integer"}, "format": {"type": "string", "enum": ["json", "csv"]}, "seed": {"type": "integer"}}, "required": ["kind"]}}]


def lat(s): return "".join(TR.get(c, c) for c in s.lower())


def run(name, a, ctx):
    rnd = random.Random(a.get("seed")); n = max(1, min(int(a.get("count") or 5), 100)); rows = []
    for _ in range(n):
        if a["kind"] == "person":
            f, l = rnd.choice(FIRST), rnd.choice(LAST)
            rows.append({"name": f"{f} {l}", "email": f"{lat(f)}.{lat(l)}{rnd.randint(1, 99)}@example.com", "phone": f"+1-555-01{rnd.randint(0, 99):02d}", "city": rnd.choice(CITY),
                         "birth": f"{rnd.randint(1960, 2006)}-{rnd.randint(1, 12):02d}-{rnd.randint(1, 28):02d}"})
        elif a["kind"] == "company":
            c = rnd.choice(CO); rows.append({"company": f"{c} {rnd.choice(['LLC', 'Group', 'Labs', 'Studio'])}", "site": f"https://{lat(c)}.example.com", "employees": rnd.randint(3, 5000), "city": rnd.choice(CITY)})
        else: rows.append({"uuid": str(uuid.UUID(int=rnd.getrandbits(128), version=4))})
    if a.get("format") == "csv":
        b = io.StringIO(); w = csv.DictWriter(b, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows); return b.getvalue()
    return json.dumps(rows, ensure_ascii=False, indent=1)
