import statistics as st
TOOLS = [
    {"name": "describe_numbers", "description": "Описательная статистика списка чисел: среднее, медиана, мода, стд. отклонение, квартили, выбросы.",
     "parameters": {"type": "object", "properties": {"numbers": {"type": "array", "items": {"type": "number"}}}, "required": ["numbers"]}},
    {"name": "linear_regression", "description": "Линейная регрессия y = a*x + b и коэффициент корреляции по спискам x и y.",
     "parameters": {"type": "object", "properties": {"x": {"type": "array", "items": {"type": "number"}}, "y": {"type": "array", "items": {"type": "number"}}}, "required": ["x", "y"]}}]


def run(name, a, ctx):
    if name == "describe_numbers":
        n = sorted(a["numbers"])
        if len(n) < 2: return "Нужно хотя бы 2 числа"
        q = st.quantiles(n, n=4); iqr = q[2] - q[0]; out = [x for x in n if x < q[0] - 1.5 * iqr or x > q[2] + 1.5 * iqr]
        return (f"n={len(n)}; среднее {st.mean(n):.6g}; медиана {st.median(n):.6g}; мода {st.mode(n):g}; ст.откл. {st.stdev(n):.6g}\n"
                f"min {n[0]:g}; Q1 {q[0]:.6g}; Q3 {q[2]:.6g}; max {n[-1]:g}; выбросы: {out or 'нет'}")
    x, y = a["x"], a["y"]
    if len(x) != len(y) or len(x) < 3: return "Нужны списки одинаковой длины (≥3)"
    r = st.linear_regression(x, y); c = st.correlation(x, y)
    return f"y = {r.slope:.6g}·x + {r.intercept:.6g}; корреляция r = {c:.4f}; R² = {c * c:.4f}"
