import datetime as dt
TOOLS = [
    {"name": "time_convert", "description": "Перевести время между часовыми поясами IANA (Europe/Moscow, America/New_York, Asia/Tokyo...). datetime: ГГГГ-ММ-ДД ЧЧ:ММ.",
     "parameters": {"type": "object", "properties": {"datetime": {"type": "string"}, "from_tz": {"type": "string"}, "to_tz": {"type": "string"}}, "required": ["datetime", "from_tz", "to_tz"]}},
    {"name": "time_now_in", "description": "Текущее время в часовом поясе IANA.", "parameters": {"type": "object", "properties": {"tz": {"type": "string"}}, "required": ["tz"]}}]


def run(name, a, ctx):
    from zoneinfo import ZoneInfo
    try:
        if name == "time_now_in": return dt.datetime.now(ZoneInfo(a["tz"])).strftime("%Y-%m-%d %H:%M:%S %Z (UTC%z)")
        t = dt.datetime.fromisoformat(a["datetime"]).replace(tzinfo=ZoneInfo(a["from_tz"])); r = t.astimezone(ZoneInfo(a["to_tz"]))
        return f"{t:%Y-%m-%d %H:%M %Z} = {r:%Y-%m-%d %H:%M %Z} (UTC{r:%z})"
    except Exception as e:
        return f"Не удалось: {e}. Названия вида Europe/Moscow, America/New_York."
