CATS = {
    "length": {"mm": .001, "cm": .01, "m": 1, "km": 1000, "in": .0254, "ft": .3048, "yd": .9144, "mi": 1609.344, "nmi": 1852},
    "mass": {"mg": 1e-6, "g": .001, "kg": 1, "t": 1000, "oz": .028349523125, "lb": .45359237},
    "volume": {"ml": .001, "l": 1, "m3": 1000, "gal": 3.785411784, "qt": .946352946, "pt": .473176473, "cup": .2365882365, "floz": .0295735295625, "tbsp": .01478676478, "tsp": .00492892159},
    "area": {"mm2": 1e-6, "cm2": 1e-4, "m2": 1, "km2": 1e6, "ha": 1e4, "acre": 4046.8564224, "ft2": .09290304, "in2": 6.4516e-4, "mi2": 2589988.110336},
    "speed": {"m/s": 1, "km/h": 1 / 3.6, "mph": .44704, "kn": .514444, "ft/s": .3048},
    "time": {"ms": .001, "s": 1, "min": 60, "h": 3600, "d": 86400, "week": 604800, "year": 31557600},
    "data": {"bit": .125, "b": 1, "kb": 1000, "mb": 1e6, "gb": 1e9, "tb": 1e12, "kib": 1024, "mib": 1024 ** 2, "gib": 1024 ** 3, "tib": 1024 ** 4},
}
ALIAS = {"км": "km", "м": "m", "см": "cm", "мм": "mm", "кг": "kg", "г": "g", "т": "t", "мг": "mg", "л": "l", "мл": "ml", "ч": "h", "мин": "min",
         "с": "s", "сек": "s", "дн": "d", "км/ч": "km/h", "м/с": "m/s", "миля": "mi", "фут": "ft", "дюйм": "in", "фунт": "lb", "унция": "oz",
         "byte": "b", "inch": "in", "feet": "ft", "mile": "mi", "pound": "lb", "gallon": "gal", "hour": "h", "day": "d", "minute": "min", "second": "s"}
TOOLS = [{"name": "convert_units", "description": "Перевести величину между единицами: длина, масса, объём, площадь, скорость, время, данные (B, KB, MiB, GB...), температура (C, F, K).",
          "parameters": {"type": "object", "properties": {"value": {"type": "number"}, "from": {"type": "string"}, "to": {"type": "string"}}, "required": ["value", "from", "to"]}}]


def norm(u): return ALIAS.get(u.strip().lower().replace("°", ""), u.strip().lower().replace("°", ""))


def run(name, a, ctx):
    v, f, t = float(a["value"]), norm(a["from"]), norm(a["to"])
    if f in ("c", "f", "k") and t in ("c", "f", "k"):
        c = v if f == "c" else (v - 32) * 5 / 9 if f == "f" else v - 273.15
        r = c if t == "c" else c * 9 / 5 + 32 if t == "f" else c + 273.15
        return f"{v:g} {f.upper()} = {r:.4g} {t.upper()}"
    for cat, u in CATS.items():
        if f in u and t in u:
            return f"{v:g} {f} = {v * u[f] / u[t]:.6g} {t}  ({cat})"
    return "Неизвестные или несовместимые единицы. Доступно: " + ", ".join(f"{c}: {' '.join(u)}" for c, u in CATS.items())
