import difflib
from pathlib import Path
TOOLS = [{"name": "diff", "description": "Показать различия между двумя текстами (mode=text) или двумя файлами рабочей папки (mode=file) в формате unified diff.",
          "parameters": {"type": "object", "properties": {"a": {"type": "string"}, "b": {"type": "string"}, "mode": {"type": "string", "enum": ["text", "file"]}}, "required": ["a", "b"]}}]


def run(name, a, ctx):
    x, y = a["a"], a["b"]
    if a.get("mode") == "file":
        root = Path(ctx["workspace"]).resolve(); out = []
        for rel in (x, y):
            p = (root / rel).resolve(); p.relative_to(root); out.append(p.read_text("utf-8", errors="replace"))
        la, lb, na, nb = out[0].splitlines(), out[1].splitlines(), x, y
    else: la, lb, na, nb = x.splitlines(), y.splitlines(), "A", "B"
    d = list(difflib.unified_diff(la, lb, na, nb, lineterm=""))
    return "\n".join(d[:200]) + (f"\n… ещё {len(d) - 200} строк" if len(d) > 200 else "") if d else "Различий нет"
