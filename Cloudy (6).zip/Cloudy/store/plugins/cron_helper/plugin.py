import datetime as dt
TOOLS = [{"name": "cron_next", "description": "Разобрать cron-выражение из 5 полей (мин час день месяц день_недели) и показать ближайшие запуски.",
          "parameters": {"type": "object", "properties": {"expression": {"type": "string"}, "count": {"type": "integer"}}, "required": ["expression"]}}]
NAMES = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12, "sun": 0, "mon": 1, "tue": 2, "wed": 3, "thu": 4, "fri": 5, "sat": 6}


def field(s, lo, hi):
    out = set()
    for part in s.lower().split(","):
        step = 1
        if "/" in part: part, st = part.split("/"); step = int(st)
        if part in ("*", "?"): a, b = lo, hi
        elif "-" in part: x, y = part.split("-"); a, b = NAMES.get(x) if x in NAMES else int(x), NAMES.get(y) if y in NAMES else int(y)
        else: a = NAMES.get(part) if part in NAMES else int(part); b = hi if step > 1 else a
        out.update(range(a, b + 1, step))
    return {v for v in out if lo <= v <= hi}


def run(name, a, ctx):
    p = a["expression"].split()
    if len(p) != 5: return "Нужно 5 полей: мин час день месяц день_недели"
    mi, ho, dm, mo, dw = field(p[0], 0, 59), field(p[1], 0, 23), field(p[2], 1, 31), field(p[3], 1, 12), {v % 7 for v in field(p[4], 0, 7)}
    star_dm, star_dw = p[2] in ("*", "?"), p[4] in ("*", "?"); now = dt.datetime.now().replace(second=0, microsecond=0); out = []; d = now.date()
    for _ in range(800):
        ok_dm, ok_dw = d.day in dm, (d.isoweekday() % 7) in dw
        day_ok = d.month in mo and ((ok_dm and ok_dw) if star_dm or star_dw else (ok_dm or ok_dw))
        if day_ok:
            for h in sorted(ho):
                for m in sorted(mi):
                    t = dt.datetime.combine(d, dt.time(h, m))
                    if t > now: out.append(t.strftime("%Y-%m-%d %H:%M (%a)"))
                    if len(out) >= max(1, min(int(a.get("count") or 5), 20)): return "Ближайшие запуски:\n" + "\n".join(out)
        d += dt.timedelta(days=1)
    return "Запусков в ближайшие ~2 года не найдено"
