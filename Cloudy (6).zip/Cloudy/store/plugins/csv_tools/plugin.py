import csv, statistics, collections
from pathlib import Path
TOOLS = [{"name": "csv_summary", "description": "Сводка по CSV-файлу в рабочей папке: столбцы, число строк, статистика числовых столбцов, частые значения, первые строки.",
          "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "delimiter": {"type": "string"}, "head": {"type": "integer"}}, "required": ["path"]}}]


def run(name, a, ctx):
    root = Path(ctx["workspace"]).resolve(); p = (root / a["path"]).resolve(); p.relative_to(root)
    if p.stat().st_size > 5_000_000: return "Файл больше 5 МБ"
    text = p.read_text("utf-8-sig", errors="replace"); d = a.get("delimiter") or (";" if text.split("\n")[0].count(";") > text.split("\n")[0].count(",") else ",")
    rows = list(csv.reader(text.splitlines(), delimiter=d))[:100001]
    if not rows: return "Пустой файл"
    head, data = rows[0], rows[1:]; out = [f"Строк данных: {len(data)}; столбцов: {len(head)}"]
    for i, h in enumerate(head):
        col = [r[i].strip() for r in data if i < len(r) and r[i].strip()]; nums = []
        for v in col:
            try: nums.append(float(v.replace(",", ".")))
            except ValueError: pass
        if col and len(nums) >= 0.8 * len(col):
            out.append(f"- {h}: число; min {min(nums):g}, max {max(nums):g}, среднее {statistics.mean(nums):.4g}, пропусков {len(data) - len(col)}")
        else:
            top = collections.Counter(col).most_common(3); out.append(f"- {h}: текст; уникальных {len(set(col))}; частые: " + ", ".join(f"{k} ({v})" for k, v in top))
    out.append("Первые строки:"); out += [" | ".join(r) for r in rows[:1 + int(a.get("head") or 5)]]
    return "\n".join(out)
