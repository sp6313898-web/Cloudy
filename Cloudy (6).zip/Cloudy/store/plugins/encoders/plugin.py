import binascii, html, urllib.parse as up
MORSE = {"a": ".-", "b": "-...", "c": "-.-.", "d": "-..", "e": ".", "f": "..-.", "g": "--.", "h": "....", "i": "..", "j": ".---", "k": "-.-", "l": ".-..", "m": "--", "n": "-.", "o": "---", "p": ".--.", "q": "--.-", "r": ".-.",
         "s": "...", "t": "-", "u": "..-", "v": "...-", "w": ".--", "x": "-..-", "y": "-.--", "z": "--..", "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-", "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----."}
MODES = ["hex_encode", "hex_decode", "url_encode", "url_decode", "html_escape", "html_unescape", "rot13", "morse_encode", "morse_decode", "binary_encode", "binary_decode", "reverse"]
TOOLS = [{"name": "encode_text", "description": "Кодирование и декодирование текста: " + ", ".join(MODES) + ".",
          "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "mode": {"type": "string", "enum": MODES}}, "required": ["text", "mode"]}}]


def run(name, a, ctx):
    t, m = a["text"], a["mode"]
    try:
        if m == "hex_encode": return t.encode().hex()
        if m == "hex_decode": return binascii.unhexlify(t.replace(" ", "")).decode("utf-8", "replace")
        if m == "url_encode": return up.quote(t, safe="")
        if m == "url_decode": return up.unquote(t)
        if m == "html_escape": return html.escape(t)
        if m == "html_unescape": return html.unescape(t)
        if m == "rot13":
            import codecs; return codecs.encode(t, "rot13")
        if m == "morse_encode": return " ".join(MORSE.get(c, "?") for c in t.lower() if c != " ") if t.strip() else ""
        if m == "morse_decode":
            inv = {v: k for k, v in MORSE.items()}; return "".join(inv.get(x, "?") for x in t.split())
        if m == "binary_encode": return " ".join(f"{b:08b}" for b in t.encode())
        if m == "binary_decode": return bytes(int(x, 2) for x in t.split()).decode("utf-8", "replace")
        if m == "reverse": return t[::-1]
    except Exception as e:
        return f"Ошибка: {e}"
    return "Неизвестный режим"
