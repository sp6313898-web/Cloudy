import colorsys, re
TOOLS = [
    {"name": "color_convert", "description": "Перевести цвет (#rrggbb, rgb(r,g,b), hsl(h,s%,l%)) во все форматы.",
     "parameters": {"type": "object", "properties": {"color": {"type": "string"}}, "required": ["color"]}},
    {"name": "contrast_ratio", "description": "Контраст WCAG между цветом текста и фона, оценка AA/AAA.",
     "parameters": {"type": "object", "properties": {"foreground": {"type": "string"}, "background": {"type": "string"}}, "required": ["foreground", "background"]}},
    {"name": "color_palette", "description": "Палитра по базовому цвету: complementary, analogous, triadic, tetradic, monochrome.",
     "parameters": {"type": "object", "properties": {"color": {"type": "string"}, "scheme": {"type": "string"}}, "required": ["color"]}}]


def parse(s):
    s = s.strip().lower()
    m = re.fullmatch(r"#?([0-9a-f]{3}|[0-9a-f]{6})", s)
    if m:
        h = m[1]; h = "".join(c * 2 for c in h) if len(h) == 3 else h; return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    m = re.fullmatch(r"rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)", s)
    if m: return tuple(min(255, int(x)) for x in m.groups())
    m = re.fullmatch(r"hsl\(\s*(\d+)\s*,\s*(\d+)%?\s*,\s*(\d+)%?\s*\)", s)
    if m: r, g, b = colorsys.hls_to_rgb(int(m[1]) / 360, int(m[3]) / 100, int(m[2]) / 100); return round(r * 255), round(g * 255), round(b * 255)
    raise ValueError("Не понял цвет: " + s)


def hexs(c): return "#%02x%02x%02x" % c


def hsl(c):
    h, l, s = colorsys.rgb_to_hls(*(x / 255 for x in c)); return round(h * 360), round(s * 100), round(l * 100)


def lum(c):
    f = lambda v: v / 12.92 if v <= .03928 else ((v + .055) / 1.055) ** 2.4
    r, g, b = (f(x / 255) for x in c); return .2126 * r + .7152 * g + .0722 * b


def rot(c, deg):
    h, l, s = colorsys.rgb_to_hls(*(x / 255 for x in c)); r, g, b = colorsys.hls_to_rgb((h + deg / 360) % 1, l, s); return round(r * 255), round(g * 255), round(b * 255)


def run(name, a, ctx):
    try:
        if name == "color_convert":
            c = parse(a["color"]); return f"HEX {hexs(c)}; RGB {c}; HSL {hsl(c)}"
        if name == "contrast_ratio":
            f, b = parse(a["foreground"]), parse(a["background"]); l1, l2 = sorted((lum(f), lum(b)), reverse=True); r = (l1 + .05) / (l2 + .05)
            return f"{r:.2f}:1 — обычный текст: {'AAA' if r >= 7 else 'AA' if r >= 4.5 else 'не проходит'}; крупный: {'AAA' if r >= 4.5 else 'AA' if r >= 3 else 'не проходит'}"
        c = parse(a["color"]); s = (a.get("scheme") or "analogous").lower()
        degs = {"complementary": [0, 180], "analogous": [-30, 0, 30], "triadic": [0, 120, 240], "tetradic": [0, 90, 180, 270]}
        if s == "monochrome":
            h, l, sat = colorsys.rgb_to_hls(*(x / 255 for x in c)); return ", ".join(hexs(tuple(round(v * 255) for v in colorsys.hls_to_rgb(h, ll, sat))) for ll in (.2, .35, .5, .65, .8))
        return ", ".join(hexs(rot(c, d)) for d in degs.get(s, degs["analogous"]))
    except ValueError as e:
        return str(e)
