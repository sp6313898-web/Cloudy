import random, re, secrets, uuid
TOOLS = [
    {"name": "roll_dice", "description": "Бросок кубиков в нотации 2d6+3, d20, 4d8-1.",
     "parameters": {"type": "object", "properties": {"dice": {"type": "string"}}, "required": ["dice"]}},
    {"name": "random_pick", "description": "Случайно выбрать count элементов из списка (честный secrets).",
     "parameters": {"type": "object", "properties": {"items": {"type": "array", "items": {"type": "string"}}, "count": {"type": "integer"}}, "required": ["items"]}},
    {"name": "random_number", "description": "Случайное целое между min и max; либо новый UUID (kind=uuid), либо монетка (kind=coin).",
     "parameters": {"type": "object", "properties": {"min": {"type": "integer"}, "max": {"type": "integer"}, "kind": {"type": "string"}}}}]


def run(name, a, ctx):
    if name == "roll_dice":
        m = re.fullmatch(r"\s*(\d*)d(\d+)\s*([+-]\s*\d+)?\s*", a["dice"].lower())
        if not m: return "Формат: 2d6+3"
        n, s, b = int(m[1] or 1), int(m[2]), int((m[3] or "0").replace(" ", ""))
        if n > 100 or s > 1000 or s < 2: return "Слишком много кубиков или граней"
        r = [random.randint(1, s) for _ in range(n)]; return f"{r} {'+' if b >= 0 else '-'} {abs(b)} = {sum(r) + b}" if b else f"{r} = {sum(r)}"
    if name == "random_pick":
        it = list(a["items"]); k = max(1, min(int(a.get("count") or 1), len(it))); pool = it[:]; out = []
        for _ in range(k): out.append(pool.pop(secrets.randbelow(len(pool))))
        return ", ".join(out)
    if a.get("kind") == "uuid": return str(uuid.uuid4())
    if a.get("kind") == "coin": return secrets.choice(["Орёл", "Решка"])
    lo, hi = int(a.get("min", 1)), int(a.get("max", 100)); return str(lo + secrets.randbelow(hi - lo + 1))
