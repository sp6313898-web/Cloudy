import math
TOOLS = [
    {"name": "geo_distance", "description": "Расстояние по большому кругу (км, мили) и азимут между двумя точками (широта, долгота в градусах).",
     "parameters": {"type": "object", "properties": {"lat1": {"type": "number"}, "lon1": {"type": "number"}, "lat2": {"type": "number"}, "lon2": {"type": "number"}}, "required": ["lat1", "lon1", "lat2", "lon2"]}},
    {"name": "coord_convert", "description": "Перевод координат: десятичные градусы в градусы-минуты-секунды.",
     "parameters": {"type": "object", "properties": {"degrees": {"type": "number"}}, "required": ["degrees"]}}]


def run(name, a, ctx):
    if name == "coord_convert":
        d = float(a["degrees"]); s = abs(d) * 3600; return f"{int(s // 3600)}° {int(s % 3600 // 60)}' {s % 60:.2f}\"" + (" (отрицательная)" if d < 0 else "")
    p1, l1, p2, l2 = (math.radians(float(a[k])) for k in ("lat1", "lon1", "lat2", "lon2")); dp, dl = p2 - p1, l2 - l1
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2; km = 2 * 6371.0088 * math.asin(math.sqrt(h))
    az = (math.degrees(math.atan2(math.sin(dl) * math.cos(p2), math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl))) + 360) % 360
    return f"{km:,.1f} км ({km * 0.621371:,.1f} миль); начальный азимут {az:.1f}°"
