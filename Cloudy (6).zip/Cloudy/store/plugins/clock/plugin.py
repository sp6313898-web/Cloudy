import datetime
TOOLS = [
    {"name": "now", "description": "Текущие дата, время и день недели на компьютере пользователя.",
     "parameters": {"type": "object", "properties": {}}},
    {"name": "days_between", "description": "Сколько дней между двумя датами (формат ГГГГ-ММ-ДД).",
     "parameters": {"type": "object", "properties": {"a": {"type": "string"}, "b": {"type": "string"}}, "required": ["a", "b"]}},
]


def run(name, args, ctx):
    if name == "now":
        return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S, %A")
    a = datetime.date.fromisoformat(args["a"]); b = datetime.date.fromisoformat(args["b"])
    return f"{(b - a).days} дн."
