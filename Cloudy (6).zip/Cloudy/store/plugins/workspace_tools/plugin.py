import collections, hashlib, re
from pathlib import Path
SKIP = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".idea", ".vscode"}
TOOLS = [
    {"name": "loc_stats", "description": "Сколько строк кода в рабочей папке по типам файлов.", "parameters": {"type": "object", "properties": {}}},
    {"name": "find_todos", "description": "Найти TODO / FIXME / HACK / XXX в файлах рабочей папки.", "parameters": {"type": "object", "properties": {}}},
    {"name": "large_files", "description": "Самые большие файлы в рабочей папке.", "parameters": {"type": "object", "properties": {"count": {"type": "integer"}}}},
    {"name": "file_hash", "description": "SHA-256 файла из рабочей папки.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}]


def files(root):
    n = 0
    for f in root.rglob("*"):
        if f.is_file() and not any(x in SKIP or x.startswith(".git") for x in f.relative_to(root).parts):
            yield f; n += 1
            if n > 20000: return


def run(name, a, ctx):
    root = Path(ctx["workspace"]).resolve()
    if name == "file_hash":
        p = (root / a["path"]).resolve(); p.relative_to(root); h = hashlib.sha256()
        with open(p, "rb") as fh:
            for ch in iter(lambda: fh.read(1 << 20), b""): h.update(ch)
        return h.hexdigest()
    if name == "large_files":
        fs = sorted(files(root), key=lambda f: -f.stat().st_size)[:max(1, min(int(a.get("count") or 10), 50))]
        return "\n".join(f"{f.stat().st_size / 1024:10.1f} КБ  {f.relative_to(root).as_posix()}" for f in fs) or "Файлов нет"
    if name == "loc_stats":
        c = collections.Counter(); fc = collections.Counter()
        for f in files(root):
            if f.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".zip", ".exe", ".dll", ".pdf", ".ico", ".bin", ".mp4", ".mp3"} or f.stat().st_size > 2_000_000: continue
            try: n = sum(1 for _ in open(f, encoding="utf-8", errors="ignore"))
            except Exception: continue
            c[f.suffix.lower() or "(без)"] += n; fc[f.suffix.lower() or "(без)"] += 1
        return "\n".join(f"{k:8} {v:8} строк  ({fc[k]} файлов)" for k, v in c.most_common(15)) + f"\nВсего: {sum(c.values())} строк" if c else "Файлов нет"
    rx = re.compile(r"\b(TODO|FIXME|HACK|XXX)\b[:\s]*(.*)"); out = []
    for f in files(root):
        if f.stat().st_size > 1_000_000: continue
        try:
            for i, l in enumerate(open(f, encoding="utf-8").read().splitlines(), 1):
                m = rx.search(l)
                if m: out.append(f"{f.relative_to(root).as_posix()}:{i}: {m[1]} {m[2][:100]}")
        except Exception: pass
        if len(out) >= 100: break
    return "\n".join(out) or "TODO не найдено"
