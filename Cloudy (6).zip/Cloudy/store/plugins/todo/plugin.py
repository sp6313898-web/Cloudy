import json
from pathlib import Path
TOOLS = [{"name": "tasks", "description": "Список задач пользователя (хранится на компьютере). action: add (text, due), list, done (id), delete (id), clear_done.",
          "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["add", "list", "done", "delete", "clear_done"]}, "text": {"type": "string"}, "due": {"type": "string"}, "id": {"type": "integer"}}, "required": ["action"]}}]


def run(name, a, ctx):
    f = Path(ctx["data"]) / "tasks.json"
    try: d = json.loads(f.read_text("utf-8"))
    except Exception: d = {"next": 1, "items": []}
    act = a["action"]
    if act == "add": d["items"].append({"id": d["next"], "text": a.get("text", ""), "due": a.get("due", ""), "done": False}); d["next"] += 1; res = f"Задача #{d['next'] - 1} добавлена"
    elif act == "done":
        for x in d["items"]:
            if x["id"] == a.get("id"): x["done"] = True
        res = "Отмечено выполненной"
    elif act == "delete": d["items"] = [x for x in d["items"] if x["id"] != a.get("id")]; res = "Удалено"
    elif act == "clear_done": d["items"] = [x for x in d["items"] if not x["done"]]; res = "Выполненные убраны"
    else: res = None
    f.write_text(json.dumps(d, ensure_ascii=False), "utf-8")
    if res: return res
    return "\n".join(f"[{'x' if x['done'] else ' '}] #{x['id']} {x['text']}" + (f" (до {x['due']})" if x["due"] else "") for x in d["items"]) or "Задач нет"
