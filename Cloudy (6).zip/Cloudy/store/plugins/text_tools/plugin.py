import re, collections
OPS = ["upper", "lower", "title", "slugify", "snake_case", "camel_case", "kebab_case", "sort_lines", "unique_lines", "reverse_lines", "trim_lines", "remove_blank_lines", "number_lines"]
TOOLS = [
    {"name": "text_stats", "description": "Статистика текста: символы, слова, предложения, время чтения, примерное число токенов, частые слова.",
     "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}},
    {"name": "text_transform", "description": "Преобразовать текст: " + ", ".join(OPS) + ".",
     "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "op": {"type": "string", "enum": OPS}}, "required": ["text", "op"]}}]
TR = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя", ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "f", "h", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]))


def words(t): return re.findall(r"[A-Za-zА-Яа-яЁё0-9]+", t)


def run(name, a, ctx):
    t = a["text"]
    if name == "text_stats":
        w = words(t); nosp = len(re.sub(r"\s", "", t)); top = collections.Counter(x.lower() for x in w if len(x) > 3).most_common(8)
        sents = [s for s in re.split(r"[.!?…]+\s+|\n", t) if s.strip()]
        return (f"Символов: {len(t)} (без пробелов {nosp}); слов: {len(w)}; строк: {len(t.splitlines())}; предложений: {len(sents)}\n"
                f"Время чтения: ~{max(1, round(len(w) / 180))} мин; токенов (оценка): ~{round(len(t) / 3.6)}\n"
                f"Частые слова: " + ", ".join(f"{k} ({v})" for k, v in top))
    op, L = a["op"], t.splitlines()
    if op == "upper": return t.upper()
    if op == "lower": return t.lower()
    if op == "title": return t.title()
    if op in ("slugify", "kebab_case", "snake_case", "camel_case"):
        w = [x.lower() for x in words("".join(TR.get(c, c) if c.lower() in TR else c for c in t.lower()))]
        return {"slugify": "-".join(w), "kebab_case": "-".join(w), "snake_case": "_".join(w), "camel_case": (w[0] + "".join(x.title() for x in w[1:])) if w else ""}[op]
    if op == "sort_lines": return "\n".join(sorted(L, key=str.lower))
    if op == "unique_lines": return "\n".join(dict.fromkeys(L))
    if op == "reverse_lines": return "\n".join(reversed(L))
    if op == "trim_lines": return "\n".join(x.strip() for x in L)
    if op == "remove_blank_lines": return "\n".join(x for x in L if x.strip())
    if op == "number_lines": return "\n".join(f"{i}. {x}" for i, x in enumerate(L, 1))
    return "Неизвестная операция"
