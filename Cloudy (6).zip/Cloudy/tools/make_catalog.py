"""Пересобрать store/catalog.json после изменения или добавления плагинов:  python tools/make_catalog.py"""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.plugins import folder_hash

root = Path(__file__).resolve().parent.parent / "store"
cat = []
for d in sorted((root / "plugins").iterdir()):
    m = json.loads((d / "manifest.json").read_text("utf-8"))
    cat.append({"id": m["id"], "name": m["name"], "version": m["version"], "kind": m["kind"],
                "description": m["description"], "category": m.get("category", "Утилиты"), "name_en": m.get("name_en", ""), "description_en": m.get("description_en", ""), "permissions": m.get("permissions", []),
                "sha256": folder_hash(d)})
(root / "catalog.json").write_text(json.dumps(cat, ensure_ascii=False, indent=2), "utf-8")
print("Плагинов в каталоге:", len(cat))
