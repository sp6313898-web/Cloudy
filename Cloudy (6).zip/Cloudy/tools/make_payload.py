"""Упаковывает собранную программу (dist/Cloudy) в installer/payload.zip и пишет installer/version.txt. Вызывается из build_exe.bat."""
import sys, zipfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))
from app.version import VERSION

src = root / "dist" / "Cloudy"
if not (src / "Cloudy.exe").exists():
    sys.exit("Не найден dist\\Cloudy\\Cloudy.exe — сначала должна пройти сборка программы.")
out = root / "installer" / "payload.zip"
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for f in sorted(src.rglob("*")):
        z.write(f, f.relative_to(src).as_posix())
with zipfile.ZipFile(out, "a", zipfile.ZIP_DEFLATED) as z:      # лицензия лежит рядом с Cloudy.exe
    for name in ("LICENSE.txt", "THIRD_PARTY_NOTICES.txt"):
        if (root / name).exists(): z.write(root / name, name)
(root / "installer" / "version.txt").write_text(VERSION, "utf-8")
print("payload.zip: %.0f МБ, версия %s" % (out.stat().st_size / 1048576, VERSION))
