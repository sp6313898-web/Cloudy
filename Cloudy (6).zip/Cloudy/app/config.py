import json, os, sys
from pathlib import Path

from . import presets

APP = "Cloudy"


def base_dir() -> Path:
    """Папка с ресурсами (store/) — и в разработке, и внутри EXE."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


DATA = Path(os.environ.get("APPDATA", str(Path.home()))) / APP
for _d in (DATA, DATA / "plugins", DATA / "chats"):
    _d.mkdir(parents=True, exist_ok=True)

CFG_FILE = DATA / "settings.json"
DEFAULTS = {
    "providers": presets.all_providers(),
    "removed": [],
    "fallback_auto": True,
    "web": True,
    "search_url": "",
    "memory_on": True,
    "tray": {"close": False, "hotkey": True},
    "onboarded": False,
    "mcp": {"on": False, "servers": []},
    "computer": {"on": False, "confirm": "input", "minimize": True},
    "model": "auto",
    "lang": "ru",
    "collab": {"on": False, "models": [], "lead": ""},
    "workspace": str(Path.home() / "CloudyWorkspace"),
    "theme": "light",
    "agent": True,
    "require_approval": True,
    "max_steps": 20,
    "vision_model": "",
    "tts_auto": False,
}


def load() -> dict:
    cfg = json.loads(json.dumps(DEFAULTS))
    raw = {}
    try:
        raw = json.loads(CFG_FILE.read_text("utf-8"))
        cfg.update(raw)
    except Exception:
        pass
    if raw and "providers" not in raw:  # миграция со старой версии (один DeepSeek + vision)
        prov = [{"id": "deepseek", "name": "DeepSeek", "base_url": raw.get("base_url", "https://api.deepseek.com"),
                 "api_key": raw.get("api_key", "")}]
        old = raw.get("model", "deepseek-chat")
        cfg["model"] = old if old == "auto" or "|" in old else "deepseek|" + old
        if raw.get("vision_key"):
            prov.append({"id": "vision", "name": "Vision", "base_url": raw.get("vision_base_url") or "https://api.openai.com/v1",
                         "api_key": raw["vision_key"]})
            cfg["vision_model"] = "vision|" + raw.get("vision_model", "")
        cfg["providers"] = prov
    have = {p["id"]: p for p in cfg["providers"]}
    for pid, pr in presets.BY_ID.items():            # подмешиваем все бесплатные провайдеры (кроме удалённых вручную)
        full = presets.provider(pr)
        if pid in have:
            for k, v in full.items(): have[pid].setdefault(k, v)
        elif pid not in cfg.get("removed", []): cfg["providers"].append(full)
    for p in cfg["providers"]:                       # старый адрес GitHub Models больше не открывается у многих
        if "models.inference.ai.azure.com" in (p.get("base_url") or "") + (p.get("chat_url") or ""):
            p["base_url"] = "https://models.github.ai/inference"; p["chat_url"] = ""; p["models_url"] = "https://models.github.ai/catalog/models"
    Path(cfg["workspace"]).mkdir(parents=True, exist_ok=True)
    return cfg


def save(cfg: dict):
    CFG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")
