import json, time, uuid
from .config import DATA

CH = DATA / "chats"
PR = DATA / "projects"
PR.mkdir(exist_ok=True)


def new_chat(project=None) -> dict:
    return {"id": uuid.uuid4().hex[:12], "title": "Новый чат", "created": time.time(), "messages": [],
            "artifacts": {}, "project": project}


def save_chat(chat: dict):
    slim = dict(chat, messages=[dict(m, content="[скриншот]") if m.get("_screen") else m for m in chat["messages"]])
    (CH / f"{chat['id']}.json").write_text(json.dumps(slim, ensure_ascii=False), "utf-8")


def list_chats() -> list:
    out = []
    for f in CH.glob("*.json"):
        try:
            c = json.loads(f.read_text("utf-8")); c.setdefault("artifacts", {}); c.setdefault("project", None); out.append(c)
        except Exception:
            pass
    return sorted(out, key=lambda c: c.get("created", 0), reverse=True)


def delete_chat(cid: str):
    f = CH / f"{cid}.json"
    if f.exists(): f.unlink()


def new_project() -> dict:
    return {"id": uuid.uuid4().hex[:10], "name": "Новый проект", "instructions": "", "files": [], "workspace": ""}


def save_project(p: dict):
    (PR / f"{p['id']}.json").write_text(json.dumps(p, ensure_ascii=False), "utf-8")


def list_projects() -> list:
    out = []
    for f in sorted(PR.glob("*.json")):
        try: out.append(json.loads(f.read_text("utf-8")))
        except Exception: pass
    return out


def get_project(pid):
    return next((p for p in list_projects() if p["id"] == pid), None) if pid else None


def delete_project(pid: str):
    f = PR / f"{pid}.json"
    if f.exists(): f.unlink()


def project_context(p: dict) -> str:
    """Инструкции проекта + текст его файлов знаний (с ограничениями по размеру)."""
    parts, total = [], 0
    if p.get("instructions"):
        parts.append("Инструкции проекта «%s»:\n%s" % (p["name"], p["instructions"]))
    for f in p.get("files", []):
        try:
            t = open(f, encoding="utf-8", errors="replace").read()[:40000]
        except Exception:
            continue
        if total + len(t) > 120000: break
        total += len(t); parts.append(f"### Файл проекта: {f.replace(chr(92), '/').split('/')[-1]}\n```\n{t}\n```")
    return "\n\n".join(parts)


def chat_text(c) -> str:
    """Весь текст чата в нижнем регистре — для поиска в боковой панели."""
    out = []
    for m in c.get("messages", []):
        if m.get("_screen"): continue
        t = m.get("_text") or m.get("content")
        if isinstance(t, list): t = " ".join(p.get("text", "") for p in t if p.get("type") == "text")
        if isinstance(t, str): out.append(t)
    return "\n".join(out).lower()
