"""Любые OpenAI-совместимые API. Авто: реальная проверка моделей запросами, гонка кандидатов, память о рабочих,
перерывы для сбойных, переход к следующей модели при ошибке."""
import json, queue, re, threading, time
import requests
from . import api
from .config import DATA
from .i18n import T

CACHE_F, STATS_F = DATA / "models_cache.json", DATA / "model_stats.json"
LOCK = threading.Lock()
DAY = 86400
BAD = re.compile(r"embed|whisper|tts|dall|image|moderation|rerank|audio|transcri|realtime|guard|speech|diffusion|sdxl|flux|stable|ocr|search-preview|safety|classif", re.I)
VISION = re.compile(r"gpt-4o|gpt-4\.1|gpt-5|o4|claude|gemini|vision|llava|pixtral|-vl|qwen.*vl|minicpm-v|gemma-3|llama-4|llama-3\.2-(11|90)b", re.I)
SMALL = re.compile(r"mini|nano|small|lite|tiny|flash-8b|(^|[^0-9])(1|3|7|8)b\b", re.I)
REASON = re.compile(r"r1|reason|think|qwq|(^|[^a-z])o[13]([^a-z]|$)", re.I)
PREF = [("gpt-5", 97), ("deepseek-chat", 96), ("deepseek-v3", 95), ("gpt-4.1", 95), ("claude", 95), ("gpt-4o", 94), ("gemini-2", 93),
        ("gemini", 90), ("qwen3", 90), ("qwen", 86), ("llama-3.3", 90), ("llama-4", 90), ("llama-3.1", 84), ("gpt-oss", 88),
        ("mistral-large", 86), ("glm-4", 84), ("grok", 85), ("deepseek", 75), ("mistral", 76), ("command-a", 82), ("command-r", 78),
        ("hunyuan", 70), ("gpt-4", 80), ("llama", 70), ("gpt-3.5", 60)]


def _jload(f, d):
    try: return json.loads(f.read_text("utf-8"))
    except Exception: return d


def _jsave(f, d): f.write_text(json.dumps(d), "utf-8")


def is_local(u): return bool(re.search(r"localhost|127\.0\.0\.1|192\.168\.|\[::1\]", u or ""))


def usable(p):
    return bool(p.get("base_url")) and bool(p.get("api_key") or p.get("nokey") or p.get("default_key") or is_local(p["base_url"]))


def split(key): pid, _, m = key.partition("|"); return pid, m


def _prov(cfg, key): return next((x for x in cfg["providers"] if x["id"] == split(key)[0]), None)


def label(cfg, key):
    p = _prov(cfg, key); m = split(key)[1]
    return f"{m} · {p['name']}" if p else m


# ---------- список моделей
def fetch_models(p) -> list:
    r = requests.get(api.models_url(p), headers=api.headers(p), timeout=20)
    r.raise_for_status(); j = r.json()
    items = j.get("data") if isinstance(j, dict) else j
    if items is None and isinstance(j, dict): items = j.get("models") or j.get("result") or []
    ids = []
    for x in items or []:
        if isinstance(x, dict):
            i = str(x.get("id") or x.get("name") or "")
            if p.get("free_only"):
                pr = x.get("pricing") or {}
                zero = bool(pr) and str(pr.get("prompt", "1")) in ("0", "0.0") and str(pr.get("completion", "1")) in ("0", "0.0")
                if not (i.endswith(":free") or zero): continue
        else: i = str(x)
        i = i[7:] if i.startswith("models/") else i
        if i: ids.append(i)
    return sorted(set(ids))


def set_cache(pid, models, failed=False):
    with LOCK:
        c = _jload(CACHE_F, {}); old = c.get(pid) if isinstance(c.get(pid), dict) else {}
        c[pid] = {"ts": time.time(), "models": models or old.get("models", []), "failed": failed}; _jsave(CACHE_F, c)


def models_of(p):
    e = _jload(CACHE_F, {}).get(p["id"])
    if isinstance(e, list) and e: return e
    if isinstance(e, dict) and e.get("models"): return e["models"]
    return p.get("fallback") or []


def _stale(p):
    e = _jload(CACHE_F, {}).get(p["id"])
    if not isinstance(e, dict): return True
    return time.time() - e.get("ts", 0) > (1800 if e.get("failed") else DAY)


def ensure_models(cfg, force=False, timeout=14):
    ps = [p for p in cfg["providers"] if usable(p) and (force or _stale(p))]

    def work(p):
        try: set_cache(p["id"], fetch_models(p))
        except Exception: set_cache(p["id"], [], True)
    ts = [threading.Thread(target=work, args=(p,), daemon=True) for p in ps]
    for t in ts: t.start()
    end = time.time() + timeout
    for t in ts: t.join(max(0.0, end - time.time()))


def all_models(cfg) -> list:
    return [{"key": f"{p['id']}|{m}", "pid": p["id"], "pname": p["name"], "model": m, "nokey": bool(p.get("nokey"))}
            for p in cfg["providers"] if usable(p) for m in models_of(p)]


# ---------- статистика
def stats(): return _jload(STATS_F, {})


def _friendly(ex):
    """Понятное сообщение вместо длинных ошибок библиотеки requests."""
    t = str(ex)
    if isinstance(ex, requests.exceptions.ConnectionError):
        m = re.search(r"host='([^']+)'", t); host = m.group(1) if m else "?"
        if re.search(r"NameResolution|getaddrinfo|Name or service|11001|Errno -[23]", t): return T("Не удаётся найти адрес {host}: проверьте интернет, VPN или DNS.").format(host=host)
        return T("Нет соединения с {host}.").format(host=host)
    if isinstance(ex, requests.exceptions.Timeout): return T("Сервер не ответил вовремя.")
    return t


def _is_conn(ex): return isinstance(ex, (requests.exceptions.ConnectionError, requests.exceptions.Timeout))


def record(key, ok, lat=0.0, err="", status=0, conn=False):
    with LOCK:
        st = _jload(STATS_F, {}); now = time.time()
        s = st.setdefault(key, {"ok": 0, "fail": 0, "lat": 0, "last_ok": 0, "last_fail": 0, "cool": 0, "err": ""})
        if ok:
            s["lat"] = (s["lat"] * s["ok"] + lat) / (s["ok"] + 1); s["ok"] += 1; s["last_ok"] = now; s["cool"] = 0; s["err"] = ""
        else:
            s["fail"] += 1; s["last_fail"] = now; s["err"] = err[:160]
            s["cool"] = now + (300 if conn else {402: DAY, 403: 6 * 3600, 404: 6 * 3600, 429: 180}.get(status, 600))
            if status == 401: st.setdefault("__prov__", {})[split(key)[0]] = now + 1800
            if conn: st.setdefault("__prov__", {})[split(key)[0]] = now + 300     # адрес не открывается — весь провайдер на паузу
        _jsave(STATS_F, st)


def set_caps(key, **caps):
    with LOCK:
        st = _jload(STATS_F, {}); s = st.setdefault(key, {"ok": 0, "fail": 0, "lat": 0, "last_ok": 0, "last_fail": 0, "cool": 0, "err": ""})
        s.update(caps); _jsave(STATS_F, st)


def caps_ok(s, need):
    """Нужные возможности подтверждены проверкой (True), а не только угаданы по названию."""
    return all((s or {}).get(c) is True for c, v in (need or {}).items() if v)


def is_good(s, now=None):
    now = now or time.time()
    return bool(s) and s.get("ok", 0) > 0 and s.get("cool", 0) <= now and s["ok"] / (s["ok"] + s["fail"]) >= 0.5


def score(model):
    m = model.lower(); sc = next((v for k, v in PREF if k in m), 50)
    if SMALL.search(m): sc -= 12
    if REASON.search(m): sc -= 6
    if re.search(r"preview|exp|beta", m): sc -= 3
    z = re.search(r"(\d+)b", m)
    if z: sc += min(int(z.group(1)) / 12, 8)
    return sc


def rows(cfg) -> list:
    """Все модели со статусом: ok / fail / new — для окон выбора."""
    st, now = stats(), time.time(); out = []
    for m in all_models(cfg):
        if BAD.search(m["model"]): continue
        s = st.get(m["key"]); free = m["model"].endswith(":free") or m["model"].endswith("-free") or m["nokey"]
        if is_good(s, now): rank, state, ms = 0, "ok", int(s["lat"] * 1000)
        elif s and s.get("fail") and s.get("ok", 0) == 0: rank, state, ms = 2, "fail", 0
        elif s and s.get("cool", 0) > now: rank, state, ms = 2, "fail", 0
        else: rank, state, ms = 1, "new", 0
        out.append({**m, "state": state, "ms": ms, "rank": rank, "free": free, "err": (s or {}).get("err", ""),
                    "vision": (s or {}).get("vision"), "tools": (s or {}).get("tools")})
    out.sort(key=lambda r: (r["rank"], r["ms"] if r["rank"] == 0 else -score(r["model"])))
    return out


def provider_stats(cfg) -> dict:
    """По провайдерам: сколько рабочих моделей, сколько из них проверено на MCP (инструменты) и на картинки."""
    out = {}
    for r in rows(cfg):
        d = out.setdefault(r["pid"], {"ok": 0, "mcp": 0, "vision": 0})
        if r["state"] == "ok":
            d["ok"] += 1; d["mcp"] += 1 if r.get("tools") else 0; d["vision"] += 1 if r.get("vision") else 0
    return out


def working_count(cfg) -> int: return sum(1 for r in rows(cfg) if r["state"] == "ok")


def capable_count(cfg, need) -> int:
    st = stats(); return sum(1 for r in rows(cfg) if r["state"] == "ok" and caps_ok(st.get(r["key"]), need))


def candidates(cfg, need=None) -> list:
    need = need or {}; st, now = stats(), time.time(); pb = st.get("__prov__", {}); good, fresh, bad = [], [], []
    for m in all_models(cfg):
        s = st.get(m["key"])
        if BAD.search(m["model"]) or (need.get("vision") and not VISION.search(m["model"])): continue
        if (need.get("vision") and (s or {}).get("vision") is False) or (need.get("tools") and (s or {}).get("tools") is False): continue
        if pb.get(m["pid"], 0) > now or (s and s.get("cool", 0) > now): bad.append(m["key"])
        elif is_good(s, now):
            q = score(m["model"]) + 8 * s["ok"] / (s["ok"] + s["fail"]) - min(s["lat"], 10) * 1.5 + (12 if caps_ok(s, need) and need else 0); good.append((q, m["key"]))
        else: fresh.append(m["key"])
    good.sort(reverse=True); fresh.sort(key=lambda k: -(score(split(k)[1]) + (12 if caps_ok(st.get(k), need) and need else 0)))
    return [k for _, k in good] + fresh + bad


# ---------- проверка и гонка
def probe(cfg, key, need=None):
    """Мини-запрос; при need ещё проверяет, что модель умеет вызывать инструменты и/или видит картинки."""
    p = _prov(cfg, key); model = split(key)[1]; t0 = time.time()
    try:
        api.chat_once(p, model); lat = time.time() - t0; record(key, True, lat)
        have = stats().get(key, {})
        if need and need.get("tools") and have.get("tools") is not True:
            ok = api.probe_tools(p, model); set_caps(key, tools=ok)
            if not ok: return False, 0, "no tools"
        if need and need.get("vision") and have.get("vision") is not True:
            ok = api.probe_vision(p, model); set_caps(key, vision=ok)
            if not ok: return False, 0, "no vision"
        return True, lat, ""
    except Exception as ex:
        record(key, False, err=_friendly(ex), status=getattr(ex, "status", 0), conn=_is_conn(ex)); return False, 0, _friendly(ex)


def race(cfg, keys, timeout=30, extra=2.5, errs=None, need=None):
    """Проверяет модели параллельно; через extra секунд после первой рабочей возвращает все ответившие (лучшие первыми)."""
    q = queue.Queue()
    for k in keys: threading.Thread(target=lambda k=k: q.put((k,) + probe(cfg, k, need)), daemon=True).start()
    ok, got, first, end = [], 0, None, time.time() + timeout
    while got < len(keys) and time.time() < end:
        if first and time.time() - first > extra: break
        try: k, good, lat, err = q.get(timeout=0.3)
        except queue.Empty: continue
        got += 1
        if good: ok.append((k, lat)); first = first or time.time()
        elif errs is not None: errs.append((k, err))
    ok.sort(key=lambda x: (-score(split(x[0])[1]), x[1]))
    return [k for k, _ in ok]


def scan(cfg, cb=None, per=5, stop=lambda: False, only=None, cap=90, need=None):
    """Проверка лучших непроверенных моделей каждого провайдера (фон)."""
    ensure_models(cfg); st, now = stats(), time.time(); tasks = []
    for p in cfg["providers"]:
        if not usable(p) or (only and p["id"] != only): continue
        ms = sorted((m for m in models_of(p) if not BAD.search(m) and not (need and need.get("vision") and not VISION.search(m))), key=lambda m: -score(m))
        todo = [f"{p['id']}|{m}" for m in ms if not (is_good(st.get(f"{p['id']}|{m}"), now) and (not need or caps_ok(st.get(f"{p['id']}|{m}"), need)))
                and (st.get(f"{p['id']}|{m}") or {}).get("tools") is not False][:per]
        tasks += todo
    tasks = tasks[:cap]; total = len(tasks); q = queue.Queue(); sem = threading.Semaphore(12)

    def work(k):
        with sem: q.put(probe(cfg, k, need)[0] if not stop() else False)
    for k in tasks: threading.Thread(target=work, args=(k,), daemon=True).start()
    done = okc = 0
    while done < total and not stop():
        try: good = q.get(timeout=0.5)
        except queue.Empty: continue
        done += 1; okc += 1 if good else 0
        if cb: cb(done, total, okc)
    return capable_count(cfg, need) if need else working_count(cfg)


# ---------- запуск
class _Early(Exception):
    pass


def _run(cfg, key, msgs, tools, fallback, timeout, strict=False):
    """strict: инструменты обязательны (MCP / управление компьютером) — без них не продолжаем, а берём другую модель."""
    p = _prov(cfg, key)
    if not p: raise _Early(T("Нет доступных моделей. Откройте Настройки, раздел «Провайдеры API», добавьте API и ключ.")) if fallback else RuntimeError(T("Нет доступных моделей. Откройте Настройки, раздел «Провайдеры API», добавьте API и ключ."))
    model, t0, started, use_tools, lab, ttft = split(key)[1], time.time(), False, tools, label(cfg, key), 0.0
    for attempt in range(2):
        try:
            for ev in api.stream(p, model, msgs, use_tools, timeout):
                if not started:
                    started, ttft = True, time.time() - t0
                    yield "model", lab + (" · " + T("без инструментов") if tools and not use_tools else "")
                yield ev
            record(key, True, ttft or time.time() - t0); return
        except Exception as ex:
            st = getattr(ex, "status", 0); msg = _friendly(ex)
            if (not strict and not started and use_tools and attempt == 0
                    and (st in (400, 404, 413, 422, 500) or re.search(r"tool|function|context|too (long|large)|max.*tokens", str(ex), re.I))):
                use_tools = None; continue
            if strict and st in (400, 404, 422) and re.search(r"tool|function", str(ex), re.I): set_caps(key, tools=False)
            record(key, False, err=msg, status=st, conn=_is_conn(ex))
            if not started and fallback: raise _Early(msg)
            raise RuntimeError(msg) from ex


def stream(cfg, key, msgs, tools, need=None):
    """События: ("model", ярлык) ("text", s) ("reasoning", s) ("tools", [...]) ("notice", текст).  key == "auto" — самая рабочая модель.
    Выбранная вручную модель при сбое (до первого слова) уступает место «Авто» — если это не отключено в настройках."""
    need = {k: v for k, v in (need or {}).items() if v}; strict = bool(need.get("tools")); allow = cfg.get("fallback_auto", True)
    if key and key != "auto":
        s0 = stats().get(key) or {}
        if any(s0.get(c) is False for c in need):                    # проверено: модель не умеет нужного (инструменты / картинки)
            why = T("модель не поддерживает инструменты или картинки")
        else:
            try: yield from _run(cfg, key, msgs, tools, allow, (15, 120), strict); return
            except _Early as e: why = str(e)
        if not allow: raise RuntimeError(why)
        yield "notice", T("Выбранная модель недоступна ({err}). Перехожу на «Авто».").format(err=why[:100])
    ensure_models(cfg, timeout=10)
    cands = [k for k in candidates(cfg, need) if k != key]
    if not cands:
        raise RuntimeError(T("Нужна модель с поддержкой картинок: добавьте провайдера с такой моделью (OpenAI, Gemini, OpenRouter и т.п.).")
                           if need.get("vision") else T("Нет доступных моделей. Откройте Настройки, раздел «Провайдеры API», добавьте API и ключ."))
    st, now = stats(), time.time(); good = [k for k in cands if is_good(st.get(k), now) and caps_ok(st.get(k), need)]
    rest = [k for k in cands if k not in good]; errs, tried = [], set()

    def batches():
        if good: yield good[:3]
        if rest[:14]: yield race(cfg, rest[:14], errs=errs, need=need)
        if rest[14:40]: yield race(cfg, rest[14:40], errs=errs, need=need)
    for batch in batches():
        for k in batch:
            if k in tried: continue
            tried.add(k)
            try: yield from _run(cfg, k, msgs, tools, True, (10, 60), strict); return
            except _Early as e: errs.append((k, str(e)))
    lines = "\n".join(f"- {split(k)[1]}: {e[:110]}" for k, e in errs[:5])
    head = T("Авто: ни одна подходящая для MCP модель не ответила.") if strict else T("Авто: ни одна модель не ответила.")
    raise RuntimeError(head + "\n" + lines + "\n" + T("Проверьте ключи в «Провайдерах API» и нажмите «Проверить модели»."))
