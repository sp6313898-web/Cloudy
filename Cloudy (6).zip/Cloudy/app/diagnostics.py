"""Диагностика для поддержки: сеть до провайдеров, число рабочих и MCP-моделей, режимы, ошибки MCP, хвост журнала сбоев."""
import platform, socket, sys
from urllib.parse import urlparse
from . import router, winput, mcp, config
from .i18n import T
from .version import VERSION


def report(cfg) -> str:
    L = [f"Cloudy {VERSION}", f"{platform.platform()} / Python {sys.version.split()[0]}" + (" / EXE" if getattr(sys, "frozen", False) else ""), "", T("Провайдеры:")]
    pst = router.provider_stats(cfg)
    for p in sorted(cfg["providers"], key=lambda p: (not router.usable(p), p["name"])):
        if not router.usable(p): continue
        host = urlparse(p.get("chat_url") or p["base_url"]).hostname or "?"
        try: socket.getaddrinfo(host, 443); net = "OK"
        except Exception: net = T("адрес не открывается (интернет, VPN или DNS)")
        d = pst.get(p["id"], {"ok": 0, "mcp": 0, "vision": 0})
        L.append(f"  {p['name']}: {host} - {net}; " + T("рабочих: {a}, MCP: {b}, картинки: {c}").format(a=d["ok"], b=d["mcp"], c=d["vision"]))
    L += ["", T("Рабочих моделей: {n}").format(n=router.working_count(cfg)), T("Подходящих для MCP: {n}").format(n=router.capable_count(cfg, {"tools": True})),
          T("Подходящих для управления экраном: {n}").format(n=router.capable_count(cfg, {"vision": True, "tools": True})), "",
          T("Модель: {m}").format(m=cfg.get("model")), T("Модель для картинок: {m}").format(m=cfg.get("vision_model") or T("Авто (подходящая)")),
          T("Переход на «Авто» при сбое: {x}").format(x=T("да") if cfg.get("fallback_auto", True) else T("нет"))]
    m = cfg.get("mcp") or {}
    L.append("MCP: " + (T("включён") if m.get("on") else T("выключен")) + f" ({len(m.get('servers', []))})")
    for sid, err in mcp.MANAGER.errors.items(): L.append(f"  {sid}: {err[:160]}")
    L.append(T("Управление компьютером: {x}").format(x=T("доступно") if winput.available() else T("недоступно (нужны Windows, mss и Pillow)")))
    f = config.DATA / "crash.log"
    if f.exists() and f.stat().st_size:
        L += ["", T("Журнал сбоев (конец):"), f.read_text("utf-8", errors="replace")[-700:]]
    return "\n".join(L)
