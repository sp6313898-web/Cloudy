"""Долгая память Cloudy: короткие факты о вас хранятся только на этом компьютере и подмешиваются в каждый чат."""
import json, re, time, uuid
from .config import DATA

F = DATA / "memory.json"
SECRET = re.compile(r"(парол|password|passwd|token|токен|секрет|secret|api[ _-]?key|ключ api|cvv|cvc|iban|\b(?:\d[ -]?){13,19}\b|\bsk-[A-Za-z0-9]{10,})", re.I)


def _fn(name, desc, props, req):
    return {"type": "function", "function": {"name": name, "description": desc, "parameters": {"type": "object", "properties": props, "required": req}}}


SCHEMAS = [
    _fn("remember", "Запомнить устойчивый факт или предпочтение пользователя (имя, привычки, стиль ответов, проекты). Один короткий факт. Никаких паролей и платёжных данных.", {"fact": {"type": "string"}}, ["fact"]),
    _fn("forget", "Забыть факт из памяти (по тексту или id).", {"fact": {"type": "string"}}, ["fact"]),
    _fn("recall", "Показать всё, что сохранено в памяти.", {}, []),
]
NAMES = {"remember", "forget", "recall"}
PROMPT = ("Долгая память: если пользователь сообщает устойчивый факт о себе или просит запомнить — вызови remember (коротко, по одному факту). "
          "Не запоминай пароли, ключи, платёжные и другие чувствительные данные. Если просят забыть — forget.")


def load():
    try: return json.loads(F.read_text("utf-8"))
    except Exception: return []


def save(items): F.write_text(json.dumps(items[-200:], ensure_ascii=False, indent=1), "utf-8")


def add(text):
    t = " ".join((text or "").split())[:300]
    if len(t) < 3: return None, "Слишком коротко"
    if SECRET.search(t): return None, "Похоже на секретные данные — не сохраняю"
    items = load()
    for x in items:
        if x["text"].lower() == t.lower(): return x["id"], "Уже в памяти"
    i = uuid.uuid4().hex[:6]; items.append({"id": i, "text": t, "ts": time.strftime("%Y-%m-%d")}); save(items); return i, "Запомнено"


def remove(key):
    items, k = load(), (key or "").strip().lower()
    keep = [x for x in items if x["id"] != k and k not in x["text"].lower()]
    save(keep); return len(items) - len(keep)


def prompt(limit=2500):
    items = load()[-40:]
    if not items: return ""
    out, size = [], 0
    for x in reversed(items):
        size += len(x["text"]) + 3
        if size > limit: break
        out.append("- " + x["text"])
    return "Что известно о пользователе (долгая память):\n" + "\n".join(reversed(out))


def run(name, a):
    if name == "remember": return add(a.get("fact", ""))[1]
    if name == "forget": n = remove(a.get("fact", "")); return f"Забыто записей: {n}"
    return "\n".join(f"{x['id']}: {x['text']} ({x['ts']})" for x in load()) or "Память пуста"
