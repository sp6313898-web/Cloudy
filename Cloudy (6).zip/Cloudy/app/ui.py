import base64, json, os, tempfile, webbrowser
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QEvent, Signal, QBuffer, QByteArray, QIODevice, QSize, QSettings
from PySide6.QtGui import QKeySequence, QShortcut, QImage, QPixmap, QGuiApplication
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QScrollArea,
                               QPlainTextEdit, QFrame, QDialog, QLineEdit, QComboBox, QCheckBox, QFileDialog,
                               QMessageBox, QFormLayout, QSpinBox, QToolButton, QApplication, QStackedWidget,
                               QListWidget, QProgressDialog, QTextBrowser)
from . import config, storage, plugins, theme, widgets, icons, voice, i18n, router, presets, mcp, winput, threads
from .i18n import T
from .ui_models import ProvidersDialog, ModelPicker, CollabDialog, ScanThread
from .ui_mcp import MCPDialog
from .icons import set_ic
from PySide6.QtWidgets import QSystemTrayIcon, QMenu, QTabWidget, QInputDialog
from . import system, hotkey, memory, journal, exporter
from .ui_extra import MemoryDialog, JournalDialog, AboutDialog, OnboardingDialog, DiagDialog
from .widgets import Spark, MdView, Card, ArtifactCard, AttachChip, fade_in, alive, AICursor, AIBanner
from .agent import AgentWorker

try:
    os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")
    from PySide6.QtWebEngineWidgets import QWebEngineView
    HAVE_WEB = True
except Exception:
    HAVE_WEB = False

IMG_EXT = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}
EXT = {"html": ".html", "svg": ".svg", "markdown": ".md", "python": ".py", "javascript": ".js", "css": ".css",
       "json": ".json", "java": ".java", "cpp": ".cpp", "c": ".c", "csharp": ".cs", "go": ".go", "rust": ".rs"}
KIND = {"html": T("Веб-страница"), "svg": T("SVG-рисунок"), "markdown": T("Документ"), "code": T("Код")}


def load_attachment(path: str) -> dict:
    p = Path(path); name = p.name
    if p.suffix.lower() in IMG_EXT:
        img = QImage(str(p))
        if img.isNull(): raise ValueError(T("Не удалось открыть картинку."))
        if max(img.width(), img.height()) > 1568:
            img = img.scaled(1568, 1568, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.WriteOnly); img.save(buf, "JPEG", 85)
        return {"name": name, "kind": "image", "data": "data:image/jpeg;base64," + base64.b64encode(bytes(ba)).decode()}
    raw = p.read_bytes()[:300000]
    if b"\x00" in raw: raise ValueError(T("«{name}»: бинарные файлы не поддерживаются (только текст, код и картинки).").format(name=name))
    return {"name": name, "kind": "text", "data": raw.decode("utf-8", "replace")}


def build_user_message(text, atts):
    body = text
    for f in (a for a in atts if a["kind"] == "text"):
        body += f"\n\n[Файл: {f['name']}]\n```\n{f['data']}\n```"
    imgs = [a for a in atts if a["kind"] == "image"]
    content = body if not imgs else [{"type": "text", "text": body or T("Опиши изображение.")}] + \
        [{"type": "image_url", "image_url": {"url": i["data"]}} for i in imgs]
    return {"role": "user", "content": content, "_text": text, "_att": [{"name": a["name"], "kind": a["kind"]} for a in atts]}


class UserMsg(QWidget):
    def __init__(self, m):
        super().__init__()
        lay = QHBoxLayout(self); lay.setContentsMargins(0, 6, 0, 6)
        col = QVBoxLayout(); col.setSpacing(6); col.setAlignment(Qt.AlignRight)
        content = m["content"]
        if isinstance(content, list):
            for part in content:
                if part.get("type") == "image_url":
                    pm = QPixmap(); pm.loadFromData(base64.b64decode(part["image_url"]["url"].split(",", 1)[1]))
                    il = QLabel(); il.setPixmap(pm.scaledToHeight(150, Qt.SmoothTransformation)); col.addWidget(il, 0, Qt.AlignRight)
        for a in m.get("_att", []):
            if a["kind"] == "text": col.addWidget(AttachChip(a), 0, Qt.AlignRight); col.itemAt(col.count() - 1).widget().findChild(QToolButton).hide()
        text = m.get("_text", content if isinstance(content, str) else "")
        if text:
            lb = QLabel(text); lb.setObjectName("userBubble"); lb.setWordWrap(True)
            lb.setTextInteractionFlags(Qt.TextSelectableByMouse); lb.setMaximumWidth(680); col.addWidget(lb, 0, Qt.AlignRight)
        lay.addStretch(); lay.addLayout(col)


class AssistantMsg(QWidget):
    def __init__(self):
        super().__init__()
        self.open_cb = None; self.speak_cb = None; self.regen_cb = None; self.regen_btn = None
        root = QHBoxLayout(self); root.setContentsMargins(0, 6, 0, 6); root.setSpacing(12)
        self.spark = Spark(22); left = QVBoxLayout(); left.addWidget(self.spark); left.addStretch(); root.addLayout(left)
        self.col = QVBoxLayout(); self.col.setSpacing(8); root.addLayout(self.col, 1)
        self.text, self.full, self.view, self.think = "", "", None, None
        self.cards = {}; self.dirty = False; self.drafts = {}; self.model = ""
        self.timer = QTimer(self); self.timer.timeout.connect(self._flush); self.timer.start(60)

    def _flush(self):
        if self.dirty and self.view: self.view.set_md(self.text); self.dirty = False

    def set_running(self, on):
        self.spark.start() if on else self.spark.stop()
        if not on: self._flush()

    def add_text(self, s):
        if self.view is None:
            self.view = MdView(); self.col.addWidget(self.view); self.text = ""
        self.text += s; self.full += s; self.dirty = True

    def add_reasoning(self, s):
        if self.think is None:
            self.think = Card(T("Размышляю"), icon="layers"); self.col.addWidget(self.think); fade_in(self.think)
        self.think.add_body(s)

    def close_segment(self):
        self._flush(); self.view = None

    def add_tool(self, cid, name, args):
        self.close_segment()
        if name == "create_artifact":
            try: a = json.loads(args)
            except Exception: a = {}
            c = ArtifactCard(a.get("title", T("Артефакт")), T(KIND.get(a.get("type"), "Артефакт")))
            c.clicked.connect(lambda _, i=a.get("id"): self.open_cb and self.open_cb(i))
            self.col.addWidget(c); fade_in(c); self.cards[cid] = (c, name); return
        c = Card(name, args, "terminal"); self.col.addWidget(c); fade_in(c); self.cards[cid] = (c, name)

    def tool_done(self, cid, res):
        c, name = self.cards.get(cid, (None, None))
        if c is not None and name != "create_artifact":
            c.set_title(name, "check"); c.set_body(c.body.toPlainText() + T("\n\n--- результат ---\n") + res)

    def set_model(self, m): self.model = m

    def hide_regen(self):
        if self.regen_btn: self.regen_btn.hide()

    def draft_start(self, model):
        c = Card(T("Черновик: {model}").format(model=model), "", "network"); self.drafts[model] = c; self.col.addWidget(c); fade_in(c)

    def draft_text(self, model, s):
        if model in self.drafts: self.drafts[model].add_body(s)

    def draft_done(self, model, ok):
        if model in self.drafts: self.drafts[model].set_icon("check" if ok else "warn")

    def finish_actions(self, regen=False):
        if not self.full.strip(): return
        row = QHBoxLayout(); row.setSpacing(2)
        for ic, tip, fn in (("copy", T("Копировать"), lambda: QGuiApplication.clipboard().setText(self.full)),
                            ("speaker", T("Озвучить"), lambda: self.speak_cb and self.speak_cb(self.full))):
            b = QToolButton(); set_ic(b, ic, size=16); b.setToolTip(tip); b.clicked.connect(fn); row.addWidget(b)
        if regen and self.regen_cb:
            self.regen_btn = QToolButton(); set_ic(self.regen_btn, "refresh", size=16); self.regen_btn.setToolTip(T("Повторить ответ"))
            self.regen_btn.clicked.connect(self.regen_cb); row.addWidget(self.regen_btn)
        row.addStretch()
        if self.model:
            ml = QLabel(T("Ответила модель: {model}").format(model=self.model)); ml.setObjectName("sub"); row.addWidget(ml)
        self.col.addLayout(row)


class ChatView(QScrollArea):
    def __init__(self):
        super().__init__(); self.setWidgetResizable(True)
        self.inner = QWidget(); self.inner.setObjectName("scrollInner")
        outer = QHBoxLayout(self.inner); outer.setContentsMargins(20, 20, 20, 20)
        self.col = QVBoxLayout(); self.col.setSpacing(4)
        box = QWidget(); box.setMaximumWidth(780); box.setLayout(self.col)
        outer.addStretch(1); outer.addWidget(box, 100); outer.addStretch(1); self.col.addStretch()
        self.setWidget(self.inner); self.stick = True
        bar = self.verticalScrollBar()
        bar.rangeChanged.connect(lambda a, b: bar.setValue(b) if self.stick else None)
        bar.valueChanged.connect(lambda v: setattr(self, "stick", v >= bar.maximum() - 60))

    def add(self, w, animate=True):
        self.col.insertWidget(self.col.count() - 1, w)
        if animate: fade_in(w)

    def clear(self):
        while self.col.count() > 1:
            it = self.col.takeAt(0)
            if it.widget(): it.widget().deleteLater()
        self.stick = True


class Composer(QFrame):
    send = Signal(str, list)
    stop = Signal()
    mic = Signal()

    def __init__(self):
        super().__init__(); self.setObjectName("inputBox"); self.setProperty("focus", False)
        self.atts, self.busy = [], False
        v = QVBoxLayout(self); v.setContentsMargins(12, 8, 8, 8); v.setSpacing(4)
        self.chips = QHBoxLayout(); self.chips.setSpacing(6); self.chips.addStretch(); v.addLayout(self.chips)
        h = QHBoxLayout(); h.setSpacing(4)
        self.clip = QToolButton(); set_ic(self.clip, "attach", size=20); self.clip.setToolTip(T("Прикрепить файл или картинку"))
        self.clip.clicked.connect(self.pick)
        self.edit = QPlainTextEdit(); self.edit.setPlaceholderText(T("Чем я могу помочь сегодня?")); self.edit.setFixedHeight(44)
        self.edit.installEventFilter(self); self.edit.textChanged.connect(self._grow)
        self.mic_btn = QPushButton(); set_ic(self.mic_btn, "mic", size=20); self.mic_btn.setFixedSize(38, 38)
        self.mic_btn.setToolTip(T("Голосовой ввод")); self.mic_btn.clicked.connect(self.mic.emit)
        self.btn = QPushButton(); self.btn.setObjectName("primary"); set_ic(self.btn, "send", True, 20); self.btn.setFixedSize(38, 38)
        self.btn.clicked.connect(self._click)
        h.addWidget(self.clip, 0, Qt.AlignBottom); h.addWidget(self.edit, 1)
        h.addWidget(self.mic_btn, 0, Qt.AlignBottom); h.addWidget(self.btn, 0, Qt.AlignBottom); v.addLayout(h)

    def _grow(self):
        self.edit.setFixedHeight(max(44, min(int(self.edit.document().size().height()) + 18, 200)))

    def set_busy(self, b):
        self.busy = b; set_ic(self.btn, "stop" if b else "send", True, 20)

    def set_rec(self, on):
        self.mic_btn.setObjectName("rec" if on else ""); set_ic(self.mic_btn, "mic", on, 20)
        self.mic_btn.style().unpolish(self.mic_btn); self.mic_btn.style().polish(self.mic_btn)

    def pick(self):
        files, _ = QFileDialog.getOpenFileNames(self, T("Прикрепить"), "", T("Все файлы (*)"))
        self.add_files(files)

    def add_files(self, paths):
        for f in paths:
            try: a = load_attachment(f)
            except Exception as ex:
                QMessageBox.warning(self, T("Вложение"), str(ex)); continue
            chip = AttachChip(a); chip.removed.connect(self._rm)
            self.chips.insertWidget(self.chips.count() - 1, chip); self.atts.append(chip); fade_in(chip, 200)

    def _rm(self, chip):
        self.atts.remove(chip); chip.deleteLater()

    def _click(self):
        self.stop.emit() if self.busy else self._submit()

    def _submit(self):
        t = self.edit.toPlainText().strip()
        if (t or self.atts) and not self.busy:
            atts = [c.att for c in self.atts]
            for c in list(self.atts): self._rm(c)
            self.edit.clear(); self.send.emit(t, atts)

    def eventFilter(self, o, e):
        if o is self.edit:
            if e.type() == QEvent.KeyPress and e.key() in (Qt.Key_Return, Qt.Key_Enter) and not (e.modifiers() & Qt.ShiftModifier):
                self._submit(); return True
            if e.type() in (QEvent.FocusIn, QEvent.FocusOut):
                self.setProperty("focus", e.type() == QEvent.FocusIn); self.style().unpolish(self); self.style().polish(self)
        return super().eventFilter(o, e)


class Welcome(QWidget):
    pick = Signal(str)
    setup = Signal()
    keys = Signal()

    def __init__(self):
        super().__init__()
        lay = QVBoxLayout(self); lay.setAlignment(Qt.AlignCenter); lay.setSpacing(14)
        row = QHBoxLayout(); row.setAlignment(Qt.AlignCenter); row.setSpacing(12)
        s = Spark(40); s.start(); QTimer.singleShot(2500, lambda: alive(s) and s.stop()); row.addWidget(s)
        h = QLabel(T("Чем могу помочь?")); h.setObjectName("hello"); row.addWidget(h); lay.addLayout(row)
        chips = QHBoxLayout(); chips.setAlignment(Qt.AlignCenter)
        for t in (T("Объясни тему простыми словами"), T("Сделай веб-страницу или игру"), T("Разбери файлы в рабочей папке")):
            b = QPushButton(t); b.setObjectName("chip"); b.clicked.connect(lambda _, x=t: self.pick.emit(x)); chips.addWidget(b)
        lay.addLayout(chips)
        self.card = QFrame(); self.card.setObjectName("card"); cl = QVBoxLayout(self.card); cl.setContentsMargins(20, 16, 20, 16); cl.setSpacing(10)
        t1 = QLabel(T("Подключите бесплатные API, чтобы начать")); t1.setObjectName("brand"); cl.addWidget(t1)
        t2 = QLabel(T("Часть провайдеров работает без ключа, для остальных нужен бесплатный ключ — ссылка есть в карточке каждого провайдера."))
        t2.setObjectName("sub"); t2.setWordWrap(True); cl.addWidget(t2)
        br = QHBoxLayout(); b1 = QPushButton(T("Добавить все бесплатные и проверить")); b1.setObjectName("primary"); b1.clicked.connect(self.setup.emit)
        b2 = QPushButton(T("Настроить ключи")); b2.clicked.connect(self.keys.emit); br.addWidget(b1); br.addWidget(b2); br.addStretch(); cl.addLayout(br)
        self.card.setMaximumWidth(640); lay.addWidget(self.card, 0, Qt.AlignCenter); self.card.hide()


class ArtifactPanel(QFrame):
    closed = Signal()

    def __init__(self):
        super().__init__(); self.setObjectName("artPanel"); self.setMaximumWidth(0)
        self.arts, self.aid = {}, None
        v = QVBoxLayout(self); v.setContentsMargins(12, 10, 12, 10)
        top = QHBoxLayout(); top.setSpacing(4)
        self.title = QLabel(""); self.title.setObjectName("brand"); top.addWidget(self.title, 1)
        self.ver = QComboBox(); self.ver.currentIndexChanged.connect(self._show); top.addWidget(self.ver)
        for ic, tip, fn in (("copy", T("Копировать"), self.copy), ("save", T("Сохранить файл"), self.save),
                            ("external", T("Открыть в браузере"), self.browser), ("close", T("Закрыть"), self.closed.emit)):
            b = QToolButton(); set_ic(b, ic, size=18); b.setToolTip(tip); b.clicked.connect(fn); top.addWidget(b)
        v.addLayout(top)
        seg = QHBoxLayout(); seg.setSpacing(0)
        self.b_prev, self.b_code = QPushButton(T("Просмотр")), QPushButton(T("Код"))
        for b in (self.b_prev, self.b_code): b.setObjectName("seg"); b.setCheckable(True); seg.addWidget(b)
        seg.addStretch(); self.b_prev.setChecked(True); v.addLayout(seg)
        self.b_prev.clicked.connect(lambda: self._mode(0)); self.b_code.clicked.connect(lambda: self._mode(1))
        self.stack = QStackedWidget(); v.addWidget(self.stack, 1)
        self.web = QLabel(T("Предпросмотр HTML недоступен — нажмите «Открыть в браузере»."))
        self.md = QTextBrowser(); self.md.setOpenExternalLinks(True)
        self.code = QPlainTextEdit(); self.code.setReadOnly(True); self.code.setStyleSheet("font-family: Consolas, monospace; font-size: 13px;")
        for w in (self.web, self.md, self.code): self.stack.addWidget(w)
        self.anim = QPropertyAnimation(self, b"maximumWidth", self); self.anim.setDuration(280); self.anim.setEasingCurve(QEasingCurve.OutCubic)

    def slide(self, open_):
        self.anim.stop(); self.setMinimumWidth(0); self.anim.setStartValue(self.maximumWidth()); self.anim.setEndValue(560 if open_ else 0)
        self.anim.start()

    def is_open(self): return self.maximumWidth() > 0

    def open(self, arts, aid):
        self.arts = arts
        if aid not in arts: return
        self.aid = aid; a = arts[aid]; self.title.setText(a["title"])
        self.ver.blockSignals(True); self.ver.clear(); self.ver.addItems([f"v{i+1}" for i in range(len(a["versions"]))])
        self.ver.setCurrentIndex(len(a["versions"]) - 1); self.ver.blockSignals(False)
        self.ver.setVisible(len(a["versions"]) > 1); self._show(); self.slide(True)

    def _cur(self):
        a = self.arts.get(self.aid)
        return (a, a["versions"][max(0, self.ver.currentIndex())]) if a else (None, "")

    def _show(self):
        a, content = self._cur()
        if not a: return
        self.code.setPlainText(content); self._mode(0 if self.b_prev.isChecked() else 1)

    def _mode(self, m):
        self.b_prev.setChecked(m == 0); self.b_code.setChecked(m == 1)
        a, content = self._cur()
        if not a: return
        if m == 1 or a["type"] == "code": self.stack.setCurrentWidget(self.code); return
        if a["type"] == "markdown": self.md.setMarkdown(content); self.stack.setCurrentWidget(self.md); return
        if HAVE_WEB and self._web():
            html = content if a["type"] == "html" else \
                f"<html><body style='margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#fff'>{content}</body></html>"
            self.web.setHtml(html); self.stack.setCurrentWidget(self.web)
        else:
            self.stack.setCurrentWidget(self.code)

    def _web(self):
        global HAVE_WEB
        if isinstance(self.web, QLabel):
            try:
                v = QWebEngineView(); i = self.stack.indexOf(self.web); self.stack.removeWidget(self.web); self.web.deleteLater(); self.web = v; self.stack.insertWidget(i, v)
            except Exception:
                HAVE_WEB = False; return False
        return True

    def copy(self): QGuiApplication.clipboard().setText(self._cur()[1])

    def _ext(self, a):
        return EXT.get(a["type"]) or EXT.get((a.get("language") or "").lower(), ".txt")

    def save(self):
        a, content = self._cur()
        if not a: return
        f, _ = QFileDialog.getSaveFileName(self, T("Сохранить артефакт"), a["title"] + self._ext(a))
        if f: Path(f).write_text(content, "utf-8")

    def browser(self):
        a, content = self._cur()
        if not a: return
        f = config.DATA / ("preview" + (".svg" if a["type"] == "svg" else ".html" if a["type"] == "html" else ".txt"))
        f.write_text(content, "utf-8"); webbrowser.open(f.as_uri())


CONF = ["all", "input", "none"]


class SettingsDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent); self.cfg = cfg; self.setWindowTitle(T("Настройки")); self.setMinimumWidth(660)
        self.vision = cfg.get("vision_model", "")
        root = QVBoxLayout(self); root.setContentsMargins(18, 16, 18, 16); root.setSpacing(12); tabs = QTabWidget(); root.addWidget(tabs)

        def tab(title):
            w = QWidget(); f = QFormLayout(w); f.setContentsMargins(16, 16, 16, 16); f.setVerticalSpacing(10); tabs.addTab(w, title); return f
        f = tab(T("Основные"))
        pb = QPushButton(T("Провайдеры API")); set_ic(pb, "cpu"); pb.clicked.connect(lambda: ProvidersDialog(self.cfg, self).exec()); f.addRow(pb)
        self.vb = QPushButton(); self.vb.clicked.connect(self._vision); self._vlabel()
        self.lang = QComboBox(); self.lang.addItems(["Русский", "English"]); self.lang.setCurrentIndex(cfg.get("lang", "ru") == "en")
        self.ws = QLineEdit(cfg["workspace"]); b = QPushButton(T("Обзор")); b.clicked.connect(self._browse)
        wr = QHBoxLayout(); wr.addWidget(self.ws, 1); wr.addWidget(b)
        self.theme = QComboBox(); self.theme.addItems([T("Светлая"), T("Тёмная")]); self.theme.setCurrentIndex(cfg["theme"] == "dark")
        self.agent = QCheckBox(T("Режим агента (файлы и команды)")); self.agent.setChecked(cfg["agent"])
        self.appr = QCheckBox(T("Спрашивать разрешение на запись и команды")); self.appr.setChecked(cfg["require_approval"])
        self.tts = QCheckBox(T("Озвучивать ответы автоматически")); self.tts.setChecked(cfg["tts_auto"])
        self.fb = QCheckBox(T("Если выбранная модель недоступна — переключаться на «Авто»")); self.fb.setChecked(cfg.get("fallback_auto", True))
        self.steps = QSpinBox(); self.steps.setRange(1, 60); self.steps.setValue(cfg["max_steps"])
        for lab, w in ((T("Язык"), self.lang), (T("Модель для картинок"), self.vb), (T("Рабочая папка"), wr), (T("Тема"), self.theme),
                       ("", self.agent), ("", self.appr), ("", self.tts), ("", self.fb), (T("Макс. шагов агента"), self.steps)): f.addRow(lab, w)
        f = tab(T("Интернет и память"))
        self.web = QCheckBox(T("Разрешить ИИ искать в интернете и читать страницы")); self.web.setChecked(cfg.get("web", True))
        self.surl = QLineEdit(cfg.get("search_url", "")); self.surl.setPlaceholderText("https://searx.example.org")
        self.mem = QCheckBox(T("Долгая память: запоминать устойчивые факты обо мне")); self.mem.setChecked(cfg.get("memory_on", True))
        mb = QPushButton(T("Что Cloudy помнит")); set_ic(mb, "layers"); mb.clicked.connect(lambda: MemoryDialog(self).exec())
        jb = QPushButton(T("Журнал действий и откат")); set_ic(jb, "undo"); jb.clicked.connect(lambda: JournalDialog(self).exec())
        f.addRow(self.web); f.addRow(T("Свой SearXNG (необязательно)"), self.surl); f.addRow(self.mem); f.addRow(mb); f.addRow(jb)
        f = tab(T("MCP и компьютер"))
        c = cfg.get("computer") or {}
        self.comp_on = QCheckBox(T("Управление компьютером: ИИ видит экран, имеет свой чёрный курсор и доступ к клавиатуре")); self.comp_on.setChecked(bool(c.get("on")))
        if not winput.available():
            self.comp_on.setEnabled(False); self.comp_on.setToolTip(T("Доступно только в Windows (нужны mss и Pillow)"))
        warn = QLabel(T("Внимание: ИИ сможет нажимать и печатать на вашем компьютере. Esc — аварийная остановка. Нужна модель с картинками и инструментами: при включении «Авто» сам найдёт подходящие."))
        warn.setObjectName("sub"); warn.setWordWrap(True)
        self.comp_conf = QComboBox(); self.comp_conf.addItems([T("Спрашивать каждое действие"), T("Спрашивать только ввод текста и клавиши"), T("Не спрашивать")])
        self.comp_conf.setCurrentIndex(CONF.index(c.get("confirm", "input")) if c.get("confirm", "input") in CONF else 1)
        self.comp_min = QCheckBox(T("Сворачивать Cloudy на время работы")); self.comp_min.setChecked(c.get("minimize", True))
        self.mcp_on = QCheckBox(T("Подключать MCP-серверы")); self.mcp_on.setChecked(bool((cfg.get("mcp") or {}).get("on")))
        mcpb = QPushButton(T("MCP-серверы")); set_ic(mcpb, "blocks"); mcpb.clicked.connect(lambda: MCPDialog(self.cfg, self).exec())
        f.addRow(self.comp_on); f.addRow(warn); f.addRow(T("Подтверждения"), self.comp_conf); f.addRow(self.comp_min); f.addRow(self.mcp_on); f.addRow(mcpb)
        f = tab(T("Система")); tr = cfg.get("tray") or {}
        self.auto = QCheckBox(T("Запускать Cloudy вместе с Windows (в трее)")); self.auto.setChecked(system.autostart_get()); self.auto.setEnabled(os.name == "nt")
        self.trc = QCheckBox(T("При закрытии окна оставлять Cloudy в трее")); self.trc.setChecked(bool(tr.get("close")))
        self.hk = QCheckBox(T("Глобальная клавиша Ctrl+Alt+C: показать или скрыть Cloudy")); self.hk.setChecked(tr.get("hotkey", True)); self.hk.setEnabled(os.name == "nt")
        ab = QPushButton(T("О программе")); set_ic(ab, "info"); ab.clicked.connect(lambda: AboutDialog(self, self.cfg).exec())
        df = QPushButton(T("Открыть папку данных")); set_ic(df, "folder"); df.clicked.connect(lambda: system.open_folder(config.DATA))
        dg = QPushButton(T("Диагностика")); set_ic(dg, "check"); dg.clicked.connect(lambda: DiagDialog(self.cfg, self).exec())
        f.addRow(self.auto); f.addRow(self.trc); f.addRow(self.hk); f.addRow(dg); f.addRow(ab); f.addRow(df)
        ok = QPushButton(T("Сохранить")); ok.setObjectName("primary"); ok.clicked.connect(self._ok); root.addWidget(ok)

    def _vlabel(self): self.vb.setText(router.label(self.cfg, self.vision) if self.vision else T("Авто (подходящая)"))

    def _vision(self):
        d = ModelPicker(self.cfg, self.vision, True, T("Авто (подходящая)"), self)
        if d.exec() and d.key is not None: self.vision = d.key; self._vlabel()

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, T("Рабочая папка"), self.ws.text())
        if d: self.ws.setText(d)

    def _ok(self):
        self.cfg.update(workspace=self.ws.text().strip(), theme="dark" if self.theme.currentIndex() else "light",
                        agent=self.agent.isChecked(), require_approval=self.appr.isChecked(), tts_auto=self.tts.isChecked(),
                        max_steps=self.steps.value(), vision_model=self.vision, lang="en" if self.lang.currentIndex() else "ru",
                        web=self.web.isChecked(), search_url=self.surl.text().strip(), memory_on=self.mem.isChecked(), fallback_auto=self.fb.isChecked())
        self.cfg["computer"] = {"on": self.comp_on.isChecked(), "confirm": CONF[self.comp_conf.currentIndex()], "minimize": self.comp_min.isChecked()}
        self.cfg.setdefault("mcp", {"servers": []})["on"] = self.mcp_on.isChecked()
        self.cfg["tray"] = {"close": self.trc.isChecked(), "hotkey": self.hk.isChecked()}
        try: system.autostart_set(self.auto.isChecked())
        except Exception: pass
        self.accept()


class ProjectsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle(T("Проекты")); self.resize(760, 520)
        h = QHBoxLayout(self)
        left = QVBoxLayout(); self.lst = QListWidget(); left.addWidget(self.lst, 1)
        nb = QPushButton(T("Новый проект")); set_ic(nb, "plus"); nb.clicked.connect(self.new); left.addWidget(nb); h.addLayout(left, 1)
        f = QFormLayout(); self.name = QLineEdit()
        self.ins = QPlainTextEdit(); self.ins.setPlaceholderText(T("Инструкции: как отвечать в этом проекте, контекст, стиль…"))
        self.files = QListWidget(); self.files.setMaximumHeight(110)
        fb = QHBoxLayout(); a = QPushButton(T("Добавить файлы")); set_ic(a, "file"); a.clicked.connect(self.add_files)
        r = QPushButton(T("Убрать")); r.clicked.connect(lambda: [self.files.takeItem(self.files.row(i)) for i in self.files.selectedItems()])
        fb.addWidget(a); fb.addWidget(r); fb.addStretch()
        self.ws = QLineEdit(); self.ws.setPlaceholderText(T("пусто = общая рабочая папка"))
        wb = QPushButton(T("Обзор")); wb.clicked.connect(self._ws)
        wr = QHBoxLayout(); wr.addWidget(self.ws, 1); wr.addWidget(wb)
        f.addRow(T("Название"), self.name); f.addRow(T("Инструкции"), self.ins); f.addRow(T("Знания"), self.files); f.addRow("", fb); f.addRow(T("Папка"), wr)
        bb = QHBoxLayout(); sv = QPushButton(T("Сохранить")); sv.setObjectName("primary"); sv.clicked.connect(self.save)
        dl = QPushButton(T("Удалить")); set_ic(dl, "trash"); dl.clicked.connect(self.delete); bb.addWidget(sv); bb.addWidget(dl); f.addRow(bb)
        h.addLayout(f, 2); self.cur = None; self.fill()
        self.lst.currentRowChanged.connect(self.pick)

    def fill(self, select=None):
        self.projs = storage.list_projects(); self.lst.blockSignals(True); self.lst.clear()
        for p in self.projs: self.lst.addItem(p["name"])
        self.lst.blockSignals(False)
        if self.projs:
            i = next((k for k, p in enumerate(self.projs) if p["id"] == select), 0); self.lst.setCurrentRow(i); self.pick(i)
        else: self.new()

    def pick(self, i):
        if i < 0 or i >= len(self.projs): return
        p = self.cur = self.projs[i]
        self.name.setText(p["name"]); self.ins.setPlainText(p["instructions"]); self.ws.setText(p.get("workspace", ""))
        self.files.clear(); self.files.addItems(p["files"])

    def new(self):
        p = storage.new_project(); storage.save_project(p); self.fill(p["id"])

    def add_files(self):
        fs, _ = QFileDialog.getOpenFileNames(self, T("Файлы знаний"))
        for f in fs: self.files.addItem(f)

    def _ws(self):
        d = QFileDialog.getExistingDirectory(self, T("Папка проекта"))
        if d: self.ws.setText(d)

    def save(self):
        if not self.cur: return
        self.cur.update(name=self.name.text().strip() or T("Проект"), instructions=self.ins.toPlainText(),
                        files=[self.files.item(i).text() for i in range(self.files.count())], workspace=self.ws.text().strip())
        storage.save_project(self.cur); self.fill(self.cur["id"])

    def delete(self):
        if self.cur: storage.delete_project(self.cur["id"]); self.cur = None; self.fill()


ORDER = ["Математика", "Текст", "Данные", "Дата и время", "Файлы проекта", "Заметки", "Утилиты", "Код", "Учёба", "Письмо", "Работа", "Творчество", "Жизнь"]


class StoreDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle(T("Магазин плагинов")); self.resize(780, 740)
        lay = QVBoxLayout(self); lay.setContentsMargins(18, 16, 18, 16); lay.setSpacing(10)
        t = QLabel(T("Магазин плагинов")); t.setObjectName("hello"); lay.addWidget(t)
        s = QLabel(T("Всё встроено в приложение: без сайтов и интернета. Каждый плагин проверяется по SHA-256.")); s.setObjectName("sub"); s.setWordWrap(True); lay.addWidget(s)
        bar = QHBoxLayout(); self.search = QLineEdit(); self.search.setPlaceholderText(T("Поиск плагинов")); self.search.textChanged.connect(self.fill); bar.addWidget(self.search, 1)
        self.cat = QComboBox(); self.cat.addItem(T("Все категории"), "")
        have = {c.get("category") for c in plugins.catalog()}
        for c in ORDER + sorted(have - set(ORDER) - {None}):
            if c in have: self.cat.addItem(T(c), c)
        self.cat.currentIndexChanged.connect(self.fill); bar.addWidget(self.cat)
        self.only = QCheckBox(T("Только установленные")); self.only.toggled.connect(self.fill); bar.addWidget(self.only); lay.addLayout(bar)
        self.count = QLabel(""); self.count.setObjectName("sub"); lay.addWidget(self.count)
        self.area = QScrollArea(); self.area.setWidgetResizable(True); lay.addWidget(self.area, 1)
        h = QLabel(T("Включайте только нужные плагины: чем больше включено, тем длиннее подсказки для модели.")); h.setObjectName("sub"); h.setWordWrap(True); lay.addWidget(h)
        self.fill(); self.setWindowOpacity(0)
        self.a = QPropertyAnimation(self, b"windowOpacity", self); self.a.setDuration(220); self.a.setEndValue(1.0); self.a.start()

    def loc(self, c, k):
        return (c.get(k + "_en") or T(c[k])) if i18n.lang() == "en" else c[k]

    def fill(self, *_):
        q = self.search.text().lower().split(); cat = self.cat.currentData(); cats = plugins.catalog()
        w = QWidget(); col = QVBoxLayout(w); col.setSpacing(10); shown = 0
        for c in cats:
            blob = " ".join([c["name"], c["description"], c.get("name_en", ""), c.get("description_en", ""), c.get("category", "")]).lower()
            if (q and not all(x in blob for x in q)) or (cat and c.get("category") != cat) or (self.only.isChecked() and not plugins.is_installed(c["id"])): continue
            shown += 1; card = QFrame(); card.setObjectName("card"); h = QHBoxLayout(card); h.setContentsMargins(14, 10, 14, 10)
            ic = QLabel(); ic.setPixmap(icons.pix("terminal" if c["kind"] == "tools" else "layers", None, 24)); h.addWidget(ic, 0, Qt.AlignTop)
            info = QVBoxLayout(); info.setSpacing(2)
            n = QLabel("<b>{}</b>  <span style='color:gray'>v{} / {} / {}</span>".format(self.loc(c, "name"), c["version"], T("инструменты") if c["kind"] == "tools" else T("навык"), T(c.get("category", ""))))
            d = QLabel(self.loc(c, "description")); d.setWordWrap(True); d.setObjectName("sub")
            p = QLabel(T("Доступ: ") + ", ".join(T(x) for x in c["permissions"])); p.setObjectName("sub"); p.setWordWrap(True)
            for x in (n, d, p): info.addWidget(x)
            h.addLayout(info, 1); pid = c["id"]; side = QVBoxLayout()
            if plugins.is_installed(pid):
                chk = QCheckBox(T("Включён")); chk.setChecked(plugins.is_enabled(pid)); chk.toggled.connect(lambda on, i=pid: plugins.set_enabled(i, on))
                rm = QPushButton(T("Удалить")); set_ic(rm, "trash"); rm.clicked.connect(lambda _, i=pid: (plugins.uninstall(i), self.fill()))
                side.addWidget(chk); side.addWidget(rm)
            else:
                b = QPushButton(T("Скачать")); b.setObjectName("primary"); set_ic(b, "save", True); b.clicked.connect(lambda _, i=pid: self.inst(i)); side.addWidget(b)
            h.addLayout(side); col.addWidget(card)
        col.addStretch(); self.area.setWidget(w)
        self.count.setText(T("Всего: {n}  /  установлено: {m}").format(n=len(cats), m=sum(1 for c in cats if plugins.is_installed(c["id"]))) + ("   " + T("Показано: {n}").format(n=shown) if shown != len(cats) else ""))

    def inst(self, pid):
        err = plugins.install(pid)
        if err: QMessageBox.warning(self, T("Плагин"), err)
        self.fill()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.cfg = config.load(); i18n.set_lang(self.cfg.get("lang", "ru")); self._quit = self._restart = False; self.worker = self.listener = self.dl = None; self.cur = self.cur_ui = None
        self.proj = None; self.speaker = voice.Speaker(); self.base_text = ""
        self.setWindowTitle("Cloudy"); self.setWindowIcon(icons.app_icon()); self.resize(1240, 780); self._restore(); self.setAcceptDrops(True)
        root = QWidget(); self.setCentralWidget(root); h = QHBoxLayout(root); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(0)
        self.side = QFrame(); self.side.setObjectName("sidebar"); self.side.setFixedWidth(270)
        sl = QVBoxLayout(self.side); sl.setContentsMargins(12, 14, 12, 12)
        br = QHBoxLayout(); br.setSpacing(8); br.addWidget(Spark(22)); lb = QLabel("Cloudy"); lb.setObjectName("brand"); br.addWidget(lb); br.addStretch(); sl.addLayout(br)
        nb = QPushButton(T("Новый чат")); set_ic(nb, "plus"); nb.clicked.connect(self.new_chat); sl.addWidget(nb)
        pr = QHBoxLayout(); self.pcombo = QComboBox(); self.pcombo.currentIndexChanged.connect(self.on_project)
        pe = QToolButton(); set_ic(pe, "layers"); pe.setToolTip(T("Управление проектами")); pe.clicked.connect(self.open_projects)
        pr.addWidget(self.pcombo, 1); pr.addWidget(pe); sl.addLayout(pr)
        lbl = QLabel(T("Недавние")); lbl.setObjectName("sub"); sl.addWidget(lbl)
        self.search = QLineEdit(); self.search.setPlaceholderText(T("Поиск по чатам")); self.search.setClearButtonEnabled(True); self.search.textChanged.connect(lambda _: self.refresh_list()); sl.addWidget(self.search)
        self.lst = QVBoxLayout(); self.lst.setSpacing(2); lw = QWidget(); lw.setObjectName("sideList"); lw.setLayout(self.lst)
        sa = QScrollArea(); sa.setWidgetResizable(True); sa.setWidget(lw); sl.addWidget(sa, 1)
        pb = QPushButton(T("Магазин плагинов")); set_ic(pb, "blocks"); pb.clicked.connect(self.open_store); sl.addWidget(pb)
        st = QPushButton(T("Настройки")); set_ic(st, "sliders"); st.clicked.connect(self.open_settings); sl.addWidget(st)
        h.addWidget(self.side)
        right = QWidget(); right.setObjectName("chatArea"); rl = QVBoxLayout(right); rl.setContentsMargins(0, 0, 0, 0)
        top = QHBoxLayout(); top.setContentsMargins(10, 8, 10, 0)
        self.tg = QToolButton(); set_ic(self.tg, "menu"); self.tg.clicked.connect(self.toggle_side); top.addWidget(self.tg)
        self.title = QLabel(""); self.title.setObjectName("sub"); top.addWidget(self.title); top.addStretch()
        self.scan_lbl = QLabel(""); self.scan_lbl.setObjectName("sub"); self.scan_th = None
        self.collab_btn = QPushButton(); self.collab_btn.setObjectName("topbtn"); set_ic(self.collab_btn, "network", size=16); self.collab_btn.clicked.connect(self.open_collab)
        self.model_btn = QPushButton(); self.model_btn.setObjectName("topbtn"); set_ic(self.model_btn, "cpu", size=16); self.model_btn.clicked.connect(self.pick_model)
        self.exp_btn = QToolButton(); set_ic(self.exp_btn, "save", size=18); self.exp_btn.setToolTip(T("Экспорт чата")); self.exp_btn.setPopupMode(QToolButton.InstantPopup)
        em = QMenu(self.exp_btn)
        for label, fmt in (("Markdown (.md)", "md"), ("HTML (.html)", "html"), ("JSON (.json)", "json")): em.addAction(label).triggered.connect(lambda _, f=fmt: self.export_chat(f))
        self.exp_btn.setMenu(em)
        top.addWidget(self.scan_lbl); top.addWidget(self.exp_btn); top.addWidget(self.collab_btn); top.addWidget(self.model_btn); rl.addLayout(top); self.refresh_model_btn()
        self.view = ChatView(); self.welcome = Welcome(); self.welcome.pick.connect(lambda t: self.on_send(t, [])); self.welcome.setup.connect(self.add_all_free); self.welcome.keys.connect(self.first_run)
        rl.addWidget(self.view, 1); rl.addWidget(self.welcome, 1)
        cw = QWidget(); cl = QHBoxLayout(cw); cl.setContentsMargins(20, 4, 20, 18); cl.addStretch(1)
        self.comp = Composer(); self.comp.setMaximumWidth(780); self.comp.setMinimumWidth(300); cl.addWidget(self.comp, 100); cl.addStretch(1); rl.addWidget(cw)
        self.comp.send.connect(self.on_send); self.comp.stop.connect(self.on_stop); self.comp.mic.connect(self.toggle_mic)
        h.addWidget(right, 1)
        self.panel = ArtifactPanel(); self.panel.closed.connect(lambda: self.panel.slide(False)); h.addWidget(self.panel)
        QShortcut(QKeySequence("Ctrl+N"), self, self.new_chat); QShortcut(QKeySequence("Ctrl+K"), self, self.pick_model)
        QShortcut(QKeySequence("Ctrl+L"), self, lambda: self.comp.edit.setFocus())
        self.ai_cursor = AICursor(); self.ai_banner = AIBanner(T("Cloudy управляет компьютером. Esc — остановить"))
        self.esc_timer = QTimer(self); self.esc_timer.timeout.connect(self._esc)
        self.apply_theme(); self.fill_projects(); self.refresh_list(); self.new_chat()
        self.refresh_model_btn(); QTimer.singleShot(900, self.start_scan); self.setup_system(); QTimer.singleShot(700, self.maybe_onboard)

    # ---- тема / интерфейс
    def apply_theme(self):
        p = theme.PALETTES[self.cfg["theme"]]
        widgets.PAL.update(code=p["code"], accent=p["accent"]); icons.COLOR["c"] = p["text"]
        app = QApplication.instance(); app.setStyle("Fusion"); app.setPalette(theme.palette(p)); app.setStyleSheet(theme.qss(p)); icons.refresh(self)

    def toggle_side(self):
        w = self.side.width(); self.side.setMinimumWidth(0)
        self.sa = QPropertyAnimation(self.side, b"maximumWidth", self); self.sa.setDuration(240); self.sa.setEasingCurve(QEasingCurve.OutCubic)
        self.sa.setStartValue(w); self.sa.setEndValue(0 if w > 0 else 270); self.sa.start()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls(): e.acceptProposedAction()

    def dropEvent(self, e):
        self.comp.add_files([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])

    # ---- проекты
    def fill_projects(self, select=None):
        self.pcombo.blockSignals(True); self.pcombo.clear(); self.pcombo.addItem(T("Все чаты"), None)
        for p in storage.list_projects(): self.pcombo.addItem(p["name"], p["id"])
        i = max(0, self.pcombo.findData(select if select is not None else self.proj)); self.pcombo.setCurrentIndex(i)
        self.proj = self.pcombo.itemData(i); self.pcombo.blockSignals(False)

    def on_project(self, i):
        self.proj = self.pcombo.itemData(i); self.refresh_list()

    def open_projects(self):
        ProjectsDialog(self).exec(); self.fill_projects(); self.refresh_list()

    # ---- список чатов
    def refresh_list(self):
        while self.lst.count():
            it = self.lst.takeAt(0)
            if it.widget(): it.widget().deleteLater()
        q = self.search.text().strip().lower() if hasattr(self, "search") else ""
        chats = storage.list_chats(); chats.sort(key=lambda c: not c.get("pinned"))
        for c in chats:
            if self.proj and c.get("project") != self.proj: continue
            if q and q not in c["title"].lower() and q not in storage.chat_text(c): continue
            row = QWidget(); r = QHBoxLayout(row); r.setContentsMargins(0, 0, 0, 0); r.setSpacing(0)
            b = QPushButton(T(c["title"])[:30]); b.setObjectName("chat"); set_ic(b, "pin" if c.get("pinned") else "chat", size=16)
            b.setProperty("active", bool(self.cur and c["id"] == self.cur["id"])); b.clicked.connect(lambda _, x=c: self.open_chat(x))
            b.setContextMenuPolicy(Qt.CustomContextMenu); b.customContextMenuRequested.connect(lambda pos, x=c, w=b: self.chat_menu(x, w.mapToGlobal(pos)))
            d = QToolButton(); set_ic(d, "close", size=12); d.clicked.connect(lambda _, x=c: self.del_chat(x))
            r.addWidget(b, 1); r.addWidget(d); self.lst.addWidget(row)
        self.lst.addStretch()

    def chat_menu(self, c, pos):
        m = QMenu(self); a_ren = m.addAction(T("Переименовать")); a_pin = m.addAction(T("Открепить") if c.get("pinned") else T("Закрепить"))
        a_exp = m.addAction(T("Экспорт (Markdown)")); a_del = m.addAction(T("Удалить")); act = m.exec(pos)
        target = self.cur if (self.cur and self.cur["id"] == c["id"]) else c
        if act is a_ren:
            t, ok = QInputDialog.getText(self, T("Переименовать"), T("Название"), text=target["title"])
            if ok and t.strip(): target["title"] = t.strip()[:60]; storage.save_chat(target); self.title.setText(target["title"]) if target is self.cur else None
        elif act is a_pin: target["pinned"] = not target.get("pinned"); storage.save_chat(target)
        elif act is a_exp: self.export_chat("md", target); return
        elif act is a_del: self.del_chat(c); return
        self.refresh_list()

    def export_chat(self, fmt="md", chat=None):
        chat = chat or self.cur
        if not chat or not chat.get("messages"): QMessageBox.information(self, T("Экспорт чата"), T("Чат пока пуст.")); return
        ext = {"md": ".md", "html": ".html", "json": ".json"}[fmt]; name = "".join(ch for ch in chat["title"] if ch.isalnum() or ch in " -_")[:40].strip() or "chat"
        f, _ = QFileDialog.getSaveFileName(self, T("Экспорт чата"), name + ext, f"*{ext}")
        if not f: return
        lang = i18n.lang(); data = {"md": exporter.to_markdown, "html": exporter.to_html}.get(fmt, lambda c, l=None: exporter.to_json(c))(chat, lang) if fmt != "json" else exporter.to_json(chat)
        Path(f).write_text(data, "utf-8")

    def del_chat(self, c):
        storage.delete_chat(c["id"])
        if self.cur and self.cur["id"] == c["id"]: self.new_chat()
        else: self.refresh_list()

    def busy(self): return bool(self.worker and self.worker.isRunning())

    def new_chat(self):
        if self.busy(): return
        self.cur = storage.new_chat(self.proj); self.render_chat(); self.refresh_list(); self.panel.slide(False)

    def open_chat(self, c):
        if self.busy(): return
        self.cur = c; self.render_chat(); self.refresh_list(); self.panel.slide(False)

    def open_artifact(self, aid): self.panel.open(self.cur["artifacts"], aid)

    def mk_assistant(self):
        a = AssistantMsg(); a.open_cb = self.open_artifact; a.speak_cb = self.speaker.say; a.regen_cb = self.regenerate; return a

    def render_chat(self):
        self.view.clear(); self.title.setText(self.cur["title"] if self.cur["messages"] else "")
        empty = not self.cur["messages"]; self.welcome.setVisible(empty); self.view.setVisible(not empty)
        results = {m["tool_call_id"]: m["content"] for m in self.cur["messages"] if m["role"] == "tool"}
        last_ai = max((i for i, x in enumerate(self.cur["messages"]) if x["role"] == "assistant"), default=-1)
        for i, m in enumerate(self.cur["messages"]):
            if m.get("_screen"): continue
            if m["role"] == "user": self.view.add(UserMsg(m), False)
            elif m["role"] == "assistant":
                a = self.mk_assistant()
                for d in m.get("_drafts", []): a.draft_start(d["model"]); a.draft_text(d["model"], d["text"]); a.draft_done(d["model"], True)
                a.set_model(m.get("_model", ""))
                if m.get("content"): a.add_text(m["content"])
                a.close_segment()
                for tc in m.get("tool_calls") or []:
                    a.add_tool(tc["id"], tc["function"]["name"], tc["function"]["arguments"]); a.tool_done(tc["id"], results.get(tc["id"], ""))
                a.finish_actions(i == last_ai); self.view.add(a, False)

    # ---- отправка
    def on_send(self, text, atts):
        if self.busy(): return
        msg = build_user_message(text, atts)
        if not self.cur["messages"]:
            self.cur["title"] = (text or (atts[0]["name"] if atts else T("Чат")))[:40]; self.welcome.hide(); self.view.show(); self.title.setText(self.cur["title"])
        self.speaker.stop(); self.cur["messages"].append(msg)
        self.view.stick = True; self.view.add(UserMsg(msg))
        self.run_worker()

    def regenerate(self):
        if self.busy(): return
        ms = self.cur["messages"]; idx = max((i for i, m in enumerate(ms) if m["role"] == "user" and not m.get("_screen")), default=None)
        if idx is None: return
        del ms[idx + 1:]; self.render_chat(); self.view.stick = True; self.run_worker()

    def run_worker(self):
        for a in self.view.inner.findChildren(AssistantMsg): a.hide_regen()
        self.cur_ui = self.mk_assistant(); self.view.add(self.cur_ui); self.cur_ui.set_running(True); self.comp.set_busy(True)
        self.worker = AgentWorker(self.cfg, self.cur, storage.get_project(self.cur.get("project")))
        w, u = self.worker, self.cur_ui
        w.token.connect(u.add_text); w.reasoning.connect(u.add_reasoning); w.tool_start.connect(u.add_tool); w.tool_done.connect(u.tool_done)
        w.model_used.connect(u.set_model); w.draft_start.connect(u.draft_start); w.draft_text.connect(u.draft_text); w.draft_done.connect(u.draft_done)
        w.status.connect(self.scan_lbl.setText); w.cursor_move.connect(self.on_cursor_move); w.cursor_click.connect(self.on_cursor_click); w.computer_state.connect(self.on_computer_state)
        w.approval.connect(self.ask); w.failed.connect(self.on_error); w.artifact.connect(self.open_artifact); w.finished.connect(self.on_finished)
        threads.run(w); self.refresh_list()

    def ask(self, name, detail):
        m = QMessageBox(self); m.setWindowTitle(T("Разрешить действие?")); m.setText(T("Агент хочет выполнить: {name}").format(name=name))
        m.setInformativeText(detail[:300]); m.setDetailedText(detail)
        yes = m.addButton(T("Разрешить"), QMessageBox.AcceptRole); m.addButton(T("Отклонить"), QMessageBox.RejectRole)
        m.exec(); self.worker.answer(m.clickedButton() is yes)

    def on_error(self, msg):
        if self.cur_ui: self.cur_ui.close_segment(); self.cur_ui.add_text(T("**Ошибка:** {msg}").format(msg=msg))

    def on_stop(self):
        if self.worker: self.worker.stop()

    def on_finished(self):
        if self.cur_ui:
            self.cur_ui.set_running(False); self.cur_ui.finish_actions(True)
            if self.cfg.get("tts_auto") and self.cur_ui.full: self.speaker.say(self.cur_ui.full)
        self.comp.set_busy(False); storage.save_chat(self.cur); self.refresh_list()

    # ---- голос
    def toggle_mic(self):
        if self.listener and self.listener.isRunning(): self.listener.stop(); return
        if not voice.available():
            QMessageBox.information(self, T("Голос"), T("Модули vosk и sounddevice не установлены. Запустите build_exe.bat заново (они в requirements.txt).")); return
        if not voice.model_path(): self.get_model(); return
        self.base_text = self.comp.edit.toPlainText().strip()
        self.listener = voice.Listener(); l = self.listener
        l.partial.connect(self.on_speech); l.final.connect(self.on_speech)
        l.error.connect(lambda m: QMessageBox.warning(self, T("Голос"), m)); l.finished.connect(lambda: self.comp.set_rec(False))
        self.comp.set_rec(True); threads.run(l)

    def on_speech(self, t): self.comp.edit.setPlainText((self.base_text + " " + t).strip())

    def get_model(self):
        if QMessageBox.question(self, T("Голосовой ввод"), T("Нужно один раз скачать офлайн-модель распознавания речи (около 45 МБ). Скачать?")) != QMessageBox.Yes: return
        pd = QProgressDialog(T("Скачиваю модель распознавания речи…"), None, 0, 100, self); pd.setWindowModality(Qt.WindowModal); pd.setMinimumDuration(0)
        self.dl = voice.ModelDownloader(); self.dl.progress.connect(pd.setValue)
        def fin(err):
            pd.close()
            if err: QMessageBox.warning(self, T("Голосовой ввод"), T("Не удалось скачать: ") + err)
            else: QMessageBox.information(self, T("Голосовой ввод"), T("Готово. Нажмите на микрофон ещё раз."))
        self.dl.done.connect(fin); threads.run(self.dl)

    def first_run(self):
        ProvidersDialog(self.cfg, self).exec(); self.refresh_model_btn(); self.start_scan()

    def need(self):
        c, m = self.cfg.get("computer") or {}, self.cfg.get("mcp") or {}
        if c.get("on") and winput.available(): return {"vision": True, "tools": True}
        return {"tools": True} if m.get("on") and any(x.get("enabled", True) for x in m.get("servers", [])) else None   # без серверов инструменты не нужны

    def start_scan(self):
        if (self.scan_th and self.scan_th.isRunning()) or not any(router.usable(p) for p in self.cfg["providers"]): return
        need = self.need(); msg = "Ищу модели для MCP… {done}/{total}" if need else "Проверка моделей… {done}/{total}"
        self.scan_th = ScanThread(self.cfg, 6 if need else 4, None, need)
        self.scan_th.progress.connect(lambda d, t, o: self.scan_lbl.setText(T(msg).format(done=d, total=t)))
        self.scan_th.done.connect(self.scan_done); threads.run(self.scan_th)

    def scan_done(self, n):
        txt = T("Подходящих моделей для MCP: {n}") if self.need() else T("Рабочих моделей: {n}")
        self.scan_lbl.setText(txt.format(n=n)); self.refresh_model_btn()

    # ---- управление компьютером
    def on_cursor_move(self, x, y):
        dpr = QGuiApplication.primaryScreen().devicePixelRatio() or 1.0
        self.ai_cursor.move_to(x / dpr, y / dpr, lambda: self.worker and self.worker.cur_done.set())

    def on_cursor_click(self, x, y): self.ai_cursor.click_fx()

    def on_computer_state(self, on):
        if on:
            if (self.cfg.get("computer") or {}).get("minimize", True): self.showMinimized()
            self.ai_banner.show_top(); self.esc_timer.start(60)
        else:
            self.esc_timer.stop(); self.ai_cursor.hide(); self.ai_banner.hide()
            if self.isMinimized(): self.showNormal(); self.raise_(); self.activateWindow()

    def _esc(self):
        if winput.esc_pressed() and self.worker and self.worker.isRunning():
            self.worker.stop(); self.scan_lbl.setText(T("Остановлено (Esc)"))

    def add_all_free(self):
        have = {p["id"] for p in self.cfg["providers"]}
        for pr in presets.PRESETS:
            full = presets.provider(pr)
            if full["id"] not in have: self.cfg["providers"].append(full)
        self.cfg["removed"] = []; config.save(self.cfg); self.scan_lbl.setText(T("Проверка моделей…") ); self.start_scan()

    def _restore(self):
        g = QSettings("Cloudy", "Cloudy").value("geom")
        if g: self.restoreGeometry(g)

    def closeEvent(self, e):
        QSettings("Cloudy", "Cloudy").setValue("geom", self.saveGeometry())
        if (self.cfg.get("tray") or {}).get("close") and getattr(self, "tray", None) and not self._quit and not self._restart:
            e.ignore(); self.hide()
            self.tray.showMessage("Cloudy", T("Cloudy работает в трее. Ctrl+Alt+C — открыть."), QSystemTrayIcon.Information, 2500); return
        try:
            self.esc_timer.stop(); self.ai_cursor.close(); self.ai_banner.close(); self.speaker.stop()
            if getattr(self, "hk", None): self.hk.stop()
            if getattr(self, "tray", None): self.tray.hide()
            threads.stop_all(); mcp.MANAGER.shutdown()
        except Exception:
            pass
        super().closeEvent(e)
        if not self._restart: QApplication.instance().quit()

    # ---- трей, горячая клавиша, первый запуск
    def setup_system(self):
        if QSystemTrayIcon.isSystemTrayAvailable() and not getattr(self, "tray", None):
            self.tray = QSystemTrayIcon(icons.app_icon(), self); self.tray.setToolTip("Cloudy")
            m = QMenu(); m.addAction(T("Открыть Cloudy")).triggered.connect(self.show_window)
            m.addAction(T("Новый чат")).triggered.connect(lambda: (self.show_window(), self.new_chat()))
            m.addSeparator(); m.addAction(T("Выход")).triggered.connect(self.quit_app)
            self._tray_menu = m; self.tray.setContextMenu(m)
            self.tray.activated.connect(lambda r: self.show_window() if r == QSystemTrayIcon.Trigger else None); self.tray.show()
        want = bool((self.cfg.get("tray") or {}).get("hotkey", True)) and os.name == "nt"
        if want and not getattr(self, "hk", None):
            self.hk = hotkey.Hotkey(); self.hk.start()
            self.hk_timer = QTimer(self); self.hk_timer.timeout.connect(self._hk_poll); self.hk_timer.start(120)
        elif not want and getattr(self, "hk", None): self.hk.stop(); self.hk = None; self.hk_timer.stop()

    def _hk_poll(self):
        fired = False
        while self.hk and not self.hk.q.empty(): self.hk.q.get(); fired = True
        if fired: self.hide() if (self.isVisible() and self.isActiveWindow()) else self.show_window()

    def show_window(self):
        self.showNormal(); self.raise_(); self.activateWindow(); self.comp.edit.setFocus()

    def quit_app(self):
        self._quit = True; self.close()

    def maybe_onboard(self):
        if self.cfg.get("onboarded"): return
        old = self.cfg.get("lang", "ru"); d = OnboardingDialog(self.cfg, self); d.exec()
        self.cfg["onboarded"] = True; config.save(self.cfg)
        if d.add_free: self.add_all_free()
        if self.cfg.get("lang") != old: self.restart_ui(); return
        self.apply_theme()

    def refresh_model_btn(self):
        m = self.cfg.get("model") or "auto"; t = T("Авто") if m == "auto" else router.split(m)[1]
        self.model_btn.setText(t if len(t) < 26 else t[:25] + "…")
        on = bool(self.cfg["collab"].get("on")); self.collab_btn.setText(T("Совместная работа: вкл") if on else T("Совместная работа"))
        for b, v in ((self.collab_btn, on), (self.model_btn, False)):
            b.setProperty("on", v); b.style().unpolish(b); b.style().polish(b)
        if hasattr(self, "welcome"): self.welcome.card.setVisible(router.working_count(self.cfg) == 0)

    def pick_model(self):
        d = ModelPicker(self.cfg, self.cfg.get("model", "auto"), True, None, self)
        if d.exec() and d.key: self.cfg["model"] = d.key; config.save(self.cfg); self.refresh_model_btn()

    def open_collab(self):
        CollabDialog(self.cfg, self).exec(); self.refresh_model_btn()

    def restart_ui(self):
        self._restart = True; nw = MainWindow(); QApplication.instance()._win = nw; nw.show(); self.close()

    def open_store(self): StoreDialog(self).exec()

    def open_settings(self):
        old = self.cfg.get("lang", "ru")
        ok = SettingsDialog(self.cfg, self).exec()
        config.save(self.cfg); self.refresh_model_btn(); self.start_scan(); self.setup_system()
        if ok:
            self.apply_theme()
            if self.cfg.get("lang") != old and not self.busy(): self.restart_ui(); return
            if not self.busy(): self.render_chat()
