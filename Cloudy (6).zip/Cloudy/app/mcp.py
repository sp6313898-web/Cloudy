"""Клиент Model Context Protocol: stdio и HTTP (Streamable HTTP). Подключает любые MCP-серверы и отдаёт их инструменты агенту."""
import copy, json, os, re, shutil, subprocess, threading, time
from pathlib import Path
import requests
from .i18n import T

PROTO = "2025-06-18"
FLAG = 0x08000000 if os.name == "nt" else 0
MAX_MCP_TOOLS = 100          # у многих провайдеров лимит ~128 инструментов на запрос (вместе со встроенными)
DROP_KEYS = {"$schema", "$id", "$comment", "additionalProperties", "patternProperties", "examples", "example", "exclusiveMinimum",
             "exclusiveMaximum", "format", "default", "definitions", "$defs", "propertyNames", "unevaluatedProperties", "readOnly", "writeOnly"}


class MCPError(Exception):
    pass


# ---------- разбор аргументов
def split_args(s):
    """Разбивает строку аргументов с учётом кавычек (в том числе внутри токена: --root="C:\\my dir"). Обратные слэши не трогает."""
    if isinstance(s, list): return [str(x) for x in s]
    out, cur, q, has = [], [], None, False
    for ch in s or "":
        if q:
            if ch == q: q = None
            else: cur.append(ch)
        elif ch in "\"'": q = ch; has = True
        elif ch.isspace():
            if cur or has: out.append("".join(cur)); cur = []; has = False
        else: cur.append(ch)
    if cur or has: out.append("".join(cur))
    return out


def join_args(a):
    return " ".join(f'"{x}"' if (" " in x or not x) else x for x in a)


def _extra_paths():
    """Папки, где обычно лежат node/npx/uvx, но которых может не быть в PATH (программа запущена до установки Node/uv)."""
    h, out = Path.home(), []
    if os.name == "nt":
        for v in ("ProgramFiles", "ProgramFiles(x86)"):
            if os.environ.get(v): out.append(os.path.join(os.environ[v], "nodejs"))
        la, ap = os.environ.get("LOCALAPPDATA", ""), os.environ.get("APPDATA", "")
        out += [os.path.join(ap, "npm"), os.path.join(la, "Microsoft", "WinGet", "Links"), str(h / ".local" / "bin"), str(h / ".cargo" / "bin")]
    else:
        out += ["/usr/local/bin", "/opt/homebrew/bin", str(h / ".local" / "bin"), str(h / ".cargo" / "bin")]
    return [p for p in out if p and os.path.isdir(p)]


def build_env(extra):
    env = dict(os.environ)
    have = env.get("PATH", "").split(os.pathsep)
    add = [p for p in _extra_paths() if p not in have]
    if add: env["PATH"] = os.pathsep.join(have + add)
    env.setdefault("PYTHONIOENCODING", "utf-8"); env.setdefault("PYTHONUTF8", "1")   # иначе русские символы роняют Python-серверы на Windows (cp1251)
    env.setdefault("npm_config_yes", "true")                                         # npx не задаёт вопрос «Ok to proceed?» (stdin закрыт для вопросов)
    env.update({k: str(v) for k, v in (extra or {}).items()})
    return env


# ---------- схемы инструментов: убираем то, что отвергают OpenAI-совместимые провайдеры
def clean_schema(s, root=None, depth=0):
    root = root if root is not None else s
    if not isinstance(s, dict) or depth > 12: return {"type": "string"} if depth else {"type": "object", "properties": {}}
    s = dict(s)
    ref = s.pop("$ref", None)
    if isinstance(ref, str) and ref.startswith("#/") and depth < 8:     # встраиваем ссылки на $defs
        node = root
        for part in ref[2:].split("/"):
            node = node.get(part) if isinstance(node, dict) else None
        if isinstance(node, dict): s = {**clean_schema(node, root, depth + 1), **{k: v for k, v in s.items() if k not in DROP_KEYS}}
    for k in ("anyOf", "oneOf"):
        opts = s.pop(k, None)
        if isinstance(opts, list):
            real = [o for o in opts if isinstance(o, dict) and o.get("type") != "null"]
            if real: s = {**clean_schema(real[0], root, depth + 1), **{kk: v for kk, v in s.items() if kk not in ("type", "properties", "items")}}
    al = s.pop("allOf", None)
    if isinstance(al, list) and len(al) == 1 and isinstance(al[0], dict): s = {**clean_schema(al[0], root, depth + 1), **s}
    if "const" in s: s["enum"] = [s.pop("const")]
    t = s.get("type")
    if isinstance(t, list): s["type"] = next((x for x in t if x != "null"), "string")
    for k in DROP_KEYS: s.pop(k, None)
    if isinstance(s.get("properties"), dict):
        s["properties"] = {str(k): clean_schema(v, root, depth + 1) for k, v in s["properties"].items()}
    elif s.get("type") == "object": s["properties"] = {}
    if s.get("type") == "array":
        it = s.get("items")
        if isinstance(it, list): it = it[0] if it else None
        s["items"] = clean_schema(it, root, depth + 1) if isinstance(it, dict) else {"type": "string"}
    if "required" in s:
        props = s.get("properties") or {}
        req = [r for r in s["required"] if isinstance(r, str) and r in props] if isinstance(s["required"], list) else []
        if req: s["required"] = req
        else: s.pop("required")
    if "type" not in s and "enum" not in s and "properties" not in s: s["type"] = "string"
    return s


def top_schema(raw):
    p = clean_schema(copy.deepcopy(raw)) if isinstance(raw, dict) else {}
    if p.get("type") != "object": p = {"type": "object", "properties": {}}
    p.setdefault("properties", {})
    return p


# ---------- подсказки по типовым ошибкам
def explain(err):
    e = str(err or ""); l = e.lower(); hint = ""
    if re.search(r"команда не найдена|not recognized|no such file|cannot find|enoent|winerror 2", l):
        hint = T("Не найдена программа запуска. Установите Node.js (для npx) или uv (для uvx), затем ПОЛНОСТЬЮ перезапустите Cloudy.")
    elif re.search(r"таймаут|timed out|timeout", l):
        hint = T("Сервер не ответил вовремя. При первом запуске npx/uvx качает пакет (до пары минут): повторите проверку. Если не помогает - запустите команду вручную в терминале.")
    elif re.search(r"сервер завершился|server exited|exited", l):
        hint = T("Процесс сервера завершился сразу после запуска. Причина обычно видна в тексте ошибки выше: неверные аргументы, нет прав или нет интернета.")
    elif "http 401" in l or "http 403" in l or "unauthorized" in l:
        hint = T("Сервер требует авторизацию: добавьте заголовок Authorization: Bearer <токен> в поле «Заголовки».")
    elif "http 404" in l:
        hint = T("Адрес не найден. Проверьте URL (обычно заканчивается на /mcp). Адреса вида /sse - старый протокол, он не поддерживается.")
    elif "http 405" in l or "/sse" in l:
        hint = T("Похоже, это устаревший SSE-эндпоинт. Нужен адрес Streamable HTTP (обычно /mcp).")
    elif re.search(r"connection|connect|resolve|ssl", l):
        hint = T("Нет соединения с сервером: проверьте адрес, интернет, VPN и прокси.")
    elif re.search(r"access denied|outside allowed|not allowed", l):
        hint = T("Сервер Filesystem видит только папку, указанную в аргументах. Укажите нужную папку или {workspace}.")
    return e + ("\n\n" + T("Подсказка: ") + hint if hint else "")


class Server:
    def __init__(self, cfg):
        self.cfg, self.proc, self.pending, self.nid, self.sess, self.ver = cfg, None, {}, 0, None, PROTO
        self.tools, self.err, self.ok = [], "", False
        self.lock, self.wlock = threading.Lock(), threading.Lock()
        self.name = cfg.get("name") or cfg.get("id", "mcp")
        self._threads = []

    @property
    def http(self): return self.cfg.get("transport", "stdio") == "http"

    def alive(self):
        if self.http: return self.ok
        return bool(self.proc) and self.proc.poll() is None and self.ok

    # ---------- запуск
    def _spawn(self):
        cmd = (self.cfg.get("command") or "").strip()
        if not cmd: raise MCPError(T("Не указана команда"))
        args = split_args(self.cfg.get("args"))
        if " " in cmd and not os.path.exists(cmd):          # вся строка вставлена в поле «Команда»
            parts = split_args(cmd); cmd, args = parts[0], parts[1:] + args
        ws = self.cfg.get("_ws", ".")
        args = [a.replace("{workspace}", ws) for a in args]
        env = build_env(self.cfg.get("env"))
        if os.path.basename(cmd).lower().split(".")[0] == "npx" and not any(a in ("-y", "--yes") for a in args): args = ["-y"] + args
        exe = shutil.which(cmd, path=env.get("PATH")) or cmd
        try:
            self.proc = subprocess.Popen([exe] + args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
                                         creationflags=FLAG, cwd=ws if os.path.isdir(ws) else None)
        except FileNotFoundError:
            raise MCPError(T("Команда не найдена: {cmd}. Установите Node.js (npx) или uv (uvx).").format(cmd=cmd))
        except OSError as ex:
            raise MCPError(f"{cmd}: {ex}")
        self._threads = [threading.Thread(target=self._read, daemon=True), threading.Thread(target=self._drain, daemon=True)]
        for t in self._threads: t.start()

    def start(self, timeout=120):
        self.err, self.sess, self.ok = "", None, False
        if self.http:
            if not self.cfg.get("url"): raise MCPError(T("Не указан URL"))
        else: self._spawn()
        res = self.request("initialize", {"protocolVersion": PROTO, "capabilities": {}, "clientInfo": {"name": "Cloudy", "version": "1.1"}}, timeout)
        self.ver = (res or {}).get("protocolVersion") or PROTO
        self.notify("notifications/initialized"); self.ok = True; self.tools = self.list_tools()

    def restart(self):
        self.stop(); self.pending = {}; self.start(60)

    def stop(self):
        self.ok = False
        p, self.proc = self.proc, None
        if p:
            try: p.terminate(); p.wait(2)
            except Exception:
                try: p.kill()
                except Exception: pass
            for s in (p.stdin, p.stdout, p.stderr):
                try: s.close()
                except Exception: pass

    # ---------- stdio
    def _write(self, obj):
        data = (json.dumps(obj) + "\n").encode()
        with self.wlock:
            self.proc.stdin.write(data); self.proc.stdin.flush()

    def _drain(self):
        try:
            for raw in self.proc.stderr: self.err = (self.err + raw.decode("utf-8", "replace"))[-1500:]
        except Exception: pass

    def _read(self):
        proc = self.proc
        try:
            for raw in proc.stdout:
                try: m = json.loads(raw.decode("utf-8", "replace"))
                except Exception: continue          # строки логов в stdout игнорируем
                if not isinstance(m, dict): continue
                if "method" in m and "id" in m:   # запрос от сервера
                    meth = m["method"]
                    try:
                        if meth == "ping": self._write({"jsonrpc": "2.0", "id": m["id"], "result": {}})
                        elif meth == "roots/list": self._write({"jsonrpc": "2.0", "id": m["id"], "result": {"roots": [{"uri": Path(self.cfg.get("_ws", ".")).resolve().as_uri(), "name": "workspace"}]}})
                        else: self._write({"jsonrpc": "2.0", "id": m["id"], "error": {"code": -32601, "message": "Method not found"}})
                    except Exception: pass
                elif "id" in m and m["id"] in self.pending:
                    ev, box = self.pending.pop(m["id"]); box["msg"] = m; ev.set()
        except Exception: pass
        self.ok = False
        for t in self._threads:                       # даём stderr дочитаться, чтобы в ошибке была причина
            if t is not threading.current_thread(): t.join(0.7)
        for ev, box in list(self.pending.values()):
            box["msg"] = {"error": {"message": T("Сервер завершился. ") + self.err[-400:]}}; ev.set()
        self.pending.clear()

    # ---------- JSON-RPC
    def request(self, method, params=None, timeout=120):
        if self.http: return self._http(method, params, timeout)
        if self.proc is None or self.proc.poll() is not None:
            raise MCPError(T("Сервер завершился. ") + self.err[-400:])
        with self.lock:
            self.nid += 1; i = self.nid; ev, box = threading.Event(), {}; self.pending[i] = (ev, box)
        try: self._write({"jsonrpc": "2.0", "id": i, "method": method, "params": params or {}})
        except Exception as ex: self.pending.pop(i, None); raise MCPError(f"{ex}. {self.err[-300:]}")
        if self.proc.poll() is not None and not ev.is_set(): ev.wait(1.5)
        if not ev.wait(timeout): self.pending.pop(i, None); raise MCPError(T("Таймаут ответа MCP-сервера.") + " " + self.err[-300:])
        return self._result(box["msg"])

    def notify(self, method, params=None):
        try:
            if self.http: self._http(method, params, 15, notify=True)
            else: self._write({"jsonrpc": "2.0", "method": method, "params": params or {}})
        except Exception: pass

    @staticmethod
    def _result(m):
        if "error" in m: raise MCPError(str((m["error"] or {}).get("message", m["error"])))
        return m.get("result") or {}

    def _http(self, method, params, timeout, notify=False, retry=True):
        with self.lock:
            self.nid += 1; i = self.nid
        payload = {"jsonrpc": "2.0", "method": method, "params": params or {}}
        if not notify: payload["id"] = i
        h = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
        h.update(self.cfg.get("headers") or {})
        if self.sess: h["Mcp-Session-Id"] = self.sess
        if method != "initialize": h["MCP-Protocol-Version"] = self.ver
        try: r = requests.post(self.cfg["url"], json=payload, headers=h, stream=True, timeout=(15, timeout))
        except requests.RequestException as ex: raise MCPError(f"{type(ex).__name__}: {str(ex)[:200]}")
        try:
            if r.status_code == 404 and self.sess and method != "initialize" and retry:     # сессия истекла - открываем заново
                self.sess = None
                self.request("initialize", {"protocolVersion": PROTO, "capabilities": {}, "clientInfo": {"name": "Cloudy", "version": "1.1"}}, 60)
                self.notify("notifications/initialized")
                return self._http(method, params, timeout, notify, retry=False)
            if r.status_code >= 400: raise MCPError(f"HTTP {r.status_code}: {r.text[:200]}")
            self.sess = r.headers.get("Mcp-Session-Id") or self.sess
            if notify: return {}
            if "text/event-stream" in r.headers.get("Content-Type", ""):
                for raw in r.iter_lines():
                    line = raw.decode("utf-8", "replace")
                    if line.startswith("data:"):
                        try: m = json.loads(line[5:].strip())
                        except Exception: continue
                        if isinstance(m, dict) and m.get("id") == i and ("result" in m or "error" in m): return self._result(m)
                raise MCPError(T("Пустой ответ сервера"))
            try: j = r.json()
            except Exception: raise MCPError(T("Сервер вернул не JSON: ") + r.text[:150])
            for m in (j if isinstance(j, list) else [j]):
                if isinstance(m, dict) and m.get("id") == i: return self._result(m)
            raise MCPError(T("Пустой ответ сервера"))
        finally:
            r.close()

    # ---------- инструменты
    def list_tools(self):
        out, cur = [], None
        for _ in range(20):
            r = self.request("tools/list", {"cursor": cur} if cur else {}, 60); out += [t for t in r.get("tools", []) if isinstance(t, dict) and t.get("name")]; cur = r.get("nextCursor")
            if not cur: break
        return out

    def call(self, tool, args, timeout=180):
        """-> (текст, [data URL картинок])"""
        r = self.request("tools/call", {"name": tool, "arguments": args if isinstance(args, dict) else {}}, timeout); text, imgs = [], []
        for c in r.get("content") or []:
            t = c.get("type")
            if t == "text": text.append(c.get("text", ""))
            elif t == "image": imgs.append(f"data:{c.get('mimeType', 'image/png')};base64,{c.get('data', '')}")
            elif t == "resource":
                res = c.get("resource", {}); text.append(res.get("text") or f"[resource {res.get('uri', '')}]")
            else: text.append(json.dumps(c, ensure_ascii=False)[:500])
        if not text and not imgs and r.get("structuredContent") is not None: text.append(json.dumps(r["structuredContent"], ensure_ascii=False))
        s = "\n".join(text)[:12000] or (T("(изображение)") if imgs else T("(пусто)"))
        return ((T("Ошибка MCP: ") + s) if r.get("isError") else s), imgs


def _sig(c, ws_sensitive=False):
    d = {k: v for k, v in c.items() if not k.startswith("_")}
    if "{workspace}" in str(c.get("args", "")) or "{workspace}" in str(c.get("command", "")): d["_ws"] = c.get("_ws")   # сменилась папка проекта - перезапуск
    return json.dumps(d, sort_keys=True, default=str)


class Manager:
    def __init__(self):
        self.servers, self.map, self.errors, self.failed, self.lock = {}, {}, {}, {}, threading.RLock()

    def ensure(self, servers, workspace=".", status=None):
        want = {s["id"]: dict(s, _ws=workspace) for s in servers if s.get("enabled", True)}
        with self.lock:
            for sid in list(self.servers):
                if sid not in want or _sig(self.servers[sid].cfg) != _sig(want[sid]) or not self.servers[sid].alive():   # упавший сервер перезапускаем
                    self.servers.pop(sid).stop(); self.failed.pop(sid, None) if sid in want else None
            for sid in list(self.errors):
                if sid not in want: self.errors.pop(sid, None)
            for sid, s in want.items():
                if sid in self.servers or time.time() - self.failed.get(sid, 0) < 45: continue
                if status: status(T("Запуск MCP: {name}").format(name=s.get("name") or sid))
                srv = Server(s)
                try: srv.start(); self.servers[sid] = srv; self.errors.pop(sid, None)
                except Exception as ex: self.errors[sid] = (s.get("name") or sid, str(ex)); self.failed[sid] = time.time(); srv.stop()
            self.map = {}
            for sid, srv in self.servers.items():
                for t in srv.tools:
                    full = re.sub(r"[^A-Za-z0-9_-]", "_", f"mcp_{sid[:10]}_{t['name']}")[:64]
                    while full in self.map: full = full[:-1] + "x"
                    self.map[full] = (srv, t)

    def schemas(self, limit=MAX_MCP_TOOLS):
        out = []
        for full, (srv, t) in list(self.map.items())[:limit]:
            out.append({"type": "function", "function": {"name": full, "description": f"[MCP {srv.name}] " + str(t.get("description") or t["name"])[:600],
                                                         "parameters": top_schema(t.get("inputSchema"))}})
        return out

    def has(self, name): return name in self.map

    def auto(self, name): return bool(self.map[name][0].cfg.get("auto"))

    def label(self, name): return f"{self.map[name][0].name}: {self.map[name][1]['name']}"

    def call(self, name, args):
        srv, t = self.map[name]
        if not srv.alive():
            try: srv.restart()
            except Exception as ex: raise MCPError(T("Сервер MCP остановился и не перезапускается: ") + str(ex))
        return srv.call(t["name"], args)

    def shutdown(self):
        with self.lock:
            for s in self.servers.values(): s.stop()
            self.servers.clear(); self.map.clear()


def import_json(text):
    """Формат Claude Desktop / Cursor: {"mcpServers": {"имя": {"command": ..., "args": [...], "env": {...}}}} или {"имя": {...}} или один сервер."""
    import uuid
    data = json.loads(text)
    if not isinstance(data, dict): raise ValueError("ожидался объект JSON")
    for k in ("mcpServers", "servers", "mcp_servers"):
        if isinstance(data.get(k), dict): data = data[k]; break
    if "command" in data or "url" in data: data = {"MCP": data}
    out = []
    for name, c in data.items():
        if not isinstance(c, dict) or not (c.get("command") or c.get("url") or c.get("serverUrl")): continue
        http = bool(c.get("url") or c.get("serverUrl")) and not c.get("command")
        out.append({"id": uuid.uuid4().hex[:8], "name": str(name)[:40], "transport": "http" if http else "stdio", "command": str(c.get("command") or ""),
                    "args": join_args([str(x) for x in c["args"]]) if isinstance(c.get("args"), list) else str(c.get("args") or ""),
                    "env": {str(k): str(v) for k, v in (c.get("env") or {}).items()}, "url": str(c.get("url") or c.get("serverUrl") or ""),
                    "headers": {str(k): str(v) for k, v in (c.get("headers") or {}).items()}, "enabled": not c.get("disabled", False), "auto": False})
    if not out: raise ValueError("не найдено ни одного сервера (нужны поля command или url)")
    return out


MANAGER = Manager()
