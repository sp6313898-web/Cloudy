"""Собственные векторные иконки (SVG, рисуются кодом) — вместо эмодзи."""
from PySide6.QtCore import Qt, QByteArray, QSize
from PySide6.QtGui import QPixmap, QPainter, QIcon
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QAbstractButton
from .config import base_dir

COLOR = {"c": "#1F1E1D"}
SHAPES = {
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "menu": '<path d="M4 6h16M4 12h16M4 18h16"/>',
    "close": '<path d="M6 6l12 12M18 6L6 18"/>',
    "send": '<path d="M12 19V6M6 12l6-6 6 6"/>',
    "stop": '<rect x="7" y="7" width="10" height="10" rx="2" fill="CUR"/>',
    "attach": '<g transform="translate(0 2)"><path d="M10 17V7.5a2 2 0 0 1 4 0V16.5a4 4 0 0 1-8 0V6.5a6 6 0 0 1 12 0V17"/></g>',
    "mic": '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/>',
    "speaker": '<path d="M4 10h4l5-4v12l-5-4H4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
    "chat": '<rect x="4" y="5" width="16" height="11" rx="3"/><path d="M9 16v4l4-4"/>',
    "blocks": '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><path d="M16.5 13v7M13 16.5h7"/>',
    "sliders": '<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="9" cy="7" r="2.2" fill="CUR"/><circle cx="15" cy="12" r="2.2" fill="CUR"/><circle cx="8" cy="17" r="2.2" fill="CUR"/>',
    "terminal": '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M7 10l3 2-3 2M12 15h5"/>',
    "check": '<path d="M5 12.5l5 5L19 7.5"/>',
    "chev_r": '<path d="M9 6l6 6-6 6"/>',
    "chev_d": '<path d="M6 9l6 6 6-6"/>',
    "folder": '<path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    "file": '<path d="M7 3h7l4 4v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M14 3v4h4"/>',
    "artifact": '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M10 9l-3 3 3 3M14 9l3 3-3 3"/>',
    "trash": '<path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12M10 11v5M14 11v5"/>',
    "copy": '<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    "save": '<path d="M12 4v11M7 10.5l5 5 5-5M5 19h14"/>',
    "external": '<path d="M14 4h6v6M20 4l-9 9M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>',
    "image": '<rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="9" cy="10" r="1.5" fill="CUR"/><path d="M4 17l5-5 4 4 3-3 4 4"/>',
    "layers": '<path d="M12 4l8 4-8 4-8-4z"/><path d="M4 12l8 4 8-4M4 16l8 4 8-4"/>',
    "edit": '<path d="M5 19l1-4L16 5l3 3L9 18z"/>',
    "warn": '<path d="M12 4l9 16H3z"/><path d="M12 10v4M12 17.2v.1"/>',
    "eye": '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
    "cpu": '<rect x="6" y="6" width="12" height="12" rx="2.5"/><rect x="10" y="10" width="4" height="4" fill="CUR"/><path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3"/>',
    "network": '<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="M8.2 7.4l2.5 8.2M15.8 7.4l-2.5 8.2M8.5 6h7"/>',
    "refresh": '<path d="M20 11a8 8 0 0 0-14.5-3.5M4 4v4h4M4 13a8 8 0 0 0 14.5 3.5M20 20v-4h-4"/>',
    "search": '<circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/>',
    "pin": '<path d="M9 4h6l-1 5 3 3H7l3-3z"/><path d="M12 12v8"/>',
    "info": '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8v.1"/>',
    "globe": '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c3 3.2 3 13.8 0 17M12 3.5c-3 3.2-3 13.8 0 17"/>',
    "undo": '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
    "code": '<path d="M9 7l-5 5 5 5M15 7l5 5-5 5"/>',
}


def svg(name, color):
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%s" stroke-width="1.8" '
            'stroke-linecap="round" stroke-linejoin="round">%s</svg>' % (color, SHAPES[name].replace("CUR", color)))


def pix(name, color=None, size=18, dpr=2):
    r = QSvgRenderer(QByteArray(svg(name, color or COLOR["c"]).encode()))
    pm = QPixmap(size * dpr, size * dpr); pm.fill(Qt.transparent)
    p = QPainter(pm); r.render(p); p.end(); pm.setDevicePixelRatio(dpr)
    return pm


def set_ic(btn, name, white=False, size=18):
    btn.setProperty("ic", name); btn.setProperty("icw", white); btn.setProperty("ics", size)
    btn.setIcon(QIcon(pix(name, "#FFFFFF" if white else None, size))); btn.setIconSize(QSize(size, size))


def refresh(root):
    for b in root.findChildren(QAbstractButton):
        n = b.property("ic")
        if n:
            set_ic(b, n, bool(b.property("icw")), int(b.property("ics") or 18))


def app_icon() -> QIcon:
    f = base_dir() / "assets" / "icon.png"
    return QIcon(str(f)) if f.exists() else QIcon()
