"""Управление компьютером: ИИ видит экран (скриншоты), двигает собственный чёрный курсор, нажимает и печатает."""
import time
from . import winput
from .i18n import T


def _fn(name, desc, props, req):
    return {"type": "function", "function": {"name": name, "description": desc, "parameters": {"type": "object", "properties": props, "required": req}}}


I, S, N = {"type": "integer"}, {"type": "string"}, {"type": "number"}
SCHEMAS = [
    _fn("computer_screenshot", "Сделать скриншот экрана. Начинай с него. Координаты всех действий — в пикселях этого скриншота.", {}, []),
    _fn("computer_click", "Кликнуть по точке (x, y) скриншота. button: left|right|middle, double: двойной клик.", {"x": I, "y": I, "button": S, "double": {"type": "boolean"}}, ["x", "y"]),
    _fn("computer_move", "Переместить курсор ИИ в точку (x, y) без клика.", {"x": I, "y": I}, ["x", "y"]),
    _fn("computer_drag", "Перетащить мышью из (x1, y1) в (x2, y2).", {"x1": I, "y1": I, "x2": I, "y2": I}, ["x1", "y1", "x2", "y2"]),
    _fn("computer_scroll", "Прокрутить колесо в точке (x, y): amount > 0 вниз, < 0 вверх (в «щелчках»).", {"x": I, "y": I, "amount": I}, ["x", "y", "amount"]),
    _fn("computer_type", "Напечатать текст в элементе, который сейчас в фокусе (сначала кликни по полю).", {"text": S}, ["text"]),
    _fn("computer_key", "Нажать клавишу или сочетание: enter, tab, esc, backspace, ctrl+c, alt+tab, win, f5, ctrl+shift+t.", {"keys": S}, ["keys"]),
    _fn("computer_wait", "Подождать секунды (до 10) и сделать новый скриншот.", {"seconds": N}, []),
]
NAMES = {s["function"]["name"] for s in SCHEMAS}

PROMPT = """Управление компьютером включено: ты видишь экран пользователя через скриншоты и можешь двигать свой чёрный курсор, кликать и печатать.
Правила: сначала computer_screenshot; координаты бери с последнего скриншота; делай по одному действию и проверяй результат на новом скриншоте
(после каждого действия приходит свежий скриншот); для ввода сначала кликни по полю. Перед необратимыми действиями (покупка, удаление,
отправка сообщений, платежи, смена паролей) спроси пользователя. Не вводи пароли и коды, если пользователь не дал их сам.
Если пользователь нажал Esc — немедленно остановись. Окно Cloudy на это время свёрнуто."""


class ComputerUse:
    def __init__(self, w):
        self.w, self.started, self.size, self.scale, self.off = w, False, None, 1.0, (0, 0)

    def _begin(self):
        if not self.started:
            self.started = True; self.w.computer_state.emit(True); time.sleep(0.9)

    def shot(self):
        url, size, scale, off = winput.screenshot(); self.size, self.scale, self.off = size, scale, off
        return url

    def _px(self, x, y):
        w, h = self.size
        return self.off[0] + round(max(0, min(int(x), w - 1)) * self.scale), self.off[1] + round(max(0, min(int(y), h - 1)) * self.scale)

    def _fx(self, px, py, click=False):
        self.w.cur_done.clear(); self.w.cursor_move.emit(px, py); self.w.cur_done.wait(2.5)
        if click: self.w.cursor_click.emit(px, py); time.sleep(0.15)

    def run(self, name, a):
        """-> (текст результата, data URL скриншота или None)"""
        if self.w._stop or winput.esc_pressed():
            self.w.stop(); return T("Остановлено пользователем."), None
        self._begin()
        try:
            if name == "computer_screenshot":
                url = self.shot(); return f"Скриншот {self.size[0]}x{self.size[1]}. Координаты — в пикселях скриншота.", url
            if self.size is None: self.shot()
            if name == "computer_wait":
                time.sleep(max(0.0, min(float(a.get("seconds") or 1), 10))); return "Ожидание завершено.", self.shot()
            saved = winput.cursor_pos(); msg = ""
            try:
                if name in ("computer_click", "computer_move"):
                    px, py = self._px(a["x"], a["y"]); self._fx(px, py, name == "computer_click")
                    if name == "computer_click":
                        winput.click(px, py, a.get("button") or "left", 2 if a.get("double") else 1)
                    msg = f"{'Клик' if name == 'computer_click' else 'Курсор'}: ({a['x']}, {a['y']})"
                elif name == "computer_drag":
                    p1, p2 = self._px(a["x1"], a["y1"]), self._px(a["x2"], a["y2"]); self._fx(*p1); self.w.cursor_click.emit(*p1)
                    winput.drag(*p1, *p2); self._fx(*p2); msg = "Перетаскивание выполнено."
                elif name == "computer_scroll":
                    px, py = self._px(a["x"], a["y"]); self._fx(px, py); winput.scroll(px, py, int(a["amount"])); msg = "Прокрутка выполнена."
                elif name == "computer_type":
                    winput.type_text(str(a["text"])); msg = f"Напечатано {len(str(a['text']))} символов."
                elif name == "computer_key":
                    winput.press(str(a["keys"])); msg = f"Нажато: {a['keys']}"
                else:
                    return "Неизвестное действие.", None
            finally:
                winput.set_cursor(*saved)
            time.sleep(0.55); return msg + " Ниже новый скриншот.", self.shot()
        except Exception as ex:
            return f"Ошибка: {ex}", None
