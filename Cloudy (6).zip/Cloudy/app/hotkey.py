"""Глобальная горячая клавиша Windows (по умолчанию Ctrl+Alt+C): показать/скрыть Cloudy из любого окна."""
import os, queue, threading

if os.name == "nt":
    import ctypes
    from ctypes import wintypes
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32


class Hotkey:
    def __init__(self):
        self.q = queue.Queue(); self.tid = None; self.ok = False

    def start(self, mods=0x1 | 0x2, vk=0x43):
        if os.name != "nt": return False
        ready = threading.Event()

        def loop():
            self.tid = kernel32.GetCurrentThreadId()
            self.ok = bool(user32.RegisterHotKey(None, 1, mods | 0x4000, vk)); ready.set()
            if not self.ok: return
            msg = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == 0x0312: self.q.put(1)
            user32.UnregisterHotKey(None, 1)
        threading.Thread(target=loop, daemon=True).start(); ready.wait(2)
        return self.ok

    def stop(self):
        if os.name == "nt" and self.tid:
            try: user32.PostThreadMessageW(self.tid, 0x0012, 0, 0)
            except Exception: pass
        self.tid = None; self.ok = False
