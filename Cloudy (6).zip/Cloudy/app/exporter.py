"""Экспорт чата: Markdown, HTML, JSON."""
import html, json, time


def _text(m):
    c = m.get("content")
    if isinstance(c, list): return "\n".join(p.get("text", "[изображение]") if p.get("type") == "text" else "[изображение]" for p in c)
    return c or ""


def to_markdown(chat, lang="ru"):
    me, ai = ("Вы", "Cloudy") if lang == "ru" else ("You", "Cloudy")
    out = [f"# {chat.get('title', 'Chat')}", "", f"_{time.strftime('%Y-%m-%d %H:%M', time.localtime(chat.get('created', time.time())))}_", ""]
    for m in chat.get("messages", []):
        if m.get("_screen"): continue
        if m["role"] == "user": out += [f"## {me}", "", m.get("_text") or _text(m), ""]
        elif m["role"] == "assistant":
            if _text(m): out += [f"## {ai}" + (f"  ·  {m['_model']}" if m.get("_model") else ""), "", _text(m), ""]
            for tc in m.get("tool_calls") or []:
                name = tc["function"]["name"]
                if name != "create_artifact": out.append(f"> [tool] {name}")
    for aid, a in (chat.get("artifacts") or {}).items():
        lang_tag = {"html": "html", "svg": "xml", "markdown": "markdown"}.get(a.get("type"), a.get("language", ""))
        out += ["", f"### {a.get('title', aid)}", "", "```" + lang_tag, a["versions"][-1] if a.get("versions") else "", "```", ""]
    return "\n".join(out)


def to_html(chat, lang="ru"):
    rows = []
    for m in chat.get("messages", []):
        if m.get("_screen"): continue
        if m["role"] == "user": rows.append(f"<div class='u'>{html.escape(m.get('_text') or _text(m))}</div>")
        elif m["role"] == "assistant" and _text(m): rows.append(f"<div class='a'>{html.escape(_text(m))}</div>")
    return ("<!doctype html><meta charset='utf-8'><title>%s</title><style>body{font:16px/1.6 'Segoe UI',sans-serif;background:#FAF9F5;color:#1F1E1D;max-width:760px;margin:40px auto;padding:0 16px}"
            "h1{font-family:Georgia,serif}.u{background:#EFEDE4;border-radius:16px;padding:10px 14px;margin:16px 0 16px 80px;white-space:pre-wrap}"
            ".a{margin:16px 0;white-space:pre-wrap}</style><h1>%s</h1>%s" % (html.escape(chat.get("title", "")), html.escape(chat.get("title", "")), "".join(rows)))


def to_json(chat):
    slim = dict(chat, messages=[m for m in chat.get("messages", []) if not m.get("_screen")])
    return json.dumps(slim, ensure_ascii=False, indent=1)
