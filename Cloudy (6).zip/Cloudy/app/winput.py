"""Экран, мышь и клавиатура Windows без сторонних зависимостей ввода (ctypes SendInput). Скриншоты: mss + Pillow."""
import base64, io, os, time

NT = os.name == "nt"
LAST = [0.0]
if NT:
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    ULONG_PTR = ctypes.c_size_t

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class _U(ctypes.Union):
        _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", _U)]

VK = {"enter": 0x0D, "return": 0x0D, "tab": 9, "esc": 0x1B, "escape": 0x1B, "space": 0x20, "backspace": 8, "delete": 0x2E, "del": 0x2E, "insert": 0x2D,
      "home": 0x24, "end": 0x23, "pageup": 0x21, "pgup": 0x21, "pagedown": 0x22, "pgdn": 0x22, "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
      "ctrl": 0x11, "control": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B, "cmd": 0x5B, "meta": 0x5B, "super": 0x5B, "capslock": 0x14,
      "printscreen": 0x2C, "menu": 0x5D, "-": 0xBD, "=": 0xBB, ",": 0xBC, ".": 0xBE, "/": 0xBF, ";": 0xBA, "'": 0xDE, "[": 0xDB, "]": 0xDD, "\\": 0xDC, "`": 0xC0}
for i in range(1, 13): VK[f"f{i}"] = 0x6F + i
EXT = {0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E}


def available() -> bool:
    if not NT: return False
    try:
        import mss, PIL  # noqa
        return True
    except Exception:
        return False


def mark(): LAST[0] = time.time()


def esc_pressed() -> bool:
    """Аварийная остановка: физический Esc (нажатия самого ИИ не считаются)."""
    return NT and bool(user32.GetAsyncKeyState(0x1B) & 0x8000) and time.time() - LAST[0] > 0.4


def _send(*items):
    arr = (INPUT * len(items))(*items); user32.SendInput(len(items), arr, ctypes.sizeof(INPUT))


def _m(flags, data=0): return INPUT(0, _U(mi=MOUSEINPUT(0, 0, data & 0xFFFFFFFF, flags, 0, 0)))


def _k(vk=0, scan=0, flags=0): return INPUT(1, _U(ki=KEYBDINPUT(vk, scan, flags, 0, 0)))


def cursor_pos():
    pt = wintypes.POINT(); user32.GetCursorPos(ctypes.byref(pt)); return pt.x, pt.y


def set_cursor(x, y): user32.SetCursorPos(int(x), int(y))


BTN = {"left": (0x2, 0x4), "right": (0x8, 0x10), "middle": (0x20, 0x40)}


def click(x, y, button="left", count=1):
    mark(); set_cursor(x, y); time.sleep(0.05); d, u = BTN.get(button, BTN["left"])
    for _ in range(max(1, min(count, 3))): _send(_m(d)); time.sleep(0.03); _send(_m(u)); time.sleep(0.08)
    mark()


def drag(x1, y1, x2, y2):
    mark(); set_cursor(x1, y1); time.sleep(0.08); _send(_m(0x2))
    for i in range(1, 21): set_cursor(x1 + (x2 - x1) * i / 20, y1 + (y2 - y1) * i / 20); time.sleep(0.012)
    time.sleep(0.05); _send(_m(0x4)); mark()


def scroll(x, y, amount):
    mark(); set_cursor(x, y); time.sleep(0.05); _send(_m(0x800, int(-amount * 120))); mark()


def _vk(name):
    n = name.strip().lower()
    if n in VK: return VK[n]
    if len(n) == 1 and n.isalnum(): return ord(n.upper())
    raise ValueError("Неизвестная клавиша: " + name)


def _key(vk, up=False): return _k(vk, 0, (0x1 if vk in EXT else 0) | (0x2 if up else 0))


def press(combo):
    """Например: enter, ctrl+c, alt+tab, ctrl+shift+t."""
    mark(); keys = [_vk(p) for p in combo.replace(" ", "").split("+") if p]
    for v in keys: _send(_key(v)); time.sleep(0.02)
    time.sleep(0.04)
    for v in reversed(keys): _send(_key(v, True)); time.sleep(0.02)
    mark()


def type_text(text):
    mark()
    for ch in text[:3000]:
        if ch == "\n": press("enter"); continue
        data = ch.encode("utf-16-le")
        for i in range(0, len(data), 2):
            u = int.from_bytes(data[i:i + 2], "little"); _send(_k(0, u, 0x4)); _send(_k(0, u, 0x6))
        time.sleep(0.006)
    mark()


def screenshot(max_w=1280, quality=70):
    """Основной монитор -> (data URL JPEG, (w, h) картинки, масштаб, (left, top))."""
    import mss
    from PIL import Image
    with mss.mss() as s:
        mon = s.monitors[1]; raw = s.grab(mon)
    img = Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX"); scale = 1.0
    if img.width > max_w:
        scale = img.width / max_w; img = img.resize((max_w, int(img.height / scale)), Image.LANCZOS)
    buf = io.BytesIO(); img.save(buf, "JPEG", quality=quality)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode(), img.size, scale, (mon["left"], mon["top"])
