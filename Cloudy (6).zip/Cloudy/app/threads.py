"""Реестр потоков: поток не удаляется, пока работает (частая причина вылетов Qt), и корректно останавливается при выходе."""
_live = set()


def run(th):
    _live.add(th)
    th.finished.connect(lambda t=th: _live.discard(t))
    th.start()
    return th


def stop_all(timeout=2500):
    for t in list(_live):
        try:
            if hasattr(t, "stop"): t.stop()
        except Exception: pass
    for t in list(_live):
        try:
            if not t.wait(timeout): t.terminate(); t.wait(500)
        except Exception: pass
