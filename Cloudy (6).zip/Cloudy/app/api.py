import json, time
import requests
from .i18n import T


class ApiError(RuntimeError):
    def __init__(self, status, text):
        super().__init__(T("Ошибка API {status}: {text}").format(status=status, text=text)); self.status = status


def key_of(p): return p.get("api_key") or p.get("default_key") or ""


def headers(p):
    h = {"Content-Type": "application/json"}
    if key_of(p): h["Authorization"] = "Bearer " + key_of(p)
    return h


def chat_url(p): return p.get("chat_url") or p["base_url"].rstrip("/") + "/chat/completions"


def models_url(p): return p.get("models_url") or p["base_url"].rstrip("/") + "/models"


def chat_once(p, model, timeout=(8, 15)):
    """Крошечный запрос для проверки, что модель реально отвечает."""
    body = {"model": model, "messages": [{"role": "user", "content": "Reply with the single word: ok"}], "max_tokens": 8, "stream": False}
    r = requests.post(chat_url(p), headers=headers(p), json=body, timeout=timeout)
    if r.status_code != 200: raise ApiError(r.status_code, r.text[:300])
    if not r.json().get("choices"): raise RuntimeError(T("Пустой ответ"))
    return True


def stream(p, model, messages, tools, timeout=(15, 120)):
    """Потоковый запрос. События: ("text", s) ("reasoning", s) ("tools", [ {id,name,arguments} ])"""
    if not ("deepseek" in model.lower() or "deepseek" in (p.get("base_url") or "").lower()):   # у Groq/Mistral/OpenAI лишнее поле даёт 400
        messages = [{k: v for k, v in m.items() if k != "reasoning_content"} for m in messages]
    body = {"model": model, "messages": messages, "stream": True}
    if tools: body["tools"] = tools
    r = requests.post(chat_url(p), headers=headers(p), json=body, stream=True, timeout=timeout)
    if r.status_code != 200: raise ApiError(r.status_code, r.text[:600])
    calls = {}
    for raw in r.iter_lines():
        if not raw: continue
        line = raw.decode("utf-8", "replace").strip()
        if not line.startswith("data:"): continue
        data = line[5:].strip()
        if data == "[DONE]": break
        try: obj = json.loads(data)
        except Exception: continue
        if isinstance(obj, dict) and obj.get("error") and not obj.get("choices"):      # ошибка внутри потока (HTTP 200)
            e = obj["error"]; raise ApiError(e.get("code", 200) if isinstance(e, dict) and isinstance(e.get("code"), int) else 200, str(e.get("message", e) if isinstance(e, dict) else e)[:400])
        try: ch = obj["choices"][0]
        except Exception: continue
        d = ch.get("delta") or {}
        if d.get("reasoning_content"): yield "reasoning", d["reasoning_content"]
        if d.get("content"): yield "text", d["content"]
        for tc in d.get("tool_calls") or []:
            ix = tc.get("index", 0)
            if tc.get("id") and ix in calls and calls[ix]["id"] and calls[ix]["id"] != tc["id"]:   # провайдер шлёт разные вызовы с одним index
                ix = max(calls) + 1
            c = calls.setdefault(ix, {"id": "", "name": "", "arguments": ""})
            if tc.get("id"): c["id"] = tc["id"]
            fn = tc.get("function") or {}
            if fn.get("name"): c["name"] += fn["name"]
            if fn.get("arguments"): c["arguments"] += fn["arguments"]
    if calls:
        out = [calls[i] for i in sorted(calls) if calls[i]["name"]]
        for n, c in enumerate(out):
            if not c["id"]: c["id"] = f"call_{int(time.time() * 1000) % 10**8}_{n}"        # без id следующий запрос вернёт 400
        if out: yield "tools", out


def _red_png():
    import struct, zlib
    w = h = 16; raw = b"".join(b"\x00" + b"\xff\x00\x00" * w for _ in range(h))

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    import base64
    return "data:image/png;base64," + base64.b64encode(png).decode()


def _post(p, body, timeout=(8, 25)):
    r = requests.post(chat_url(p), headers=headers(p), json=body, timeout=timeout)
    if r.status_code != 200: raise ApiError(r.status_code, r.text[:300])
    return (r.json().get("choices") or [{}])[0].get("message") or {}


def probe_tools(p, model):
    """Реально ли модель вызывает инструменты (function calling)."""
    tool = {"type": "function", "function": {"name": "ping", "description": "Call this function to answer.", "parameters": {"type": "object", "properties": {}}}}
    body = {"model": model, "messages": [{"role": "user", "content": "Call the function ping now."}], "tools": [tool], "max_tokens": 40, "stream": False}
    try:
        if _post(p, body).get("tool_calls"): return True
        body["tool_choice"] = "required"        # вторая попытка: часть моделей умеет вызывать инструменты, но не по просьбе в тексте
        return bool(_post(p, body).get("tool_calls"))
    except ApiError as ex:
        if ex.status in (400, 404, 422): return False   # провайдер отвергает сам параметр tools
        raise


def probe_vision(p, model):
    """Видит ли модель картинки: показываем красный квадрат."""
    content = [{"type": "text", "text": "What is the main color of this image? Answer with one word."}, {"type": "image_url", "image_url": {"url": _red_png()}}]
    m = _post(p, {"model": model, "messages": [{"role": "user", "content": content}], "max_tokens": 20, "stream": False})
    t = str(m.get("content") or "").lower()
    return "red" in t or "красн" in t
