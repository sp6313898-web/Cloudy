"""Интеграция с Windows: автозапуск, открытие папок, резервная копия."""
import os, subprocess, sys, time, zipfile
from pathlib import Path
from .config import DATA

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def exe_command():
    if getattr(sys, "frozen", False): return f'"{sys.executable}" --tray'
    return f'"{sys.executable}" "{Path(__file__).resolve().parent.parent / "run.py"}" --tray'


def autostart_get():
    if os.name != "nt": return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k: winreg.QueryValueEx(k, "Cloudy"); return True
    except Exception: return False


def autostart_set(on):
    if os.name != "nt": return
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
        if on: winreg.SetValueEx(k, "Cloudy", 0, winreg.REG_SZ, exe_command())
        else:
            try: winreg.DeleteValue(k, "Cloudy")
            except FileNotFoundError: pass


def open_folder(p):
    p = str(p)
    if os.name == "nt": os.startfile(p)
    else: subprocess.Popen(["xdg-open", p])


def backup(dest):
    """Чаты, проекты, память и заметки плагинов — в zip (ключи API не включаются)."""
    n = 0
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for sub in ("chats", "projects", "plugin_data"):
            for f in (DATA / sub).rglob("*"):
                if f.is_file(): z.write(f, f.relative_to(DATA).as_posix()); n += 1
        for name in ("memory.json",):
            if (DATA / name).exists(): z.write(DATA / name, name); n += 1
    return n
