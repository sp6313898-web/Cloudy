"""Журнал действий ИИ: правки файлов сохраняются с резервной копией и откатываются одной кнопкой; команды и действия на экране пишутся для аудита."""
import json, shutil, time, uuid
from pathlib import Path
from .config import DATA

D = DATA / "journal"; FILES = D / "files"; INDEX = D / "index.json"
FILES.mkdir(parents=True, exist_ok=True)
KEEP = 400


def _load():
    try: return json.loads(INDEX.read_text("utf-8"))
    except Exception: return []


def _save(items):
    for old in items[:-KEEP]:
        if old.get("backup"):
            try: Path(old["backup"]).unlink()
            except Exception: pass
    INDEX.write_text(json.dumps(items[-KEEP:], ensure_ascii=False), "utf-8")


def snapshot(path):
    """До изменения: -> (файл существовал?, путь резервной копии)."""
    p = Path(path)
    if p.exists() and p.is_file() and p.stat().st_size < 20_000_000:
        b = FILES / f"{uuid.uuid4().hex[:8]}_{p.name}"; shutil.copy2(p, b); return True, str(b)
    return p.exists(), None


def log(kind, target, detail="", existed=None, backup=None):
    items = _load()
    items.append({"id": uuid.uuid4().hex[:8], "ts": time.strftime("%Y-%m-%d %H:%M:%S"), "kind": kind, "target": str(target), "detail": str(detail)[:300],
                  "existed": existed, "backup": backup, "undone": False})
    _save(items)


def entries(): return list(reversed(_load()))


def undo(eid):
    items = _load()
    for e in items:
        if e["id"] != eid: continue
        if e["kind"] not in ("write", "edit") or e.get("undone"): return "Это действие нельзя откатить"
        t = Path(e["target"])
        try:
            if e.get("existed") and e.get("backup") and Path(e["backup"]).exists(): shutil.copy2(e["backup"], t)
            elif not e.get("existed") and t.exists(): t.unlink()
            else: return "Нет резервной копии"
        except Exception as ex:
            return f"Не удалось откатить: {ex}"
        e["undone"] = True; _save(items); return ""
    return "Запись не найдена"
