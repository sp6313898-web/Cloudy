import math
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QRectF, QAbstractAnimation, Signal, QPoint, QPointF, QVariantAnimation
from PySide6.QtGui import QColor, QPainter, QPen, QFont, QCursor, QPolygonF, QGuiApplication
from PySide6.QtWidgets import (QWidget, QLabel, QTextBrowser, QFrame, QSizePolicy, QVBoxLayout, QHBoxLayout,
                               QPushButton, QToolButton, QPlainTextEdit, QGraphicsOpacityEffect)
from . import icons

try:
    import shiboken6
except Exception:
    shiboken6 = None


def alive(o):
    try: return bool(shiboken6.isValid(o)) if shiboken6 else True
    except Exception: return False


PAL = {"code": "#F1EFE7", "accent": "#C96442"}


def fade_in(w, ms=280):
    eff = QGraphicsOpacityEffect(w); w.setGraphicsEffect(eff)
    a = QPropertyAnimation(eff, b"opacity", w)
    a.setDuration(ms); a.setStartValue(0.0); a.setEndValue(1.0); a.setEasingCurve(QEasingCurve.OutCubic)
    a.finished.connect(lambda: QTimer.singleShot(0, lambda: alive(w) and w.setGraphicsEffect(None)))
    a.start(QAbstractAnimation.DeleteWhenStopped); w._fade = a


class Spark(QWidget):
    """Иконка-«искра»: вращается и пульсирует, пока идёт генерация."""
    def __init__(self, size=24, color="#C96442"):
        super().__init__(); self.setFixedSize(size, size)
        self.color, self.angle, self.t = QColor(color), 0.0, 0.0
        self.timer = QTimer(self); self.timer.timeout.connect(self._tick)

    def start(self): self.timer.start(30)

    def stop(self):
        self.timer.stop(); self.angle, self.t = 0.0, 0.0; self.update()

    def _tick(self):
        self.angle = (self.angle + 5) % 360; self.t += 0.12; self.update()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.translate(self.width() / 2, self.height() / 2); p.rotate(self.angle)
        r = (self.width() / 2 - 1) * (1 + (0.1 * math.sin(self.t) if self.timer.isActive() else 0))
        p.setBrush(self.color); p.setPen(Qt.NoPen)
        for i in range(8):
            p.save(); p.rotate(i * 45)
            p.drawRoundedRect(QRectF(-r * 0.09, -r, r * 0.18, r * 0.95), r * 0.09, r * 0.09); p.restore()


class MdView(QTextBrowser):
    def __init__(self, text=""):
        super().__init__()
        self.setFrameShape(QFrame.NoFrame); self.setOpenExternalLinks(True)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff); self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.document().setDefaultStyleSheet(
            f"pre, code {{ background-color: {PAL['code']}; font-family: Consolas, monospace; }} a {{ color: {PAL['accent']}; }}")
        self.document().documentLayout().documentSizeChanged.connect(self._fit)
        self.set_md(text)

    def set_md(self, t): self.setMarkdown(t)

    def _fit(self, size): self.setFixedHeight(int(size.height()) + 8)

    def resizeEvent(self, e):
        super().resizeEvent(e); self._fit(self.document().size())


class Card(QFrame):
    """Сворачиваемая карточка: вызов инструмента / ход рассуждений."""
    def __init__(self, title, body="", icon="terminal"):
        super().__init__(); self.setObjectName("card"); self.title = title
        lay = QVBoxLayout(self); lay.setContentsMargins(6, 4, 6, 6); lay.setSpacing(4)
        self.head = QPushButton(); self.head.setCheckable(True); self.head.setFixedHeight(30)
        hl = QHBoxLayout(self.head); hl.setContentsMargins(6, 0, 6, 0); hl.setSpacing(8)
        self.chev, self.ico, self.lbl = QLabel(), QLabel(), QLabel(title)
        for w in (self.chev, self.ico, self.lbl): w.setAttribute(Qt.WA_TransparentForMouseEvents)
        hl.addWidget(self.chev); hl.addWidget(self.ico); hl.addWidget(self.lbl, 1)
        self.set_icon(icon); self.chev.setPixmap(icons.pix("chev_r", None, 14))
        self.body = QPlainTextEdit(); self.body.setReadOnly(True); self.body.setMaximumHeight(0); self.body.setPlainText(body)
        lay.addWidget(self.head); lay.addWidget(self.body)
        self.anim = QPropertyAnimation(self.body, b"maximumHeight", self)
        self.anim.setDuration(220); self.anim.setEasingCurve(QEasingCurve.OutCubic)
        self.head.toggled.connect(self._toggle)

    def set_icon(self, name): self.ico.setPixmap(icons.pix(name, None, 16))

    def _toggle(self, on):
        self.chev.setPixmap(icons.pix("chev_d" if on else "chev_r", None, 14))
        self.anim.stop(); self.anim.setStartValue(self.body.maximumHeight()); self.anim.setEndValue(200 if on else 0); self.anim.start()

    def set_title(self, t, icon=None):
        self.lbl.setText(t)
        if icon: self.set_icon(icon)

    def set_body(self, t): self.body.setPlainText(t)

    def add_body(self, t):
        self.body.moveCursor(self.body.textCursor().End); self.body.insertPlainText(t)


class ArtifactCard(QPushButton):
    def __init__(self, title, kind):
        super().__init__(); self.setObjectName("artcard"); self.setCursor(Qt.PointingHandCursor); self.setMinimumHeight(54)
        hl = QHBoxLayout(self); hl.setContentsMargins(14, 8, 14, 8); hl.setSpacing(12)
        ic = QLabel(); ic.setPixmap(icons.pix("artifact", None, 22)); ic.setAttribute(Qt.WA_TransparentForMouseEvents)
        col = QVBoxLayout(); col.setSpacing(0)
        self.t = QLabel(title); self.k = QLabel(kind); self.k.setObjectName("sub")
        for w in (self.t, self.k): w.setAttribute(Qt.WA_TransparentForMouseEvents); col.addWidget(w)
        hl.addWidget(ic); hl.addLayout(col, 1)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)


class AttachChip(QFrame):
    removed = Signal(object)

    def __init__(self, att):
        super().__init__(); self.setObjectName("chip2"); self.att = att
        hl = QHBoxLayout(self); hl.setContentsMargins(8, 4, 4, 4); hl.setSpacing(6)
        ic = QLabel(); ic.setPixmap(icons.pix("image" if att["kind"] == "image" else "file", None, 16))
        n = QLabel(att["name"][:28]); hl.addWidget(ic); hl.addWidget(n)
        x = QToolButton(); icons.set_ic(x, "close", size=12); x.clicked.connect(lambda: self.removed.emit(self)); hl.addWidget(x)


TIP = 40
OVERLAY = Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.WindowTransparentForInput | Qt.NoDropShadowWindowHint


class AICursor(QWidget):
    """Собственный чёрный курсор ИИ поверх экрана: плавно едет к цели, при клике рисует круг."""
    def __init__(self):
        super().__init__(None, OVERLAY)
        self.setAttribute(Qt.WA_TranslucentBackground); self.setAttribute(Qt.WA_ShowWithoutActivating); self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.resize(170, 130); self.pulse = 0.0; self.anim = None; self.fx = None

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        if self.pulse > 0:
            p.setPen(QPen(QColor(17, 17, 17, int(190 * (1 - self.pulse))), 3)); p.setBrush(Qt.NoBrush)
            r = 6 + 32 * self.pulse; p.drawEllipse(QPointF(TIP, TIP), r, r)
        pts = ((0, 0), (0, 17), (4.5, 13), (7.5, 20), (10.5, 18.5), (7.5, 12), (13, 12))
        p.setPen(QPen(QColor(255, 255, 255), 1.7)); p.setBrush(QColor(15, 15, 15))
        p.drawPolygon(QPolygonF([QPointF(TIP + x * 1.5, TIP + y * 1.5) for x, y in pts]))
        p.setPen(Qt.NoPen); p.drawRoundedRect(QRectF(TIP + 26, TIP + 30, 40, 20), 10, 10)
        f = QFont("Segoe UI", 8); f.setBold(True); p.setFont(f); p.setPen(QColor(255, 255, 255)); p.drawText(QRectF(TIP + 26, TIP + 30, 40, 20), Qt.AlignCenter, "AI")

    def move_to(self, x, y, done=None):
        if self.anim: self.anim.stop()
        end = QPoint(int(x) - TIP, int(y) - TIP)
        if not self.isVisible():
            self.move(QCursor.pos() - QPoint(TIP, TIP)); self.show(); self.raise_()
        dist = ((end.x() - self.x()) ** 2 + (end.y() - self.y()) ** 2) ** 0.5
        self.anim = QPropertyAnimation(self, b"pos", self); self.anim.setDuration(int(max(220, min(900, dist * 0.7))))
        self.anim.setEasingCurve(QEasingCurve.InOutCubic); self.anim.setStartValue(self.pos()); self.anim.setEndValue(end)
        if done: self.anim.finished.connect(done)
        self.anim.start()

    def click_fx(self):
        self.fx = QVariantAnimation(self); self.fx.setDuration(420); self.fx.setStartValue(0.01); self.fx.setEndValue(1.0)
        self.fx.valueChanged.connect(lambda v: (setattr(self, "pulse", float(v)), self.update()))
        self.fx.finished.connect(lambda: (setattr(self, "pulse", 0.0), self.update())); self.fx.start()


class AIBanner(QLabel):
    def __init__(self, text):
        super().__init__(text, None, OVERLAY)
        self.setAttribute(Qt.WA_TranslucentBackground); self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setStyleSheet("background:#111111;color:#ffffff;border-radius:14px;padding:8px 18px;font-size:13px;")

    def show_top(self):
        self.adjustSize(); g = QGuiApplication.primaryScreen().availableGeometry()
        self.move(g.center().x() - self.width() // 2, g.top() + 10); self.show(); self.raise_()
