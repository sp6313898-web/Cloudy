PALETTES = {
    "light": dict(bg="#FAF9F5", side="#F0EEE6", text="#1F1E1D", sub="#6B6A68", accent="#C96442",
                  border="#E3E0D5", bubble="#EFEDE4", input="#FFFFFF", hover="#E8E5DA", code="#F1EFE7"),
    "dark": dict(bg="#262624", side="#1F1E1D", text="#ECE9E1", sub="#A3A19B", accent="#D97757",
                 border="#3A3936", bubble="#35342F", input="#30302E", hover="#33322F", code="#1F1E1D"),
}


def qss(p: dict) -> str:
    return f"""
* {{ font-family: 'Segoe UI', 'Inter', sans-serif; font-size: 14px; color: {p['text']}; }}
QMainWindow, QDialog, #chatArea, #scrollInner {{ background: {p['bg']}; }}
#sidebar {{ background: {p['side']}; border-right: 1px solid {p['border']}; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ width: 10px; background: transparent; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {p['border']}; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {p['sub']}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QTextBrowser, QLabel {{ background: transparent; }}
#brand {{ font-family: Georgia, 'Times New Roman', serif; font-size: 21px; }}
#hello {{ font-family: Georgia, 'Times New Roman', serif; font-size: 34px; }}
#sub {{ color: {p['sub']}; }}
QPushButton {{ background: transparent; border: none; border-radius: 8px; padding: 8px 12px; text-align: left; }}
QPushButton:hover {{ background: {p['hover']}; }}
QPushButton#primary {{ background: {p['accent']}; color: white; text-align: center; font-weight: 600; }}
QPushButton#primary:hover {{ background: {p['accent']}; }}
QPushButton#primary:disabled {{ background: {p['border']}; }}
QPushButton#chip {{ border: 1px solid {p['border']}; border-radius: 16px; padding: 7px 14px; text-align: center; }}
QPushButton#chip:hover {{ background: {p['hover']}; }}
QPushButton#chat {{ padding: 8px 10px; }}
QPushButton#chat[active="true"] {{ background: {p['hover']}; }}
#inputBox {{ background: {p['input']}; border: 1px solid {p['border']}; border-radius: 18px; }}
#inputBox[focus="true"] {{ border: 1px solid {p['accent']}; }}
QPlainTextEdit, QLineEdit, QComboBox, QSpinBox {{ background: {p['input']}; border: 1px solid {p['border']}; border-radius: 8px; padding: 6px 8px; }}
#inputBox QPlainTextEdit {{ border: none; background: transparent; font-size: 15px; }}
QLineEdit:focus, QComboBox:focus {{ border: 1px solid {p['accent']}; }}
#userBubble {{ background: {p['bubble']}; border-radius: 16px; padding: 10px 14px; }}
#card {{ background: {p['side']}; border: 1px solid {p['border']}; border-radius: 12px; }}
#card QPlainTextEdit {{ font-family: Consolas, monospace; font-size: 12px; background: {p['code']}; }}
QToolButton {{ background: transparent; border: none; padding: 4px 6px; border-radius: 6px; }}
QToolButton:hover {{ background: {p['hover']}; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid {p['sub']}; }}
QCheckBox::indicator:checked {{ background: {p['accent']}; border-color: {p['accent']}; }}
QMessageBox {{ background: {p['bg']}; }}
#artcard {{ background: {p['side']}; border: 1px solid {p['border']}; border-radius: 12px; text-align: left; }}
#artcard:hover {{ border: 1px solid {p['accent']}; background: {p['hover']}; }}
#chip2 {{ background: {p['side']}; border: 1px solid {p['border']}; border-radius: 10px; }}
#artPanel {{ background: {p['bg']}; border-left: 1px solid {p['border']}; }}
QComboBox {{ padding: 6px 10px; }}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox QAbstractItemView {{ background: {p['input']}; border: 1px solid {p['border']}; selection-background-color: {p['hover']}; selection-color: {p['text']}; outline: 0; }}
QToolTip {{ background: {p['side']}; color: {p['text']}; border: 1px solid {p['border']}; padding: 4px 8px; }}
QProgressBar {{ border: 1px solid {p['border']}; border-radius: 6px; text-align: center; background: {p['input']}; }}
QProgressBar::chunk {{ background: {p['accent']}; border-radius: 5px; }}
QSpinBox {{ padding: 5px 8px; }}
QMenu {{ background: {p['input']}; border: 1px solid {p['border']}; padding: 4px; }}
QMenu::item {{ padding: 6px 18px; border-radius: 6px; }}
QMenu::item:selected {{ background: {p['hover']}; }}
QPushButton {{ min-height: 20px; }}
QListWidget {{ outline: 0; }}
QCheckBox {{ spacing: 8px; }}
QTabWidget::pane {{ border: 1px solid {p['border']}; border-radius: 10px; top: -1px; background: transparent; }}
QTabBar::tab {{ background: transparent; padding: 8px 16px; border: none; border-bottom: 2px solid transparent; color: {p['sub']}; }}
QTabBar::tab:selected {{ color: {p['text']}; border-bottom: 2px solid {p['accent']}; }}
QTabBar::tab:hover {{ color: {p['text']}; }}
#sideList, #sideList > QWidget {{ background: transparent; }}
QPushButton#rec {{ background: #D14343; color: white; text-align: center; }}
QPushButton#seg {{ border: 1px solid {p['border']}; padding: 5px 12px; text-align: center; }}
QPushButton#seg:checked {{ background: {p['hover']}; border: 1px solid {p['accent']}; }}
QPushButton#topbtn {{ border: 1px solid {p['border']}; border-radius: 14px; padding: 6px 12px; text-align: center; }}
QPushButton#topbtn[on="true"] {{ border: 1px solid {p['accent']}; color: {p['accent']}; }}
QListWidget {{ background: {p['input']}; border: 1px solid {p['border']}; border-radius: 8px; padding: 4px; }}
QListWidget::item {{ padding: 6px; border-radius: 6px; }}
QListWidget::item:selected {{ background: {p['hover']}; color: {p['text']}; }}
"""


def palette(p: dict):
    """Палитра Qt под тему: иначе стандартные виджеты (списки, прокрутки) остаются белыми в тёмной теме."""
    from PySide6.QtGui import QPalette, QColor
    pal = QPalette()
    for role, col in ((QPalette.Window, p["bg"]), (QPalette.WindowText, p["text"]), (QPalette.Base, p["input"]), (QPalette.AlternateBase, p["side"]),
                      (QPalette.Text, p["text"]), (QPalette.Button, p["side"]), (QPalette.ButtonText, p["text"]), (QPalette.ToolTipBase, p["side"]),
                      (QPalette.ToolTipText, p["text"]), (QPalette.Highlight, p["accent"]), (QPalette.HighlightedText, "#FFFFFF"),
                      (QPalette.PlaceholderText, p["sub"]), (QPalette.Link, p["accent"])):
        pal.setColor(role, QColor(col))
    for role in (QPalette.Text, QPalette.WindowText, QPalette.ButtonText): pal.setColor(QPalette.Disabled, role, QColor(p["sub"]))
    return pal
