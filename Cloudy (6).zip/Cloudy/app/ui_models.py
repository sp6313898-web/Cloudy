import webbrowser
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLineEdit, QListWidget, QListWidgetItem,
                               QPushButton, QLabel, QCheckBox, QComboBox)
from . import router, config, presets, threads
from .i18n import T
from .icons import set_ic

GREEN, RED = QColor("#3E8E5A"), QColor("#B5524A")


class ScanThread(QThread):
    """Фоновая проверка моделей реальными запросами."""
    progress = Signal(int, int, int)
    done = Signal(int)

    def __init__(self, cfg, per=5, only=None, need=None):
        super().__init__(); self.cfg, self.per, self.only, self.need, self._stop = cfg, per, only, need, False

    def stop(self): self._stop = True

    def run(self):
        try: n = router.scan(self.cfg, lambda d, t, o: self.progress.emit(d, t, o), self.per, lambda: self._stop, self.only, need=self.need)
        except Exception: n = 0
        self.done.emit(n)


class FetchThread(QThread):
    done = Signal(str, int, str)

    def __init__(self, providers):
        super().__init__(); self.providers = providers

    def run(self):
        for p in self.providers:
            try:
                m = router.fetch_models(p); router.set_cache(p["id"], m); self.done.emit(p["id"], len(m), "")
            except Exception as ex:
                router.set_cache(p["id"], [], True); self.done.emit(p["id"], 0, str(ex)[:200])


def tag(r):
    caps = (" · MCP" if r.get("tools") else "") + (" · " + T("картинки") if r.get("vision") else "")
    if r["state"] == "ok": return T("рабочая") + f" {r['ms']} " + T("мс") + caps
    return (T("не отвечает") if r["state"] == "fail" else T("не проверена")) + caps


class ModelPicker(QDialog):
    """Поиск по сотням моделей из всех API со статусами. «Авто» — первая строка."""
    def __init__(self, cfg, current="auto", allow_auto=True, auto_text=None, parent=None):
        super().__init__(parent); self.cfg, self.cur, self.allow_auto, self.auto_text = cfg, current, allow_auto, auto_text
        self.setWindowTitle(T("Выбор модели")); self.resize(620, 600); self.key = None; self.th = None
        v = QVBoxLayout(self); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(10)
        self.q = QLineEdit(); self.q.setPlaceholderText(T("Поиск модели (напишите «авто» для автовыбора)")); self.q.textChanged.connect(self.filt)
        self.q.returnPressed.connect(self.first); v.addWidget(self.q)
        bar = QHBoxLayout(); self.only = QCheckBox(T("Только рабочие")); self.only.toggled.connect(self.filt); bar.addWidget(self.only)
        self.only_mcp = QCheckBox(T("Только MCP")); self.only_mcp.toggled.connect(self.filt); bar.addWidget(self.only_mcp); bar.addStretch()
        self.tb = QPushButton(T("Проверить модели")); set_ic(self.tb, "refresh", size=16); self.tb.clicked.connect(self.test); bar.addWidget(self.tb)
        self.tm = QPushButton(T("Проверить для MCP")); set_ic(self.tm, "blocks", size=16); self.tm.clicked.connect(self.test_mcp); bar.addWidget(self.tm); v.addLayout(bar)
        self.lst = QListWidget(); self.lst.itemActivated.connect(self.pick); self.lst.itemDoubleClicked.connect(self.pick); v.addWidget(self.lst, 1)
        self.hint = QLabel(""); self.hint.setObjectName("sub"); self.hint.setWordWrap(True); v.addWidget(self.hint)
        self.fill(); self.q.setFocus()

    def fill(self):
        self.lst.clear(); self.data = []
        rs = router.rows(self.cfg)
        if self.allow_auto:
            txt = T("Авто: самая рабочая модель (рабочих: {n})").format(n=sum(1 for r in rs if r["state"] == "ok")) if self.auto_text is None else self.auto_text
            self.add_item("auto" if self.auto_text is None else "", txt, "авто auto", None)
        for r in rs:
            self.add_item(r["key"], f"{r['model']}      {r['pname']}      {tag(r)}" + ("      free" if r["free"] else ""),
                          f"{r['model']} {r['pname']} {tag(r)} {'free' if r['free'] else ''}".lower(), r)
        self.hint.setText(T("Авто выбирает модель по истории успешных ответов и скорости, а при сбое сама переходит к следующей.")
                          if self.allow_auto else T("Модели берутся из ваших API. Добавьте их в Настройки, «Провайдеры API»."))
        self.filt()

    def add_item(self, key, text, search, r):
        it = QListWidgetItem(text); it.setData(Qt.UserRole, key); self.lst.addItem(it); self.data.append((search, r))
        if r and r["state"] == "ok": it.setForeground(GREEN)
        elif r and r["state"] == "fail": it.setForeground(RED)
        if key == self.cur: self.lst.setCurrentItem(it)

    def filt(self, *_):
        words = self.q.text().lower().split()
        for i, (s, r) in enumerate(self.data):
            self.lst.item(i).setHidden(not all(w in s for w in words) or (self.only.isChecked() and r is not None and r["state"] != "ok")
                                       or (self.only_mcp.isChecked() and r is not None and not r.get("tools")))

    def first(self):
        for i in range(self.lst.count()):
            if not self.lst.item(i).isHidden(): self.pick(self.lst.item(i)); return

    def pick(self, it): self.key = it.data(Qt.UserRole); self.accept()

    def test(self, *_, mcp=False):
        self.tb.setEnabled(False); self.tm.setEnabled(False)
        self.th = ScanThread(self.cfg, 10 if mcp else 8, None, {"tools": True} if mcp else None)
        self.th.progress.connect(lambda d, t, o: self.hint.setText((T("Ищу модели для MCP… {done}/{total}") if mcp else T("Проверка моделей… {done}/{total}")).format(done=d, total=t) + f"  ({o})"))
        self.th.done.connect(self._tested); threads.run(self.th)

    def test_mcp(self): self.test(mcp=True)

    def _tested(self, n):
        self.tb.setEnabled(True); self.tm.setEnabled(True); self.fill(); self.hint.setText(T("Рабочих моделей: {n}").format(n=n))


class ProvidersDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent); self.cfg = cfg; self.setWindowTitle(T("Провайдеры API")); self.resize(940, 580); self.cur = None; self.th = None; self.fth = None
        h = QHBoxLayout(self); h.setContentsMargins(18, 16, 18, 16); h.setSpacing(16)
        left = QVBoxLayout(); left.setSpacing(8); self.lst = QListWidget(); left.addWidget(self.lst, 1)
        af = QPushButton(T("Добавить все бесплатные")); af.setObjectName("primary"); set_ic(af, "layers", True); af.clicked.connect(self.add_free); left.addWidget(af)
        ab = QPushButton(T("Добавить провайдера")); set_ic(ab, "plus"); ab.clicked.connect(self.add); left.addWidget(ab)
        self.scan_btn = QPushButton(T("Проверить модели")); set_ic(self.scan_btn, "refresh"); self.scan_btn.clicked.connect(lambda: self.scan(None)); left.addWidget(self.scan_btn)
        self.mcp_btn = QPushButton(T("Проверить для MCP")); set_ic(self.mcp_btn, "blocks"); self.mcp_btn.clicked.connect(lambda: self.scan(None, True)); left.addWidget(self.mcp_btn)
        self.glob = QLabel(""); self.glob.setObjectName("sub"); self.glob.setWordWrap(True); left.addWidget(self.glob)
        h.addLayout(left, 2)
        f = QFormLayout(); f.setVerticalSpacing(10)
        hint = QLabel(T("Совет: часть провайдеров работает без ключа, для остальных нужен бесплатный ключ (ссылка есть в каждой карточке).")); hint.setObjectName("sub"); hint.setWordWrap(True); f.addRow(hint)
        self.tpl = QComboBox(); self.tpl.addItem(T("Шаблон"), None)
        for pr in presets.PRESETS: self.tpl.addItem(pr["name"], pr["name"])
        self.tpl.activated.connect(self.apply_tpl)
        self.name, self.url, self.key = QLineEdit(), QLineEdit(), QLineEdit(); self.key.setEchoMode(QLineEdit.Password)
        self.key.setPlaceholderText(T("(для локальных моделей ключ не нужен)"))
        self.free = QCheckBox(T("Только бесплатные модели"))
        self.getkey = QPushButton(T("Получить ключ")); set_ic(self.getkey, "external", size=16); self.getkey.clicked.connect(lambda: self.cur and self.cur.get("key_url") and webbrowser.open(self.cur["key_url"]))
        self.status = QLabel(""); self.status.setObjectName("sub"); self.status.setWordWrap(True)
        f.addRow(T("Шаблон"), self.tpl); f.addRow(T("Название"), self.name); f.addRow(T("Адрес API"), self.url); f.addRow(T("API-ключ"), self.key)
        kr = QHBoxLayout(); kr.addWidget(self.getkey); kr.addWidget(self.free); kr.addStretch(); f.addRow(kr)
        row = QHBoxLayout(); lb = QPushButton(T("Загрузить модели")); set_ic(lb, "refresh"); lb.clicked.connect(self.load)
        tb = QPushButton(T("Проверить этого")); set_ic(tb, "check"); tb.clicked.connect(lambda: self.scan(self.cur["id"] if self.cur else None))
        row.addWidget(lb); row.addWidget(tb); row.addStretch(); f.addRow(row); f.addRow(self.status)
        bb = QHBoxLayout(); sv = QPushButton(T("Сохранить")); sv.setObjectName("primary"); sv.clicked.connect(self.save)
        dl = QPushButton(T("Удалить")); set_ic(dl, "trash"); dl.clicked.connect(self.delete); bb.addWidget(sv); bb.addWidget(dl); bb.addStretch(); f.addRow(bb)
        h.addLayout(f, 3); self.fill(); self.lst.currentRowChanged.connect(self.pick); self.glob_update()

    def glob_update(self):
        self.glob.setText(T("Рабочих моделей: {n}").format(n=router.working_count(self.cfg)))

    def fill(self, select=None):
        self.lst.blockSignals(True); self.lst.clear(); ps = self.cfg["providers"]
        pst = router.provider_stats(self.cfg)
        ps.sort(key=lambda p: (not router.usable(p), -pst.get(p["id"], {}).get("mcp", 0), p["name"].lower()))
        for p in ps:
            ok = router.usable(p); n = pst.get(p["id"], {}).get("mcp", 0)
            it = QListWidgetItem(p["name"] + ("" if ok else "  —  " + T("Нет ключа")) + (f"  —  MCP: {n}" if n else ""))
            if not ok: it.setForeground(QColor("#999999"))
            elif n: it.setForeground(GREEN)
            self.lst.addItem(it)
        self.lst.blockSignals(False)
        if ps:
            i = next((k for k, p in enumerate(ps) if p["id"] == select), 0); self.lst.setCurrentRow(i); self.pick(i)

    def pick(self, i):
        if not (0 <= i < len(self.cfg["providers"])): return
        p = self.cur = self.cfg["providers"][i]
        self.name.setText(p["name"]); self.url.setText(p["base_url"]); self.key.setText(p.get("api_key", ""))
        self.free.setChecked(bool(p.get("free_only"))); self.getkey.setVisible(bool(p.get("key_url"))); self.show_count()

    def show_count(self):
        if not self.cur: return
        n = len(router.models_of(self.cur))
        txt = T("Моделей: {n}").format(n=n) if n else T("Модели не загружены")
        if self.cur.get("nokey"): txt += "  /  " + T("Провайдер доступен без ключа")
        self.status.setText(txt)

    def apply_tpl(self, i):
        n = self.tpl.itemData(i)
        if n:
            full = presets.provider(next(p for p in presets.PRESETS if p["name"] == n))
            self.name.setText(n); self.url.setText(full["base_url"]); self.getkey.setVisible(bool(full["key_url"]))
            if self.cur: self.cur.update({k: v for k, v in full.items() if k not in ("id", "api_key")})

    def add(self):
        import uuid
        p = {"id": uuid.uuid4().hex[:8], "name": "API", "base_url": "", "api_key": "", "key_url": "", "nokey": False,
             "default_key": "", "free_only": False, "fallback": [], "chat_url": "", "models_url": ""}
        self.cfg["providers"].append(p); config.save(self.cfg); self.fill(p["id"])

    def add_free(self):
        have = {p["id"] for p in self.cfg["providers"]}; n = 0
        for pr in presets.PRESETS:
            full = presets.provider(pr)
            if full["id"] not in have: self.cfg["providers"].append(full); n += 1
            if full["id"] in self.cfg.get("removed", []): self.cfg["removed"].remove(full["id"])
        config.save(self.cfg); self.fill(self.cur["id"] if self.cur else None)
        self.glob.setText(T("Добавлено провайдеров: {n}").format(n=n)); self.scan(None)

    def save(self):
        if not self.cur: return
        self.cur.update(name=self.name.text().strip() or "API", base_url=self.url.text().strip(), api_key=self.key.text().strip(), free_only=self.free.isChecked())
        config.save(self.cfg); self.fill(self.cur["id"])

    def delete(self):
        if self.cur:
            self.cfg.setdefault("removed", []).append(self.cur["id"]); self.cfg["providers"].remove(self.cur); self.cur = None
            config.save(self.cfg); self.fill()

    def load(self):
        self.save()
        if self.cur and self.cur["base_url"]:
            self.status.setText(T("Загрузка…")); self.fth = FetchThread([self.cur]); self.fth.done.connect(self.fetched); threads.run(self.fth)

    def fetched(self, pid, n, err):
        if self.cur and self.cur["id"] == pid:
            self.status.setText(T("Ошибка загрузки: {err}").format(err=err) if err else T("Моделей: {n}").format(n=n))

    def scan(self, only, mcp=False):
        self.save(); self.scan_btn.setEnabled(False); self.mcp_btn.setEnabled(False)
        self.th = ScanThread(self.cfg, 8 if mcp else 5, only, {"tools": True} if mcp else None)
        self.th.progress.connect(lambda d, t, o: self.glob.setText((T("Ищу модели для MCP… {done}/{total}") if mcp else T("Проверка моделей… {done}/{total}")).format(done=d, total=t) + f"  ({o})"))
        self.th.done.connect(self._scanned); threads.run(self.th)

    def _scanned(self, n):
        self.scan_btn.setEnabled(True); self.mcp_btn.setEnabled(True); self.glob_update(); self.show_count(); self.fill(self.cur["id"] if self.cur else None)


class CollabDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent); self.cfg = cfg; self.setWindowTitle(T("Совместная работа моделей")); self.resize(640, 640)
        col = cfg["collab"]; self.lead = col.get("lead", "")
        v = QVBoxLayout(self); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(10)
        self.on = QCheckBox(T("Включить совместную работу")); self.on.setChecked(col.get("on", False)); v.addWidget(self.on)
        d = QLabel(T("Выбранные модели независимо готовят черновики, а ведущая модель сверяет их и пишет итоговый ответ."))
        d.setObjectName("sub"); d.setWordWrap(True); v.addWidget(d)
        v.addWidget(QLabel(T("Участники (рекомендуется 2–4)")))
        self.q = QLineEdit(); self.q.setPlaceholderText(T("Поиск")); self.q.textChanged.connect(self.filt); v.addWidget(self.q)
        self.lst = QListWidget(); v.addWidget(self.lst, 1); self.data = []
        for r in router.rows(cfg):
            it = QListWidgetItem(f"{r['model']}      {r['pname']}      {tag(r)}"); it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if r["key"] in col.get("models", []) else Qt.Unchecked); it.setData(Qt.UserRole, r["key"])
            if r["state"] == "ok": it.setForeground(GREEN)
            elif r["state"] == "fail": it.setForeground(RED)
            self.lst.addItem(it); self.data.append((r["model"] + " " + r["pname"] + " " + tag(r)).lower())
        self.cnt = QLabel(""); self.cnt.setObjectName("sub"); v.addWidget(self.cnt); self.lst.itemChanged.connect(self.count); self.count()
        lr = QHBoxLayout(); lr.addWidget(QLabel(T("Ведущая модель"))); self.lb = QPushButton(); self.lb.clicked.connect(self.pick_lead)
        lr.addWidget(self.lb, 1); v.addLayout(lr); self.set_lead(self.lead)
        sv = QPushButton(T("Сохранить")); sv.setObjectName("primary"); sv.clicked.connect(self.save); v.addWidget(sv)

    def filt(self, t):
        w = t.lower().split()
        for i, s in enumerate(self.data): self.lst.item(i).setHidden(not all(x in s for x in w))

    def checked(self): return [self.lst.item(i).data(Qt.UserRole) for i in range(self.lst.count()) if self.lst.item(i).checkState() == Qt.Checked]

    def count(self, *_): self.cnt.setText(T("Выбрано: {n}").format(n=len(self.checked())))

    def set_lead(self, k):
        self.lead = k; self.lb.setText(T("Как в основном выборе") if not k else (T("Авто") if k == "auto" else router.label(self.cfg, k)))

    def pick_lead(self):
        d = ModelPicker(self.cfg, self.lead or "", True, T("Как в основном выборе"), self)
        if d.exec() and d.key is not None: self.set_lead(d.key)

    def save(self):
        self.cfg["collab"] = {"on": self.on.isChecked(), "models": self.checked()[:5], "lead": self.lead}
        config.save(self.cfg); self.accept()
