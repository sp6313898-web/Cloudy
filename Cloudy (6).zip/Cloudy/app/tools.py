"""Встроенные инструменты агента (аналог harness): файлы, поиск, команды.
Всё ограничено рабочей папкой. Запись и команды — только с подтверждением."""
import os, re, subprocess
from pathlib import Path
from . import journal

MAX_OUT = 12000


def _fn(name, desc, props, req):
    return {"type": "function", "function": {"name": name, "description": desc,
            "parameters": {"type": "object", "properties": props, "required": req}}}


S = {"type": "string"}
BUILTIN = [
    _fn("list_dir", "Список файлов и папок в директории рабочей папки.", {"path": S}, []),
    _fn("read_file", "Прочитать текстовый файл (можно указать диапазон строк).",
        {"path": S, "start_line": {"type": "integer"}, "end_line": {"type": "integer"}}, ["path"]),
    _fn("write_file", "Создать или перезаписать файл целиком.", {"path": S, "content": S}, ["path", "content"]),
    _fn("edit_file", "Заменить точный фрагмент old на new в файле (old должен встречаться один раз).",
        {"path": S, "old": S, "new": S}, ["path", "old", "new"]),
    _fn("search_text", "Найти текст (regex) в файлах рабочей папки.", {"pattern": S, "path": S}, ["pattern"]),
    _fn("create_artifact", "Показать пользователю отдельный артефакт справа: готовую веб-страницу/приложение (html, один файл с CSS и JS), SVG-графику, документ (markdown) или файл с кодом (code). Если id уже существует — создаётся новая версия (передавай полное содержимое).",
        {"title": S, "type": {"type": "string", "enum": ["html", "svg", "markdown", "code"]}, "content": S, "language": S, "id": S},
        ["title", "type", "content"]),
    _fn("run_command", "Выполнить команду в терминале Windows в рабочей папке (таймаут 60 с).",
        {"command": S}, ["command"]),
]
NEEDS_APPROVAL = {"write_file", "edit_file", "run_command"}


def _p(ws: str, rel: str) -> Path:
    root = Path(ws).resolve()
    p = (root / (rel or ".")).resolve()
    p.relative_to(root)  # ValueError, если путь вне рабочей папки
    return p


def _cut(s: str) -> str:
    return s if len(s) <= MAX_OUT else s[:MAX_OUT] + f"\n…[обрезано, всего {len(s)} символов]"


def describe(name: str, a: dict) -> str:
    if name == "run_command":
        return a.get("command", "")
    if name == "write_file":
        return f"{a.get('path')}\n\n{str(a.get('content',''))[:1500]}"
    if name == "edit_file":
        return f"{a.get('path')}\n\n- {str(a.get('old',''))[:600]}\n+ {str(a.get('new',''))[:600]}"
    return str(a)


def run_builtin(name: str, a: dict, ws: str) -> str:
    try:
        if name == "list_dir":
            p = _p(ws, a.get("path", "."))
            items = sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
            return "\n".join(("[папка] " if i.is_dir() else "        ") + i.name for i in items[:300]) or "(пусто)"
        if name == "read_file":
            lines = _p(ws, a["path"]).read_text("utf-8", errors="replace").splitlines()
            s, e = int(a.get("start_line") or 1), int(a.get("end_line") or len(lines))
            return _cut("\n".join(f"{i}: {l}" for i, l in enumerate(lines[s - 1:e], s)))
        if name == "write_file":
            p = _p(ws, a["path"])
            p.parent.mkdir(parents=True, exist_ok=True)
            ex, bk = journal.snapshot(p)
            p.write_text(a["content"], "utf-8"); journal.log("write", p, a["path"], ex, bk)
            return f"Записано {len(a['content'])} символов в {a['path']}"
        if name == "edit_file":
            p = _p(ws, a["path"])
            t = p.read_text("utf-8")
            if t.count(a["old"]) != 1:
                return f"Ошибка: фрагмент найден {t.count(a['old'])} раз(а), нужен ровно один."
            ex, bk = journal.snapshot(p)
            p.write_text(t.replace(a["old"], a["new"]), "utf-8"); journal.log("edit", p, a["path"], ex, bk)
            return "Изменение применено."
        if name == "search_text":
            rx = re.compile(a["pattern"])
            root = _p(ws, a.get("path", "."))
            out = []
            for f in root.rglob("*"):
                if not f.is_file() or f.stat().st_size > 1_000_000 or any(x.startswith(".") for x in f.parts):
                    continue
                try:
                    for i, l in enumerate(f.read_text("utf-8").splitlines(), 1):
                        if rx.search(l):
                            out.append(f"{f.relative_to(Path(ws).resolve())}:{i}: {l.strip()[:200]}")
                            if len(out) >= 100:
                                return "\n".join(out)
                except Exception:
                    pass
            return "\n".join(out) or "Ничего не найдено."
        if name == "run_command":
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = 0x08000000
            r = subprocess.run(a["command"], shell=True, cwd=ws, capture_output=True, timeout=60, **kw)
            enc = "cp866" if os.name == "nt" else "utf-8"
            out = (r.stdout + r.stderr).decode(enc, "replace"); journal.log("command", ws, a["command"][:250])
            return _cut(f"[код {r.returncode}]\n{out}")
    except subprocess.TimeoutExpired:
        return "Ошибка: таймаут 60 секунд."
    except ValueError:
        return "Ошибка: путь вне рабочей папки запрещён."
    except Exception as ex:
        return f"Ошибка: {ex}"
    return f"Неизвестный инструмент {name}"
