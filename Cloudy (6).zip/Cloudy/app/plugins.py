"""Магазин плагинов. Каталог лежит ВНУТРИ приложения (store/), интернет не нужен.
Безопасность: плагин ставится и загружается только если SHA-256 его папки совпадает
с хэшем из каталога; изменённые файлы блокируются."""
import ast, hashlib, base64, datetime, re, math, json, shutil, importlib.util  # noqa  (для сборки EXE)
from pathlib import Path
from .config import DATA, base_dir

STORE = base_dir() / "store"
INST = DATA / "plugins"
STATE = DATA / "plugins_state.json"


def folder_hash(path: Path) -> str:
    h = hashlib.sha256()
    for f in sorted(Path(path).rglob("*")):
        if f.is_file() and "__pycache__" not in f.parts:
            h.update(f.relative_to(path).as_posix().encode())
            h.update(f.read_bytes().replace(b"\r\n", b"\n"))
    return h.hexdigest()


def catalog() -> list:
    try:
        return json.loads((STORE / "catalog.json").read_text("utf-8"))
    except Exception:
        return []


def _state() -> dict:
    try:
        return json.loads(STATE.read_text("utf-8"))
    except Exception:
        return {}


def _save(s):
    STATE.write_text(json.dumps(s), "utf-8")


def is_installed(pid) -> bool:
    return (INST / pid / "manifest.json").exists()


def is_enabled(pid) -> bool:
    return is_installed(pid) and _state().get(pid, True)


def set_enabled(pid, on: bool):
    s = _state(); s[pid] = on; _save(s)


def install(pid: str) -> str:
    item = next((c for c in catalog() if c["id"] == pid), None)
    src = STORE / "plugins" / pid
    if not item or not src.exists():
        return "Плагин не найден в каталоге."
    if folder_hash(src) != item["sha256"]:
        return "Проверка целостности не пройдена — установка отменена."
    dst = INST / pid
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__"))
    set_enabled(pid, True)
    return ""


def uninstall(pid: str):
    d = INST / pid
    if d.exists():
        shutil.rmtree(d)


def _verified(pid) -> bool:
    item = next((c for c in catalog() if c["id"] == pid), None)
    return bool(item) and folder_hash(INST / pid) == item["sha256"]


def _active():
    for c in catalog():
        pid = c["id"]
        if is_enabled(pid) and _verified(pid):
            yield pid, json.loads((INST / pid / "manifest.json").read_text("utf-8"))


def active_prompts() -> str:
    parts = [f"### {m['name']}\n{m['prompt']}" for _, m in _active() if m.get("kind") == "skill"]
    return "\n\n".join(parts)


class PluginTools:
    def __init__(self):
        self.schemas, self.mods, self.pid = [], {}, {}
        for pid, m in _active():
            if m.get("kind") != "tools":
                continue
            try:
                spec = importlib.util.spec_from_file_location("cloudy_plugin_" + pid, INST / pid / "plugin.py")
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                for t in mod.TOOLS:
                    self.schemas.append({"type": "function", "function": t})
                    self.mods[t["name"]] = mod; self.pid[t["name"]] = pid
            except Exception:
                pass

    def has(self, name):
        return name in self.mods

    def run(self, name, args, ctx):
        try:
            d = DATA / "plugin_data" / self.pid[name]; d.mkdir(parents=True, exist_ok=True)
            return str(self.mods[name].run(name, args, dict(ctx, data=str(d))))
        except Exception as ex:
            return f"Ошибка плагина: {ex}"
