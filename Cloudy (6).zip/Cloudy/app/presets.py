"""Бесплатные (и локальные) провайдеры. Адреса и имена моделей могут меняться — их можно править в окне провайдеров,
а список моделей приложение всё равно загружает у самого API и проверяет реальным запросом."""
import re


def slug(n): return re.sub(r"[^a-z0-9]+", "-", n.lower()).strip("-")


def P(name, url, key_url="", fallback=(), **kw):
    return dict(name=name, base_url=url, key_url=key_url, fallback=list(fallback), **kw)


PRESETS = [
    # --- работают без ключа
    P("Pollinations", "https://text.pollinations.ai/openai", "", ["openai", "mistral", "llama", "deepseek"], nokey=True,
      chat_url="https://text.pollinations.ai/openai", models_url="https://text.pollinations.ai/models"),
    P("LLM7", "https://api.llm7.io/v1", "https://token.llm7.io", ["gpt-4o-mini-2024-07-18", "deepseek-r1-0528"], nokey=True, default_key="unused"),
    P("OVHcloud AI", "https://oai.endpoints.kepler.ai.cloud.ovh.net/v1", "https://endpoints.ai.cloud.ovh.net",
      ["Meta-Llama-3_3-70B-Instruct", "Mistral-7B-Instruct-v0.3", "Qwen2.5-VL-72B-Instruct"], nokey=True),
    # --- бесплатный тариф, нужен бесплатный ключ
    P("OpenRouter", "https://openrouter.ai/api/v1", "https://openrouter.ai/keys",
      ["deepseek/deepseek-chat-v3-0324:free", "meta-llama/llama-3.3-70b-instruct:free", "google/gemini-2.0-flash-exp:free",
       "qwen/qwen3-235b-a22b:free", "mistralai/mistral-small-3.1-24b-instruct:free"], free_only=True),
    P("Groq", "https://api.groq.com/openai/v1", "https://console.groq.com/keys",
      ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "openai/gpt-oss-120b", "qwen/qwen3-32b"]),
    P("Google Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "https://aistudio.google.com/apikey",
      ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash", "gemini-2.5-flash-lite"]),
    P("Cerebras", "https://api.cerebras.ai/v1", "https://cloud.cerebras.ai", ["llama-3.3-70b", "llama3.1-8b", "qwen-3-32b", "gpt-oss-120b"]),
    P("SambaNova", "https://api.sambanova.ai/v1", "https://cloud.sambanova.ai",
      ["Meta-Llama-3.3-70B-Instruct", "DeepSeek-V3-0324", "Meta-Llama-3.1-8B-Instruct"]),
    P("Mistral", "https://api.mistral.ai/v1", "https://console.mistral.ai/api-keys", ["mistral-small-latest", "open-mistral-nemo", "mistral-large-latest"]),
    P("Codestral", "https://codestral.mistral.ai/v1", "https://console.mistral.ai/codestral", ["codestral-latest"]),
    P("GitHub Models", "https://models.github.ai/inference", "https://github.com/settings/tokens",
      ["openai/gpt-4o-mini", "openai/gpt-4o", "meta/Llama-3.3-70B-Instruct", "deepseek/DeepSeek-V3-0324"],
      models_url="https://models.github.ai/catalog/models"),
    P("NVIDIA NIM", "https://integrate.api.nvidia.com/v1", "https://build.nvidia.com",
      ["meta/llama-3.3-70b-instruct", "deepseek-ai/deepseek-r1", "nvidia/llama-3.1-nemotron-70b-instruct"]),
    P("Hugging Face", "https://router.huggingface.co/v1", "https://huggingface.co/settings/tokens",
      ["meta-llama/Llama-3.3-70B-Instruct", "Qwen/Qwen2.5-72B-Instruct", "deepseek-ai/DeepSeek-V3"]),
    P("Together AI", "https://api.together.xyz/v1", "https://api.together.xyz/settings/api-keys",
      ["meta-llama/Llama-3.3-70B-Instruct-Turbo-Free", "deepseek-ai/DeepSeek-R1-Distill-Llama-70B-free"]),
    P("Cohere", "https://api.cohere.ai/compatibility/v1", "https://dashboard.cohere.com/api-keys", ["command-a-03-2025", "command-r-plus", "command-r"]),
    P("Hyperbolic", "https://api.hyperbolic.xyz/v1", "https://app.hyperbolic.xyz/settings", ["meta-llama/Llama-3.3-70B-Instruct", "deepseek-ai/DeepSeek-V3"]),
    P("SiliconFlow", "https://api.siliconflow.com/v1", "https://cloud.siliconflow.com/account/ak",
      ["Qwen/Qwen2.5-7B-Instruct", "THUDM/glm-4-9b-chat", "deepseek-ai/DeepSeek-V3"]),
    P("Zhipu GLM", "https://open.bigmodel.cn/api/paas/v4", "https://open.bigmodel.cn/usercenter/apikeys", ["glm-4-flash", "glm-4.5-flash"]),
    P("Z.ai", "https://api.z.ai/api/paas/v4", "https://z.ai/manage-apikey/apikey-list", ["glm-4.5-flash", "glm-4.5-air"]),
    P("Tencent Hunyuan", "https://api.hunyuan.cloud.tencent.com/v1", "https://console.cloud.tencent.com/hunyuan", ["hunyuan-lite"]),
    P("Alibaba DashScope", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1", "https://bailian.console.alibabacloud.com",
      ["qwen-plus", "qwen-turbo", "qwen-max"]),
    P("Scaleway", "https://api.scaleway.ai/v1", "https://console.scaleway.com/iam/api-keys", ["llama-3.3-70b-instruct", "qwen3-235b-a22b-instruct-2507"]),
    P("Kluster", "https://api.kluster.ai/v1", "https://platform.kluster.ai", ["klusterai/Meta-Llama-3.3-70B-Instruct-Turbo"]),
    P("AI21", "https://api.ai21.com/studio/v1", "https://studio.ai21.com/account/api-key", ["jamba-mini", "jamba-large"]),
    P("DeepSeek", "https://api.deepseek.com", "https://platform.deepseek.com/api_keys", ["deepseek-chat", "deepseek-reasoner"]),
    # --- локально (бесплатно навсегда)
    P("Ollama", "http://localhost:11434/v1", "https://ollama.com/download", [], nokey=True),
    P("LM Studio", "http://localhost:1234/v1", "https://lmstudio.ai", [], nokey=True),
    P("Jan", "http://localhost:1337/v1", "https://jan.ai", [], nokey=True),
    P("llama.cpp", "http://localhost:8080/v1", "", [], nokey=True),
    P("KoboldCpp", "http://localhost:5001/v1", "", [], nokey=True),
    P("text-generation-webui", "http://127.0.0.1:5000/v1", "", [], nokey=True),
]
BY_ID = {slug(p["name"]): p for p in PRESETS}


def provider(pr):
    return {"id": slug(pr["name"]), "name": pr["name"], "base_url": pr["base_url"], "api_key": "", "key_url": pr.get("key_url", ""),
            "nokey": pr.get("nokey", False), "default_key": pr.get("default_key", ""), "free_only": pr.get("free_only", False),
            "fallback": pr["fallback"], "chat_url": pr.get("chat_url", ""), "models_url": pr.get("models_url", "")}


def all_providers(): return [provider(p) for p in PRESETS]
