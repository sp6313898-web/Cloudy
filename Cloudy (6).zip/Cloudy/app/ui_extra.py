import os, sys, webbrowser
from pathlib import Path
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (QPlainTextEdit, QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QPushButton, QListWidget, QListWidgetItem, QLineEdit, QCheckBox, QComboBox, QMessageBox,
                               QFileDialog)
from . import memory, journal, system, config, diagnostics, threads
from .i18n import T
from .icons import set_ic
from .version import VERSION
from .widgets import Spark


class DiagThread(QThread):
    done = Signal(str)

    def __init__(self, cfg):
        super().__init__(); self.cfg = cfg

    def run(self):
        try: self.done.emit(diagnostics.report(self.cfg))
        except Exception as ex: self.done.emit(str(ex))


class DiagDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent); self.cfg = cfg; self.setWindowTitle(T("Диагностика")); self.resize(700, 560)
        v = QVBoxLayout(self); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(10)
        t = QLabel(T("Диагностика")); t.setObjectName("hello"); v.addWidget(t)
        self.out = QPlainTextEdit(); self.out.setReadOnly(True); self.out.setStyleSheet("font-family: Consolas, monospace; font-size: 12px;"); v.addWidget(self.out, 1)
        bb = QHBoxLayout(); rb = QPushButton(T("Проверить снова")); set_ic(rb, "refresh"); rb.clicked.connect(self.run)
        cb = QPushButton(T("Копировать")); set_ic(cb, "copy"); cb.clicked.connect(lambda: QGuiApplication.clipboard().setText(self.out.toPlainText()))
        bb.addWidget(rb); bb.addWidget(cb); bb.addStretch(); v.addLayout(bb); self.run()

    def run(self):
        self.out.setPlainText(T("Проверяю…")); self.th = DiagThread(self.cfg); self.th.done.connect(self.out.setPlainText); threads.run(self.th)


class MemoryDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle(T("Память")); self.resize(560, 520)
        v = QVBoxLayout(self); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(10)
        t = QLabel(T("Что Cloudy помнит о вас")); t.setObjectName("hello"); v.addWidget(t)
        s = QLabel(T("Факты хранятся только на этом компьютере и подмешиваются в каждый чат. Пароли и платёжные данные не сохраняются.")); s.setObjectName("sub"); s.setWordWrap(True); v.addWidget(s)
        self.lst = QListWidget(); v.addWidget(self.lst, 1)
        row = QHBoxLayout(); self.edit = QLineEdit(); self.edit.setPlaceholderText(T("Добавить факт, например: «Отвечай коротко»")); self.edit.returnPressed.connect(self.add)
        ab = QPushButton(T("Добавить")); set_ic(ab, "plus"); ab.clicked.connect(self.add); row.addWidget(self.edit, 1); row.addWidget(ab); v.addLayout(row)
        bb = QHBoxLayout(); db = QPushButton(T("Удалить выбранное")); set_ic(db, "trash"); db.clicked.connect(self.delete)
        cb = QPushButton(T("Очистить всё")); cb.clicked.connect(self.clear); bb.addWidget(db); bb.addWidget(cb); bb.addStretch(); v.addLayout(bb)
        self.msg = QLabel(""); self.msg.setObjectName("sub"); v.addWidget(self.msg); self.fill()

    def fill(self):
        self.lst.clear()
        for x in memory.load():
            it = QListWidgetItem(f"{x['text']}    ({x['ts']})"); it.setData(Qt.UserRole, x["id"]); self.lst.addItem(it)

    def add(self):
        i, m = memory.add(self.edit.text()); self.msg.setText(T(m)); self.edit.clear(); self.fill()

    def delete(self):
        for it in self.lst.selectedItems(): memory.remove(it.data(Qt.UserRole))
        self.fill()

    def clear(self):
        if QMessageBox.question(self, T("Память"), T("Удалить все сохранённые факты?")) == QMessageBox.Yes: memory.save([]); self.fill()


KINDS = {"write": "запись файла", "edit": "правка файла", "command": "команда", "computer": "действие на экране", "mcp": "вызов MCP"}


class JournalDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle(T("Журнал действий")); self.resize(760, 540)
        v = QVBoxLayout(self); v.setContentsMargins(18, 16, 18, 16); v.setSpacing(10)
        t = QLabel(T("Журнал действий ИИ")); t.setObjectName("hello"); v.addWidget(t)
        s = QLabel(T("Все правки файлов, команды и действия на экране. Правки файлов можно откатить одной кнопкой.")); s.setObjectName("sub"); s.setWordWrap(True); v.addWidget(s)
        self.lst = QListWidget(); v.addWidget(self.lst, 1); self.det = QLabel(""); self.det.setObjectName("sub"); self.det.setWordWrap(True); v.addWidget(self.det)
        self.lst.currentItemChanged.connect(lambda it, _: self.det.setText((it.data(Qt.UserRole + 1) if it else "") or ""))
        bb = QHBoxLayout(); ub = QPushButton(T("Откатить")); set_ic(ub, "undo"); ub.clicked.connect(self.undo)
        fb = QPushButton(T("Открыть папку копий")); fb.clicked.connect(lambda: system.open_folder(journal.FILES)); bb.addWidget(ub); bb.addWidget(fb); bb.addStretch(); v.addLayout(bb)
        self.fill()

    def fill(self):
        self.lst.clear()
        for e in journal.entries():
            tail = "   (" + T("откачено") + ")" if e.get("undone") else ""
            it = QListWidgetItem(f"{e['ts']}   {T(KINDS.get(e['kind'], e['kind']))}   {Path(e['target']).name or e['target']}{tail}")
            it.setData(Qt.UserRole, e["id"]); it.setData(Qt.UserRole + 1, f"{e['target']}\n{e['detail']}"); self.lst.addItem(it)

    def undo(self):
        it = self.lst.currentItem()
        if not it: return
        err = journal.undo(it.data(Qt.UserRole))
        if err: QMessageBox.information(self, T("Журнал действий"), T(err))
        self.fill()


class AboutDialog(QDialog):
    def __init__(self, parent=None, cfg=None):
        super().__init__(parent); self.cfg = cfg; self.setWindowTitle(T("О программе")); self.setMinimumWidth(520)
        v = QVBoxLayout(self); v.setContentsMargins(24, 20, 24, 20); v.setSpacing(10)
        top = QHBoxLayout(); sp = Spark(44); sp.start(); top.addWidget(sp); col = QVBoxLayout(); t = QLabel("Cloudy"); t.setObjectName("hello"); col.addWidget(t)
        ver = QLabel(T("Версия {v}").format(v=VERSION)); ver.setObjectName("sub"); col.addWidget(ver); top.addLayout(col); top.addStretch(); v.addLayout(top)
        cp = QLabel("\u00a9 2026 neymnidev  \u00b7  " + T("Лицензия MIT")); cp.setObjectName("sub"); v.addWidget(cp)
        keys = QLabel(T("Горячие клавиши:\nCtrl+N — новый чат\nCtrl+K — выбор модели\nCtrl+L — поле ввода\nCtrl+Alt+C — показать/скрыть Cloudy из любого окна\nEsc — аварийная остановка ИИ, управляющего компьютером\nEnter — отправить, Shift+Enter — новая строка"))
        keys.setWordWrap(True); v.addWidget(keys)
        info = QLabel(T("Данные, чаты и настройки: {p}").format(p=config.DATA)); info.setObjectName("sub"); info.setWordWrap(True); v.addWidget(info)
        row = QHBoxLayout()
        for text, fn in ((T("Папка данных"), lambda: system.open_folder(config.DATA)), (T("Журнал сбоев"), self.crash), (T("Резервная копия"), self.backup), (T("Руководство по MCP"), self.guide), (T("Диагностика"), self.diag), (T("Лицензия"), self.license)):
            b = QPushButton(text); b.clicked.connect(fn); row.addWidget(b)
        v.addLayout(row)

    def license(self):
        for d in (Path(sys.executable).parent, config.base_dir(), Path.cwd()):
            if (d / "LICENSE.txt").exists(): system.open_folder(d / "LICENSE.txt"); return
        QMessageBox.information(self, T("Лицензия"), T("Файл LICENSE.txt не найден рядом с программой."))

    def diag(self):
        DiagDialog(self.cfg or config.load(), self).exec()

    def crash(self):
        f = config.DATA / "crash.log"
        if f.exists() and f.stat().st_size: system.open_folder(f)
        else: QMessageBox.information(self, T("Журнал сбоев"), T("Сбоев не было."))

    def backup(self):
        f, _ = QFileDialog.getSaveFileName(self, T("Резервная копия"), "Cloudy-backup.zip", "ZIP (*.zip)")
        if f: n = system.backup(f); QMessageBox.information(self, T("Резервная копия"), T("Сохранено файлов: {n}. Ключи API в копию не входят.").format(n=n))

    def guide(self):
        for d in (config.base_dir() / "docs", Path(sys.executable).parent / "docs", Path.cwd() / "docs"):
            for name in ("MCP_guide.mp4", "MCP_GUIDE.md"):
                if (d / name).exists(): system.open_folder(d / name); return
        QMessageBox.information(self, T("Руководство по MCP"), T("Файл docs/MCP_guide.mp4 не найден. Положите папку docs рядом с Cloudy.exe."))


class OnboardingDialog(QDialog):
    """Первый запуск: язык, тема и быстрый старт с бесплатными провайдерами."""
    def __init__(self, cfg, parent=None):
        super().__init__(parent); self.cfg = cfg; self.add_free = True; self.setWindowTitle(T("Добро пожаловать")); self.setMinimumWidth(520)
        v = QVBoxLayout(self); v.setContentsMargins(26, 22, 26, 22); v.setSpacing(12)
        top = QHBoxLayout(); sp = Spark(48); sp.start(); top.addWidget(sp); t = QLabel(T("Добро пожаловать в Cloudy")); t.setObjectName("hello"); top.addWidget(t, 1); v.addLayout(top)
        d = QLabel(T("Несколько настроек для начала. Всё можно изменить позже в Настройках.")); d.setObjectName("sub"); d.setWordWrap(True); v.addWidget(d)
        f = QFormLayout(); self.lang = QComboBox(); self.lang.addItems(["Русский", "English"]); self.lang.setCurrentIndex(cfg.get("lang", "ru") == "en")
        self.theme = QComboBox(); self.theme.addItems([T("Светлая"), T("Тёмная")]); self.theme.setCurrentIndex(cfg.get("theme") == "dark")
        f.addRow(T("Язык"), self.lang); f.addRow(T("Тема"), self.theme); v.addLayout(f)
        self.free = QCheckBox(T("Подключить бесплатные API и найти рабочие модели")); self.free.setChecked(True)
        self.web = QCheckBox(T("Разрешить ИИ искать в интернете")); self.web.setChecked(cfg.get("web", True))
        self.mem = QCheckBox(T("Запоминать устойчивые факты обо мне (только на этом компьютере)")); self.mem.setChecked(cfg.get("memory_on", True))
        for c in (self.free, self.web, self.mem): v.addWidget(c)
        ok = QPushButton(T("Начать")); ok.setObjectName("primary"); ok.clicked.connect(self._ok); v.addWidget(ok)

    def _ok(self):
        self.cfg.update(lang="en" if self.lang.currentIndex() else "ru", theme="dark" if self.theme.currentIndex() else "light", web=self.web.isChecked(), memory_on=self.mem.isChecked())
        self.add_free = self.free.isChecked(); self.accept()
