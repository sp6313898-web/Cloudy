import os, sys, uuid
from pathlib import Path
from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QVBoxLayout, QFormLayout, QLineEdit, QListWidget, QPushButton, QLabel, QCheckBox, QComboBox, QPlainTextEdit,
                               QInputDialog, QMessageBox)
from . import mcp, config, threads
from .i18n import T
from .icons import set_ic

TEMPLATES = [("Filesystem", "npx", '-y @modelcontextprotocol/server-filesystem "{workspace}"'), ("Fetch", "uvx", "mcp-server-fetch"),
             ("Memory", "npx", "-y @modelcontextprotocol/server-memory"), ("Sequential Thinking", "npx", "-y @modelcontextprotocol/server-sequential-thinking"),
             ("Time", "uvx", "mcp-server-time"), ("Git", "uvx", 'mcp-server-git --repository "{workspace}"'), ("Playwright (browser)", "npx", "-y @playwright/mcp@latest")]


class TestThread(QThread):
    done = Signal(str)

    def __init__(self, cfg):
        super().__init__(); self.cfg = cfg

    def run(self):
        s = mcp.Server(self.cfg)
        try:
            s.start(120)
            self.done.emit(T("Подключено. Инструментов: {n}").format(n=len(s.tools)) + "\n" + "\n".join(f"- {t['name']}: {(t.get('description') or '')[:90]}" for t in s.tools))
        except Exception as ex:
            self.done.emit(T("Ошибка: {err}").format(err=mcp.explain(str(ex)[:600])))
        finally:
            s.stop()


class MCPDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent); self.cfg = cfg; self.mc = cfg.setdefault("mcp", {"on": False, "servers": []}); self.cur = None; self.th = None
        self.setWindowTitle(T("MCP-серверы")); self.resize(920, 640)
        h = QHBoxLayout(self); h.setContentsMargins(18, 16, 18, 16); h.setSpacing(16)
        left = QVBoxLayout(); self.lst = QListWidget(); left.addWidget(self.lst, 1)
        self.tpl = QComboBox(); self.tpl.addItem(T("Шаблон"), None)
        for n, c, a in TEMPLATES: self.tpl.addItem(n, (n, c, a))
        self.tpl.activated.connect(self.apply_tpl); left.addWidget(self.tpl)
        ab = QPushButton(T("Добавить сервер")); set_ic(ab, "plus"); ab.clicked.connect(self.add); left.addWidget(ab)
        ib = QPushButton(T("Импорт из JSON")); ib.clicked.connect(self.import_json); left.addWidget(ib)
        vb = QPushButton(T("Видео-гайд по MCP")); vb.clicked.connect(self.open_guide); left.addWidget(vb)
        info = QLabel(T("Для серверов на Node.js нужен Node.js (npx), для Python-серверов — uv (uvx). Список инструментов подтягивается автоматически."))
        info.setObjectName("sub"); info.setWordWrap(True); left.addWidget(info); h.addLayout(left, 2)
        f = QFormLayout(); f.setVerticalSpacing(8)
        self.name, self.cmd, self.args, self.url = QLineEdit(), QLineEdit(), QLineEdit(), QLineEdit()
        self.tr = QComboBox(); self.tr.addItems([T("stdio (команда)"), T("http (адрес)")]); self.tr.currentIndexChanged.connect(self.vis)
        self.env = QPlainTextEdit(); self.env.setPlaceholderText("KEY=VALUE"); self.env.setFixedHeight(64)
        self.hdr = QPlainTextEdit(); self.hdr.setPlaceholderText("Authorization: Bearer ..."); self.hdr.setFixedHeight(64)
        self.on = QCheckBox(T("Включён")); self.auto = QCheckBox(T("Не спрашивать разрешение на вызовы инструментов"))
        self.rows = {}
        for key, lab, w in (("name", T("Название"), self.name), ("tr", T("Тип"), self.tr), ("cmd", T("Команда"), self.cmd), ("args", T("Аргументы"), self.args),
                            ("env", T("Переменные"), self.env), ("url", T("Адрес"), self.url), ("hdr", T("Заголовки"), self.hdr)):
            f.addRow(lab, w); self.rows[key] = (f.labelForField(w), w)
        f.addRow(self.on); f.addRow(self.auto)
        bb = QHBoxLayout(); tb = self.tb = QPushButton(T("Проверить подключение")); set_ic(tb, "check"); tb.clicked.connect(self.test)
        sv = QPushButton(T("Сохранить")); sv.setObjectName("primary"); sv.clicked.connect(self.save)
        dl = QPushButton(T("Удалить")); set_ic(dl, "trash"); dl.clicked.connect(self.delete)
        for b in (tb, sv, dl): bb.addWidget(b)
        bb.addStretch(); f.addRow(bb)
        self.out = QPlainTextEdit(); self.out.setReadOnly(True); self.out.setFixedHeight(150); f.addRow(self.out)
        h.addLayout(f, 4); self.fill(); self.lst.currentRowChanged.connect(self.pick)

    def vis(self, *_):
        http = self.tr.currentIndex() == 1
        for k in ("cmd", "args", "env"):
            for w in self.rows[k]: w.setVisible(not http)
        for k in ("url", "hdr"):
            for w in self.rows[k]: w.setVisible(http)

    def fill(self, select=None):
        self.lst.blockSignals(True); self.lst.clear()
        for s in self.mc["servers"]: self.lst.addItem(s.get("name") or s["id"])
        self.lst.blockSignals(False)
        if self.mc["servers"]:
            i = next((k for k, s in enumerate(self.mc["servers"]) if s["id"] == select), 0); self.lst.setCurrentRow(i); self.pick(i)
        else: self.cur = None; self.vis()

    def pick(self, i):
        if not (0 <= i < len(self.mc["servers"])): return
        s = self.cur = self.mc["servers"][i]
        self.name.setText(s.get("name", "")); self.tr.setCurrentIndex(1 if s.get("transport") == "http" else 0)
        self.cmd.setText(s.get("command", "")); self.args.setText(s.get("args", "") if isinstance(s.get("args"), str) else " ".join(s.get("args") or []))
        self.env.setPlainText("\n".join(f"{k}={v}" for k, v in (s.get("env") or {}).items())); self.url.setText(s.get("url", ""))
        self.hdr.setPlainText("\n".join(f"{k}: {v}" for k, v in (s.get("headers") or {}).items()))
        self.on.setChecked(s.get("enabled", True)); self.auto.setChecked(bool(s.get("auto"))); self.out.clear(); self.vis()

    def form(self):
        env = {k.strip(): v.strip() for k, v in (l.split("=", 1) for l in self.env.toPlainText().splitlines() if "=" in l) if k.strip()}
        hdr = {k.strip(): v.strip() for k, v in (l.split(":", 1) for l in self.hdr.toPlainText().splitlines() if ":" in l)}
        return {"id": (self.cur or {}).get("id") or uuid.uuid4().hex[:8], "name": self.name.text().strip() or "MCP", "transport": "http" if self.tr.currentIndex() else "stdio",
                "command": self.cmd.text().strip(), "args": self.args.text().strip(), "env": env, "url": self.url.text().strip(), "headers": hdr,
                "enabled": self.on.isChecked(), "auto": self.auto.isChecked()}

    def add(self):
        s = {"id": uuid.uuid4().hex[:8], "name": "MCP", "transport": "stdio", "command": "", "args": "", "env": {}, "enabled": True, "auto": False}
        self.mc["servers"].append(s); config.save(self.cfg); self.fill(s["id"])

    def apply_tpl(self, i):
        d = self.tpl.itemData(i)
        if not d: return
        if not self.cur: self.add()
        self.name.setText(d[0]); self.tr.setCurrentIndex(0); self.cmd.setText(d[1]); self.args.setText(d[2]); self.vis()

    def save(self):
        if not self.cur: return
        data = self.form()                 # сначала читаем форму (в ней старый id), потом перезаписываем сервер - иначе id менялся при каждом сохранении
        self.cur.clear(); self.cur.update(data); config.save(self.cfg); self.fill(self.cur["id"])

    def delete(self):
        if self.cur: self.mc["servers"].remove(self.cur); self.cur = None; config.save(self.cfg); self.fill()

    def open_guide(self):
        for d in (config.base_dir() / "docs", Path(sys.executable).parent / "docs", Path.cwd() / "docs"):
            for name in ("MCP_guide.mp4", "MCP_GUIDE.md"):
                if (d / name).exists(): QDesktopServices.openUrl(QUrl.fromLocalFile(str(d / name))); return
        QMessageBox.information(self, T("Видео-гайд по MCP"), T("Файл docs/MCP_guide.mp4 не найден. Положите папку docs рядом с Cloudy.exe."))

    def import_json(self):
        txt, ok = QInputDialog.getMultiLineText(self, T("Импорт из JSON"), T("Вставьте JSON-конфигурацию (формат Claude Desktop / Cursor, ключ mcpServers):"))
        if not ok or not txt.strip(): return
        try: new = mcp.import_json(txt)
        except Exception as ex:
            QMessageBox.warning(self, T("Импорт из JSON"), T("Не удалось разобрать JSON: {err}").format(err=ex)); return
        self.mc["servers"].extend(new); config.save(self.cfg); self.fill(new[-1]["id"])
        self.out.setPlainText(T("Импортировано серверов: {n}. Нажмите «Проверить подключение».").format(n=len(new)))

    def test(self):
        if self.th and self.th.isRunning(): return
        self.out.setPlainText(T("Подключение… (первый запуск npx/uvx может занять минуту)")); self.tb.setEnabled(False)
        self.th = TestThread(dict(self.form(), _ws=self.cfg["workspace"]))
        self.th.done.connect(self.out.setPlainText); self.th.done.connect(lambda *_: self.tb.setEnabled(True)); threads.run(self.th)
