"""Голос. Ввод: офлайн-распознавание Vosk (модель скачивается один раз), микрофон — sounddevice.
Вывод: встроенный синтезатор речи Windows (SAPI) — без интернета."""
import json, os, queue, re, subprocess, urllib.request, zipfile
from PySide6.QtCore import QThread, Signal
from .config import DATA

VDIR = DATA / "voice"
VDIR.mkdir(exist_ok=True)
MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip"


def available() -> bool:
    try:
        import vosk, sounddevice  # noqa
        return True
    except Exception:
        return False


def model_path():
    for d in VDIR.iterdir():
        if d.is_dir() and d.name.startswith("vosk-model") and (d / "am").exists():
            return d
    return None


class ModelDownloader(QThread):
    progress = Signal(int)
    done = Signal(str)  # текст ошибки или ""

    def run(self):
        try:
            zp = VDIR / "model.zip"
            with urllib.request.urlopen(MODEL_URL, timeout=30) as r, open(zp, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0); got = 0
                while True:
                    b = r.read(1 << 16)
                    if not b: break
                    f.write(b); got += len(b)
                    if total: self.progress.emit(int(got * 100 / total))
            with zipfile.ZipFile(zp) as z: z.extractall(VDIR)
            zp.unlink()
            self.done.emit("" if model_path() else "Модель распакована неправильно.")
        except Exception as ex:
            self.done.emit(str(ex))


class Listener(QThread):
    partial = Signal(str)
    final = Signal(str)
    error = Signal(str)

    def __init__(self):
        super().__init__(); self._stop = False

    def stop(self): self._stop = True

    def run(self):
        try:
            import vosk, sounddevice as sd
            vosk.SetLogLevel(-1)
            rec = vosk.KaldiRecognizer(vosk.Model(str(model_path())), 16000)
            q = queue.Queue(); acc = ""
            with sd.RawInputStream(samplerate=16000, blocksize=4000, dtype="int16", channels=1,
                                   callback=lambda d, f, t, s: q.put(bytes(d))):
                while not self._stop:
                    try: data = q.get(timeout=0.2)
                    except queue.Empty: continue
                    if rec.AcceptWaveform(data):
                        acc = (acc + " " + json.loads(rec.Result()).get("text", "")).strip()
                        self.partial.emit(acc)
                    else:
                        self.partial.emit((acc + " " + json.loads(rec.PartialResult()).get("partial", "")).strip())
            self.final.emit((acc + " " + json.loads(rec.FinalResult()).get("text", "")).strip())
        except Exception as ex:
            self.error.emit(f"Микрофон/распознавание: {ex}")


class Speaker:
    PS = ("[Console]::InputEncoding=[Text.Encoding]::UTF8; Add-Type -AssemblyName System.Speech; "
          "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $t=[Console]::In.ReadToEnd(); "
          "if($t -match '[а-яА-Я]'){ foreach($v in $s.GetInstalledVoices()){ if($v.VoiceInfo.Culture.Name -eq 'ru-RU'){ "
          "$s.SelectVoice($v.VoiceInfo.Name); break } } }; $s.Speak($t)")

    def __init__(self): self.proc = None

    def stop(self):
        if self.proc and self.proc.poll() is None: self.proc.terminate()
        self.proc = None

    def say(self, text: str):
        self.stop()
        if os.name != "nt": return
        t = re.sub(r"```.*?```", " ", text, flags=re.S)
        t = re.sub(r"[#*_`>|]", "", t)[:4000]
        if not t.strip(): return
        self.proc = subprocess.Popen(["powershell", "-NoProfile", "-Command", self.PS], stdin=subprocess.PIPE,
                                     creationflags=0x08000000)
        self.proc.stdin.write(t.encode("utf-8")); self.proc.stdin.close()
