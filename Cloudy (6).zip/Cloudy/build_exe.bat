@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Cloudy - сборка EXE
echo ==========================================
echo   Cloudy: автоматическая сборка в EXE
echo ==========================================

set "PYOK=0"
python --version >nul 2>nul && set "PYOK=1"
if "%PYOK%"=="0" (
  echo [1/6] Python не найден. Скачиваю и устанавливаю Python 3.11 ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\py311.exe'"
  if not exist "%TEMP%\py311.exe" ( echo Не удалось скачать Python. Проверьте интернет. & pause & exit /b 1 )
  "%TEMP%\py311.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
  set "PATH=%LOCALAPPDATA%\Programs\Python\Python311;%LOCALAPPDATA%\Programs\Python\Python311\Scripts;%PATH%"
) else (
  echo [1/6] Python найден.
)
python --version >nul 2>nul || ( echo Python не запустился. Перезапустите этот файл. & pause & exit /b 1 )

echo [2/6] Создаю виртуальное окружение ...
if not exist .venv python -m venv .venv
call .venv\Scripts\activate.bat

echo [3/6] Скачиваю библиотеки ...
python -m pip install --upgrade pip
pip install -r requirements.txt pyinstaller || ( echo Ошибка установки библиотек. & pause & exit /b 1 )

echo [4/6] Собираю программу ...
python tools\make_catalog.py
pyinstaller --noconfirm --clean --windowed --name Cloudy --icon assets\icon.ico --add-data "store;store" --add-data "assets;assets" --add-data "docs;docs" --collect-all vosk --collect-all sounddevice --collect-all _sounddevice_data --collect-all tzdata --hidden-import mss.windows run.py
if not exist dist\Cloudy\Cloudy.exe ( echo Сборка программы не удалась. & pause & exit /b 1 )
echo [5/6] Упаковываю файлы для установщика ...
python tools\make_payload.py || ( echo Не удалось упаковать файлы. & pause & exit /b 1 )
echo [6/6] Собираю установщик Cloudy-Setup.exe ...
pyinstaller --noconfirm --clean --onefile --windowed --name Cloudy-Setup --icon assets\icon.ico --add-data "installer\payload.zip;." --add-data "installer\version.txt;." --add-data "assets\icon.png;." --add-data "LICENSE.txt;." --exclude-module PySide6.QtWebEngineWidgets --exclude-module PySide6.QtWebEngineCore installer\setup.py
if not exist dist\Cloudy-Setup.exe ( echo Не удалось собрать установщик. & pause & exit /b 1 )
copy /y dist\Cloudy-Setup.exe Cloudy-Setup.exe >nul
copy /y installer\payload.zip Cloudy-Portable.zip >nul
echo.
echo ГОТОВО:
echo   Cloudy-Setup.exe     - установщик (ярлыки, меню Пуск, удаление через "Приложения"). Запустите его.
echo   Cloudy-Portable.zip  - то же без установки: распакуйте и запустите Cloudy\Cloudy.exe
echo   Данные и чаты: %%APPDATA%%\Cloudy
echo   Windows SmartScreen может предупредить о неподписанном файле: "Подробнее" - "Выполнить в любом случае".
pause
