"""Установщик Cloudy в стиле Claude. Один файл Cloudy-Setup.exe: мастер установки, обновление поверх, удаление через «Приложения Windows».
Тихий режим: Cloudy-Setup.exe /S [--dir "C:\\папка"]   Удаление: uninstall.exe /S"""
import base64, math, os, shutil, subprocess, sys, tempfile, time, zipfile
from pathlib import Path

APP, EXE = "Cloudy", "Cloudy.exe"
REG_UN = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\Cloudy"
REG_RUN = r"Software\Microsoft\Windows\CurrentVersion\Run"
NOWIN = 0x08000000 if os.name == "nt" else 0
LANG = {"v": "ru"}
EN = {
    "Установка Cloudy": "Cloudy Setup", "Лицензия": "License", "Прочитайте лицензионное соглашение": "Please read the license agreement", "Принимаю условия лицензии": "I accept the license terms", "Файл лицензии не найден.": "The license file was not found.", "Удаление Cloudy": "Uninstall Cloudy", "Приветствие": "Welcome", "Параметры": "Options", "Установка": "Installing", "Готово": "Done",
    "Подтверждение": "Confirm", "Удаление": "Removing", "Добро пожаловать в Cloudy": "Welcome to Cloudy",
    "Помощник для вашего компьютера: бесплатные модели, поиск в интернете, MCP и управление компьютером. Установка займёт меньше минуты.":
        "An assistant for your computer: free models, web search, MCP and computer control. Setup takes less than a minute.",
    "Бесплатные API с автоподбором рабочей модели": "Free APIs with automatic working-model selection", "Поиск в интернете и долгая память": "Web search and long-term memory",
    "MCP-серверы и управление компьютером": "MCP servers and computer control", "75 плагинов, тёмная и светлая темы, русский и английский": "75 plugins, light and dark themes, Russian and English",
    "Найдена установленная версия — установка обновит её. Чаты и настройки сохранятся.": "An existing installation was found. Setup will update it. Your chats and settings are kept.",
    "Папка установки": "Install folder", "Обзор": "Browse", "Создать ярлык на рабочем столе": "Create a desktop shortcut", "Добавить в меню «Пуск»": "Add to the Start menu",
    "Запускать вместе с Windows (в трее)": "Start with Windows (in the tray)", "Потребуется около {mb} МБ. Права администратора не нужны.": "About {mb} MB needed. No administrator rights required.",
    "Далее": "Next", "Установить": "Install", "Отмена": "Cancel", "Закрыть": "Close", "Удалить": "Remove", "Назад": "Back",
    "Выберите папку, а не корень диска.": "Choose a folder, not a drive root.", "Папка не пуста. Выберите пустую или новую папку.": "The folder is not empty. Choose an empty or new folder.",
    "Закрываю запущенный Cloudy…": "Closing the running Cloudy...", "Удаляю старую версию…": "Removing the old version...", "Копирую файлы…": "Copying files...",
    "Создаю удалитель…": "Creating the uninstaller...", "Создаю ярлыки…": "Creating shortcuts...", "Регистрирую в Windows…": "Registering with Windows...",
    "Cloudy установлен": "Cloudy is installed", "Всё готово. Нажмите «Готово» и начните работу.": "All set. Click Done and get started.", "Запустить Cloudy": "Launch Cloudy",
    "Ошибка установки: {err}": "Setup error: {err}", "Cloudy будет удалён с этого компьютера.": "Cloudy will be removed from this computer.",
    "Удалить также мои чаты, настройки и память": "Also delete my chats, settings and memory", "Удаляю файлы…": "Removing files...", "Удаляю ярлыки и записи…": "Removing shortcuts and entries...",
    "Cloudy удалён": "Cloudy was removed", "Спасибо, что пользовались Cloudy.": "Thank you for using Cloudy.", "Небезопасный путь в архиве": "Unsafe path in the archive",
    "Не найден пакет установки (payload.zip).": "The setup package (payload.zip) was not found.", "Версия {v}": "Version {v}", "Удаляю данные…": "Removing data...",
}


def T(s): return EN.get(s, s) if LANG["v"] == "en" else s


def res(name):
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / name


def version():
    try: return res("version.txt").read_text("utf-8").strip()
    except Exception: return "1.0"


def license_text():
    try: return res("LICENSE.txt").read_text("utf-8")
    except Exception: return T("Файл лицензии не найден.")


def default_dir(): return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Programs" / APP


def appdata_dir(): return Path(os.environ.get("APPDATA", str(Path.home()))) / APP


def system_lang():
    try:
        import ctypes
        return "ru" if (ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF) == 0x19 else "en"
    except Exception:
        return "ru"


# ---------- Windows
def reg_get(key, name, hive=None):
    try:
        import winreg
        with winreg.OpenKey(hive or winreg.HKEY_CURRENT_USER, key) as k: return winreg.QueryValueEx(k, name)[0]
    except Exception: return None


def existing_install():
    p = reg_get(REG_UN, "InstallLocation")
    if p and (Path(p) / EXE).exists(): return Path(p)
    return default_dir() if (default_dir() / EXE).exists() else None


def kill_running():
    if os.name == "nt":
        subprocess.run(["taskkill", "/F", "/IM", EXE], capture_output=True, creationflags=NOWIN); time.sleep(1.2)


def desktop_dir():
    v = reg_get(r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders", "Desktop")
    return Path(os.path.expandvars(v)) if v else Path.home() / "Desktop"


def start_menu_dir(): return Path(os.environ.get("APPDATA", str(Path.home()))) / "Microsoft" / "Windows" / "Start Menu" / "Programs"


def make_lnk(lnk, target, workdir, icon, args=""):
    if os.name != "nt": return
    q = lambda x: str(x).replace("'", "''")
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.IconLocation='%s,0';$s.Arguments='%s';$s.Description='Cloudy';$s.Save()"
          % (q(lnk), q(target), q(workdir), q(icon), q(args)))
    Path(lnk).parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", base64.b64encode(ps.encode("utf-16-le")).decode()],
                   capture_output=True, creationflags=NOWIN, timeout=40)


def write_uninstall_entry(target, size_kb):
    import winreg
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_UN) as k:
        for n, v in (("DisplayName", "Cloudy"), ("DisplayVersion", version()), ("Publisher", "neymnidev"), ("InstallLocation", str(target)), ("DisplayIcon", str(target / EXE)),
                     ("UninstallString", '"%s" --uninstall' % (target / "uninstall.exe")), ("QuietUninstallString", '"%s" --uninstall /S' % (target / "uninstall.exe")),
                     ("InstallDate", time.strftime("%Y%m%d"))):
            winreg.SetValueEx(k, n, 0, winreg.REG_SZ, v)
        for n, v in (("NoModify", 1), ("NoRepair", 1), ("EstimatedSize", int(size_kb))): winreg.SetValueEx(k, n, 0, winreg.REG_DWORD, v)


def set_autostart(on, target):
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_RUN, 0, winreg.KEY_SET_VALUE) as k:
        if on: winreg.SetValueEx(k, "Cloudy", 0, winreg.REG_SZ, '"%s" --tray' % (target / EXE))
        else:
            try: winreg.DeleteValue(k, "Cloudy")
            except FileNotFoundError: pass


# ---------- логика установки (без интерфейса — можно запускать тихо)
def dir_problem(p: Path) -> str:
    if len(p.parts) < 3: return T("Выберите папку, а не корень диска.")
    try:
        if p.exists() and any(p.iterdir()) and not (p / EXE).exists(): return T("Папка не пуста. Выберите пустую или новую папку.")
    except Exception: pass
    return ""


def payload_size_mb():
    try:
        with zipfile.ZipFile(res("payload.zip")) as z: return max(1, sum(i.file_size for i in z.infolist()) // (1024 * 1024))
    except Exception: return 0


def clean_dir(p: Path):
    for c in p.iterdir():
        shutil.rmtree(c, ignore_errors=True) if c.is_dir() else c.unlink(missing_ok=True)


def extract(target: Path, progress):
    pk = res("payload.zip")
    if not pk.exists(): raise RuntimeError(T("Не найден пакет установки (payload.zip)."))
    root = target.resolve()
    with zipfile.ZipFile(pk) as z:
        infos = z.infolist()
        for i, info in enumerate(infos):
            dest = (root / info.filename).resolve()
            if dest != root and root not in dest.parents: raise RuntimeError(T("Небезопасный путь в архиве"))
            if info.is_dir(): dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, open(dest, "wb") as out: shutil.copyfileobj(src, out, 1 << 20)
            progress(int(100 * (i + 1) / len(infos)))


def install(opts, cb):
    target = Path(opts["dir"])
    cb(2, T("Закрываю запущенный Cloudy…")); kill_running()
    if (target / EXE).exists(): cb(5, T("Удаляю старую версию…")); clean_dir(target)
    target.mkdir(parents=True, exist_ok=True)
    extract(target, lambda p: cb(8 + int(p * 0.78), T("Копирую файлы…")))
    cb(88, T("Создаю удалитель…"))
    if getattr(sys, "frozen", False): shutil.copy2(sys.executable, target / "uninstall.exe")
    size_kb = sum(f.stat().st_size for f in target.rglob("*") if f.is_file()) // 1024
    cb(92, T("Создаю ярлыки…"))
    icon = target / "_internal" / "assets" / "icon.ico"; icon = icon if icon.exists() else target / EXE
    if opts.get("desktop"): make_lnk(desktop_dir() / "Cloudy.lnk", target / EXE, target, icon)
    if opts.get("startmenu"): make_lnk(start_menu_dir() / "Cloudy.lnk", target / EXE, target, icon)
    cb(96, T("Регистрирую в Windows…"))
    if os.name == "nt":
        write_uninstall_entry(target, size_kb); set_autostart(bool(opts.get("autostart")), target)
    cb(100, T("Готово"))


def uninstall(target: Path, wipe, cb):
    cb(5, T("Закрываю запущенный Cloudy…")); kill_running()
    cb(25, T("Удаляю ярлыки и записи…"))
    for p in (desktop_dir() / "Cloudy.lnk", start_menu_dir() / "Cloudy.lnk"):
        try: p.unlink()
        except Exception: pass
    if os.name == "nt":
        import winreg
        for hive, key in ((winreg.HKEY_CURRENT_USER, REG_UN),):
            try: winreg.DeleteKey(hive, key)
            except Exception: pass
        try: set_autostart(False, target)
        except Exception: pass
    cb(55, T("Удаляю файлы…"))
    for _ in range(6):
        shutil.rmtree(target, ignore_errors=True)
        if not target.exists(): break
        time.sleep(0.8)
    if wipe: cb(85, T("Удаляю данные…")); shutil.rmtree(appdata_dir(), ignore_errors=True)
    cb(100, T("Готово"))


# ---------- интерфейс
def run_gui(mode, target, opts):
    from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QRectF, QThread, Signal
    from PySide6.QtGui import QColor, QPainter, QIcon, QFont
    from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit, QCheckBox, QStackedWidget, QFileDialog, QProgressBar,
                                   QFrame, QGraphicsOpacityEffect, QMessageBox, QPlainTextEdit)
    ACCENT = "#C96442"

    class Spark(QWidget):
        def __init__(self, size, color=ACCENT):
            super().__init__(); self.setFixedSize(size, size); self.color, self.angle, self.t = QColor(color), 0.0, 0.0; self.fast = False
            self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(30)

        def tick(self):
            self.angle = (self.angle + (14 if self.fast else 4)) % 360; self.t += 0.1; self.update()

        def paintEvent(self, e):
            p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.translate(self.width() / 2, self.height() / 2); p.rotate(self.angle)
            r = (self.width() / 2 - 2) * (1 + 0.07 * math.sin(self.t)); p.setBrush(self.color); p.setPen(Qt.NoPen)
            for i in range(8):
                p.save(); p.rotate(i * 45); p.drawRoundedRect(QRectF(-r * 0.09, -r, r * 0.18, r * 0.95), r * 0.09, r * 0.09); p.restore()

    class Work(QThread):
        progress = Signal(int, str)
        done = Signal(str)

        def __init__(self, fn): super().__init__(); self.fn = fn

        def run(self):
            try: self.fn(lambda p, t: self.progress.emit(int(p), t)); self.done.emit("")
            except Exception as ex: self.done.emit(str(ex))

    QSS = ("* {font-family:'Segoe UI'; font-size:14px; color:#1F1E1D;} QWidget#win {background:#FAF9F5;} QFrame#left {background:#F0EEE6; border-right:1px solid #E3E0D5;}"
           "QLabel#title {font-family:Georgia,'Times New Roman',serif; font-size:30px;} QLabel#brand {font-family:Georgia,serif; font-size:24px;} QLabel#sub {color:#6B6A68;}"
           "QLabel#err {color:#B5524A;} QLabel#step {color:#8A8984; padding:4px 0;} QLabel#stepOn {color:#1F1E1D; font-weight:600; padding:4px 0;}"
           "QPushButton {background:transparent; border:1px solid #E3E0D5; border-radius:10px; padding:9px 18px;} QPushButton:hover {background:#E8E5DA;}"
           "QPushButton#primary {background:#C96442; border:none; color:white; font-weight:600;} QPushButton#primary:hover {background:#B85A3A;} QPushButton#primary:disabled {background:#E3E0D5; color:#9A9892;}"
           "QPushButton#link {border:none; color:#6B6A68; padding:6px 10px;} QPushButton#link:hover {color:#C96442; background:transparent;}"
           "QPlainTextEdit {background:white; border:1px solid #E3E0D5; border-radius:8px; padding:8px; font-size:12px;}"
           "QLineEdit {background:white; border:1px solid #E3E0D5; border-radius:8px; padding:8px 10px;} QLineEdit:focus {border:1px solid #C96442;}"
           "QCheckBox {spacing:10px;} QCheckBox::indicator {width:18px; height:18px; border-radius:5px; border:1px solid #8A8984; background:white;}"
           "QCheckBox::indicator:checked {background:#C96442; border:1px solid #C96442;} QProgressBar {border:none; border-radius:5px; background:#E3E0D5; height:10px;}"
           "QProgressBar::chunk {background:#C96442; border-radius:5px;}")

    class Wizard(QWidget):
        def __init__(self):
            super().__init__(); self.setObjectName("win"); self.mode, self.target, self.opts, self.worker, self.busy = mode, target, dict(opts), None, False
            self.setWindowTitle(T("Установка Cloudy") if mode == "install" else T("Удаление Cloudy")); self.setFixedSize(820, 560)
            ic = res("icon.png")
            if ic.exists(): self.setWindowIcon(QIcon(str(ic)))
            root = QHBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)
            left = QFrame(); left.setObjectName("left"); left.setFixedWidth(250); lv = QVBoxLayout(left); lv.setContentsMargins(26, 32, 20, 24); lv.setSpacing(6)
            self.spark = Spark(84); lv.addWidget(self.spark); b = QLabel("Cloudy"); b.setObjectName("brand"); lv.addWidget(b)
            v = QLabel(T("Версия {v}").format(v=version()) + "  ·  \u00a9 neymnidev"); v.setObjectName("sub"); lv.addWidget(v); lv.addSpacing(26)
            names = ["Приветствие", "Лицензия", "Параметры", "Установка", "Готово"] if mode == "install" else ["Подтверждение", "Удаление", "Готово"]
            self.steps = [QLabel(T(n)) for n in names]
            for s in self.steps: s.setObjectName("step"); lv.addWidget(s)
            lv.addStretch(); self.lang = QPushButton("English" if LANG["v"] == "ru" else "Русский"); self.lang.setObjectName("link"); self.lang.clicked.connect(self.toggle_lang); lv.addWidget(self.lang, 0, Qt.AlignLeft)
            root.addWidget(left)
            right = QWidget(); rv = QVBoxLayout(right); rv.setContentsMargins(36, 32, 36, 24); self.stack = QStackedWidget(); rv.addWidget(self.stack, 1)
            bar = QHBoxLayout(); bar.addStretch(); self.cancel = QPushButton(T("Отмена")); self.cancel.clicked.connect(self.close)
            self.next = QPushButton(T("Далее")); self.next.setObjectName("primary"); self.next.setMinimumWidth(130); self.next.clicked.connect(self.on_next)
            bar.addWidget(self.cancel); bar.addWidget(self.next); rv.addLayout(bar); root.addWidget(right, 1)
            self.build(); self.go(0)

        # --- страницы
        def page(self, title, sub=None):
            w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(0, 0, 0, 0); l.setSpacing(12); t = QLabel(title); t.setObjectName("title"); t.setWordWrap(True); l.addWidget(t)
            if sub: s = QLabel(sub); s.setObjectName("sub"); s.setWordWrap(True); l.addWidget(s)
            self.stack.addWidget(w); return l

        def build(self):
            if self.mode == "install":
                l = self.page(T("Добро пожаловать в Cloudy"), T("Помощник для вашего компьютера: бесплатные модели, поиск в интернете, MCP и управление компьютером. Установка займёт меньше минуты."))
                for f in ("Бесплатные API с автоподбором рабочей модели", "Поиск в интернете и долгая память", "MCP-серверы и управление компьютером", "75 плагинов, тёмная и светлая темы, русский и английский"):
                    r = QLabel("<span style='color:#C96442'>&#9679;</span>&nbsp;&nbsp;" + T(f)); l.addWidget(r)
                if existing_install():
                    n = QLabel(T("Найдена установленная версия — установка обновит её. Чаты и настройки сохранятся.")); n.setObjectName("sub"); n.setWordWrap(True); l.addWidget(n)
                l.addStretch()
                l = self.page(T("Лицензия"), T("Прочитайте лицензионное соглашение"))
                self.lic = QPlainTextEdit(); self.lic.setReadOnly(True); self.lic.setPlainText(license_text()); l.addWidget(self.lic, 1)
                self.c_lic = QCheckBox(T("Принимаю условия лицензии")); self.c_lic.toggled.connect(lambda on: self.next.setEnabled(on) if self.stack.currentIndex() == 1 else None); l.addWidget(self.c_lic)
                l = self.page(T("Параметры"))
                l.addWidget(QLabel(T("Папка установки"))); row = QHBoxLayout(); self.path = QLineEdit(str(self.opts["dir"])); bb = QPushButton(T("Обзор")); bb.clicked.connect(self.browse)
                row.addWidget(self.path, 1); row.addWidget(bb); l.addLayout(row); self.err = QLabel(""); self.err.setObjectName("err"); self.err.setWordWrap(True); l.addWidget(self.err)
                self.c_desk = QCheckBox(T("Создать ярлык на рабочем столе")); self.c_desk.setChecked(True); self.c_menu = QCheckBox(T("Добавить в меню «Пуск»")); self.c_menu.setChecked(True)
                self.c_auto = QCheckBox(T("Запускать вместе с Windows (в трее)"))
                for c in (self.c_desk, self.c_menu, self.c_auto): l.addWidget(c)
                sz = QLabel(T("Потребуется около {mb} МБ. Права администратора не нужны.").format(mb=payload_size_mb())); sz.setObjectName("sub"); l.addWidget(sz); l.addStretch()
                l = self.page(T("Установка")); self.p_text = QLabel(""); self.p_text.setObjectName("sub"); self.bar = QProgressBar(); self.bar.setRange(0, 100); self.bar.setTextVisible(False)
                l.addStretch(); l.addWidget(self.bar); l.addWidget(self.p_text); l.addStretch()
                l = self.page(T("Cloudy установлен"), T("Всё готово. Нажмите «Готово» и начните работу.")); self.c_run = QCheckBox(T("Запустить Cloudy")); self.c_run.setChecked(True); l.addStretch(); l.addWidget(self.c_run); l.addStretch()
            else:
                l = self.page(T("Удаление Cloudy"), T("Cloudy будет удалён с этого компьютера.")); self.c_wipe = QCheckBox(T("Удалить также мои чаты, настройки и память")); l.addStretch(); l.addWidget(self.c_wipe); l.addStretch()
                l = self.page(T("Удаление")); self.p_text = QLabel(""); self.p_text.setObjectName("sub"); self.bar = QProgressBar(); self.bar.setRange(0, 100); self.bar.setTextVisible(False)
                l.addStretch(); l.addWidget(self.bar); l.addWidget(self.p_text); l.addStretch()
                l = self.page(T("Cloudy удалён"), T("Спасибо, что пользовались Cloudy.")); l.addStretch()
            self.anim = QPropertyAnimation(self.bar, b"value", self); self.anim.setDuration(260)

        def go(self, i):
            self.stack.setCurrentIndex(i); w = self.stack.currentWidget(); eff = QGraphicsOpacityEffect(w); w.setGraphicsEffect(eff)
            a = QPropertyAnimation(eff, b"opacity", w); a.setDuration(320); a.setStartValue(0.0); a.setEndValue(1.0); a.setEasingCurve(QEasingCurve.OutCubic)
            a.finished.connect(lambda: QTimer.singleShot(0, lambda: w.setGraphicsEffect(None))); a.start(); self._a = a
            for k, s in enumerate(self.steps): s.setObjectName("stepOn" if k == i else "step"); s.style().unpolish(s); s.style().polish(s)
            last = i == self.stack.count() - 1; self.spark.fast = False
            if self.mode == "install": self.next.setText(T({0: "Далее", 1: "Далее", 2: "Установить"}.get(i, "Готово"))); self.next.setEnabled(i != 3 and (i != 1 or self.c_lic.isChecked()))
            else: self.next.setText(T("Удалить") if i == 0 else T("Закрыть")); self.next.setEnabled(i != 1)
            self.cancel.setVisible(not last and i != (3 if self.mode == "install" else 1))

        def browse(self):
            d = QFileDialog.getExistingDirectory(self, T("Папка установки"), self.path.text())
            if d:
                d = Path(d)
                try: d = d / APP if (any(d.iterdir()) and not (d / EXE).exists()) else d
                except Exception: pass
                self.path.setText(str(d))

        def toggle_lang(self):
            LANG["v"] = "en" if LANG["v"] == "ru" else "ru"; nw = Wizard(); QApplication.instance()._w = nw; nw.show(); self.hide(); self.deleteLater()

        def set_progress(self, p, text):
            self.anim.stop(); self.anim.setStartValue(self.bar.value()); self.anim.setEndValue(p); self.anim.start(); self.p_text.setText(text)

        def start(self, fn):
            self.busy = True; self.spark.fast = True; self.go(self.stack.currentIndex() + 1); self.spark.fast = True
            self.worker = Work(fn); self.worker.progress.connect(self.set_progress); self.worker.done.connect(self.finished); self.worker.start()

        def finished(self, err):
            self.busy = False
            if err: QMessageBox.warning(self, "Cloudy", T("Ошибка установки: {err}").format(err=err)); self.close(); return
            self.go(self.stack.count() - 1)

        def on_next(self):
            i = self.stack.currentIndex()
            if self.mode == "install":
                if i in (0, 1): self.go(i + 1)
                elif i == 2:
                    p = Path(self.path.text().strip()); bad = dir_problem(p)
                    if bad: self.err.setText(bad); return
                    self.opts.update(dir=str(p), desktop=self.c_desk.isChecked(), startmenu=self.c_menu.isChecked(), autostart=self.c_auto.isChecked())
                    self.start(lambda cb: install(self.opts, cb))
                else:
                    if self.c_run.isChecked(): launch(Path(self.opts["dir"]))
                    self.close()
            else:
                if i == 0: self.start(lambda cb: uninstall(self.target, self.c_wipe.isChecked(), cb))
                else: self.close()

        def closeEvent(self, e):
            if self.busy: e.ignore()
            else: super().closeEvent(e)

    app = QApplication(sys.argv); app.setStyle("Fusion"); app.setStyleSheet(QSS); w = Wizard(); app._w = w; w.show(); return app.exec()


def launch(target: Path):
    try: subprocess.Popen([str(target / EXE)], cwd=str(target), creationflags=(0x00000008 | 0x00000200) if os.name == "nt" else 0)
    except Exception: pass


def main():
    a = sys.argv[1:]; low = [x.lower() for x in a]; silent = any(x in ("/s", "--silent", "/silent") for x in low); LANG["v"] = system_lang()
    me = Path(sys.executable).name.lower()
    opts = {"dir": str(default_dir()), "desktop": True, "startmenu": True, "autostart": False}
    if "--dir" in low and low.index("--dir") + 1 < len(a): opts["dir"] = a[low.index("--dir") + 1]
    if "--uninstall-run" in low:                       # уже запущены из временной копии
        target = Path(a[low.index("--uninstall-run") + 1])
        if silent: uninstall(target, False, lambda p, t: None); _selfdelete(); return 0
        code = run_gui("uninstall", target, opts); _selfdelete(); return code
    if "--uninstall" in low or me.startswith("uninstall"):
        target = Path(sys.executable).parent; tmp = Path(tempfile.gettempdir()) / ("cloudy-uninstall-%d.exe" % os.getpid())
        shutil.copy2(sys.executable, tmp); subprocess.Popen([str(tmp), "--uninstall-run", str(target)] + (["/S"] if silent else []), creationflags=NOWIN); return 0
    if silent:
        try: install(opts, lambda p, t: None); return 0
        except Exception: return 1
    ex = existing_install()
    if ex: opts["dir"] = str(ex)
    return run_gui("install", None, opts)


def _selfdelete():
    if os.name == "nt" and getattr(sys, "frozen", False) and "cloudy-uninstall-" in sys.executable.lower():
        subprocess.Popen('cmd /c ping 127.0.0.1 -n 3 >nul & del /f /q "%s"' % sys.executable, shell=True, creationflags=NOWIN)


if __name__ == "__main__":
    sys.exit(main())
