import faulthandler, os, sys, threading, traceback

os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu --no-sandbox")  # встроенный предпросмотр без падений драйвера
from app.config import DATA

LOG = DATA / "crash.log"
try:
    _f = open(LOG, "a", encoding="utf-8"); faulthandler.enable(_f)   # причины «жёстких» вылетов пишутся в crash.log
except Exception:
    pass


def _hook(t, v, tb):
    try:
        with open(LOG, "a", encoding="utf-8") as f: f.write("".join(traceback.format_exception(t, v, tb)) + "\n")
    except Exception:
        pass


sys.excepthook = _hook
threading.excepthook = lambda a: _hook(a.exc_type, a.exc_value, a.exc_traceback)

from PySide6.QtWidgets import QApplication
from app import threads, mcp
from app.ui import MainWindow
from app.icons import app_icon

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("Cloudy"); app.setStyle("Fusion"); app.setWindowIcon(app_icon()); app.setQuitOnLastWindowClosed(False)
    app.aboutToQuit.connect(lambda: (threads.stop_all(), mcp.MANAGER.shutdown()))
    w = MainWindow(); app._win = w
    if "--tray" in sys.argv and getattr(w, "tray", None): pass   # запуск свёрнутым в трей
    else: w.show()
    sys.exit(app.exec())
